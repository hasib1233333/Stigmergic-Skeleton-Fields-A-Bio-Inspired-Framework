import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from plot_style import apply_style, COLORS

apply_style()

with open('/home/claude/smsn/SSF_Code_Results/simulation_code/async_stigmergy_results.json') as f:
    r = json.load(f)

fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.2))

delay_labels = ['synchronous\n(baseline)', '1-round\ndelay', '3-round\ndelay', '5-round\ndelay']
delay_keys = ['synchronous (baseline)', '1-round delay', '3-round delay', '5-round delay']
delay_x = [0, 1, 3, 5]
cost_means = [r[k]['cost_mean'] for k in delay_keys]
cost_sds = [r[k]['cost_sd'] for k in delay_keys]

ax = axes[0]
ax.errorbar(delay_x, cost_means, yerr=cost_sds, marker='o', color=COLORS['blue'],
            capsize=3, lw=1.8)
ax.set_xlabel('Field-view delay (rounds)')
ax.set_ylabel('Mean path cost (px)')
ax.set_title('(a) Robustness to stale field views', fontsize=9.5)
ax.grid(alpha=0.25)
ax.set_ylim(min(cost_means) - 5, max(cost_means) + 8)

loss_labels = ['synchronous\n(0% loss)', '10% loss', '20% loss', '40% loss']
loss_keys = ['synchronous (baseline)', '10% update loss', '20% update loss', '40% update loss']
loss_x = [0, 10, 20, 40]
lcost_means = [r[k]['cost_mean'] for k in loss_keys]
lcost_sds = [r[k]['cost_sd'] for k in loss_keys]

ax2 = axes[1]
ax2.errorbar(loss_x, lcost_means, yerr=lcost_sds, marker='s', color=COLORS['orange'],
             capsize=3, lw=1.8)
ax2.set_xlabel('Update-message loss rate (%)')
ax2.set_ylabel('Mean path cost (px)')
ax2.set_title('(b) Robustness to dropped field updates', fontsize=9.5)
ax2.grid(alpha=0.25)

fig.suptitle('SSF degrades gracefully under simulated stale/lossy shared-field access: '
             'under 6% cost increase at 40% message loss, no measurable degradation '
             'up to 5 rounds of delay', fontsize=9.3, y=1.04)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig_async_stigmergy.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig_async_stigmergy.png', bbox_inches='tight', dpi=300)
print("async stigmergy figure done")

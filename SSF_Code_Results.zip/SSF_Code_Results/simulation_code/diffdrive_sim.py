"""
Continuous-motion layer on top of SSF/LIR.

This does NOT require ROS or Gazebo -- it is a self-contained
kinodynamic simulation (differential-drive kinematics + pure-pursuit
path following + a simple raycast range sensor for local collision
checking) that plays the role Gazebo would play in a real deployment:
turning SSF's discrete skeleton-graph paths into continuous robot
motion, so that the "instantaneous graph traversal" simplification
flagged in the paper's Discussion is actually relaxed and exercised.

It is offered as a runnable, honest stand-in for hardware/Gazebo
validation, not a replacement for it. The paper's Discussion section
is explicit that ROS 2 / Gazebo validation is still open future work;
this script is the continuous-control half of that step, which can run
without any ROS installation.
"""
import numpy as np


class DiffDriveRobot:
    """Unicycle/differential-drive kinematic model."""

    def __init__(self, x, y, theta, max_v=14.0, max_omega=3.0):
        self.x = x
        self.y = y
        self.theta = theta
        self.max_v = max_v
        self.max_omega = max_omega
        self.history = [(x, y)]

    def step(self, v, omega, dt):
        v = np.clip(v, -self.max_v, self.max_v)
        omega = np.clip(omega, -self.max_omega, self.max_omega)
        self.x += v * np.cos(self.theta) * dt
        self.y += v * np.sin(self.theta) * dt
        self.theta += omega * dt
        self.theta = (self.theta + np.pi) % (2 * np.pi) - np.pi
        self.history.append((self.x, self.y))


class PurePursuitController:
    """Sequential waypoint follower over a polyline of waypoints (here,
    the (y, x) pixel coordinates of an SSF/LIR skeleton path). Advances
    to the next waypoint once within a tolerance of the current one;
    this is simpler and far less prone to hunting/oscillation than a
    lookahead-search pure-pursuit variant, at the cost of slightly less
    smooth cornering, which is an acceptable trade for this demo."""

    def __init__(self, waypoints, lookahead=5.0, v_nominal=7.0, wp_tol=3.0):
        # waypoints given as (row, col) = (y, x); convert to (x, y) for
        # standard planar kinematics
        self.wp = np.array([(x, y) for (y, x) in waypoints], dtype=float)
        self.lookahead = lookahead
        self.v_nominal = v_nominal
        self.wp_tol = wp_tol
        self._idx = 1 if len(self.wp) > 1 else 0

    def target_point(self, pos):
        return self.wp[self._idx]

    def _advance_if_close(self, pos):
        moved = True
        while moved and self._idx < len(self.wp) - 1:
            moved = False
            d_cur = np.hypot(self.wp[self._idx, 0] - pos[0], self.wp[self._idx, 1] - pos[1])
            if d_cur < self.wp_tol:
                self._idx += 1
                moved = True
                continue
            d_next = np.hypot(self.wp[self._idx + 1, 0] - pos[0], self.wp[self._idx + 1, 1] - pos[1])
            if d_next < d_cur:
                self._idx += 1
                moved = True

    def at_goal(self, pos, tol=4.0):
        return np.hypot(self.wp[-1, 0] - pos[0], self.wp[-1, 1] - pos[1]) < tol

    def control(self, robot):
        self._advance_if_close((robot.x, robot.y))
        tx, ty = self.target_point((robot.x, robot.y))
        dx, dy = tx - robot.x, ty - robot.y
        target_theta = np.arctan2(dy, dx)
        heading_err = (target_theta - robot.theta + np.pi) % (2 * np.pi) - np.pi
        omega = 2.5 * heading_err
        # slow down sharply when a large heading correction is needed,
        # exactly like a real differential-drive base would
        v = self.v_nominal * max(0.15, 1.0 - abs(heading_err) / (np.pi / 2))
        # also slow down when nearing the final waypoint so the
        # controller converges into the goal tolerance instead of
        # orbiting it
        dist_to_goal = np.hypot(self.wp[-1, 0] - robot.x, self.wp[-1, 1] - robot.y)
        if dist_to_goal < 3 * self.lookahead:
            v *= max(0.25, dist_to_goal / (3 * self.lookahead))
        return v, omega


def raycast_range(obstacle_mask, x, y, theta, max_range=18.0, n_steps=60):
    """Simple ray-casting range sensor (stand-in for a 1-beam LIDAR
    slice) used only for emergency braking, not for planning."""
    H, W = obstacle_mask.shape
    for i in range(1, n_steps + 1):
        r = max_range * i / n_steps
        px = x + r * np.cos(theta)
        py = y + r * np.sin(theta)
        if not (0 <= py < H and 0 <= px < W):
            return r
        if obstacle_mask[int(py), int(px)]:
            return r
    return max_range


def simulate_fleet(obstacle_mask, robot_paths, dt=0.1, max_steps=4000,
                    dynamic_event=None):
    """robot_paths: list of skeleton-path node lists (each a list of
    (row, col) tuples) already planned by SSF.
    dynamic_event: optional dict {'step': int, 'mask_after': ndarray,
                                    'robot_idx': int, 'new_path': list}
    applied mid-simulation to emulate a LIR replan triggered by a newly
    appeared obstacle, without needing to re-run skeleton extraction
    inside this continuous-motion layer.
    Returns per-robot state histories and simple tracking diagnostics.
    """
    robots = []
    controllers = []
    for path in robot_paths:
        y0, x0 = path[0]
        y1, x1 = path[min(3, len(path) - 1)]
        theta0 = np.arctan2(y1 - y0, x1 - x0)
        robots.append(DiffDriveRobot(x0, y0, theta0))
        controllers.append(PurePursuitController(path))

    mask = obstacle_mask
    finished = [False] * len(robots)
    finish_time = [None] * len(robots)
    min_clearance = [np.inf] * len(robots)
    replanned = [False] * len(robots)

    for step in range(max_steps):
        if dynamic_event is not None and step == dynamic_event['step']:
            mask = dynamic_event['mask_after']
            idx = dynamic_event['robot_idx']
            controllers[idx] = PurePursuitController(dynamic_event['new_path'],
                                                       lookahead=controllers[idx].lookahead,
                                                       v_nominal=controllers[idx].v_nominal)
            replanned[idx] = True

        all_done = True
        for i, (robot, ctrl) in enumerate(zip(robots, controllers)):
            if finished[i]:
                continue
            all_done = False
            v, omega = ctrl.control(robot)
            side = np.pi / 5
            rng_c = raycast_range(mask, robot.x, robot.y, robot.theta, max_range=10.0, n_steps=30)
            rng_l = raycast_range(mask, robot.x, robot.y, robot.theta + side, max_range=10.0, n_steps=30)
            rng_r = raycast_range(mask, robot.x, robot.y, robot.theta - side, max_range=10.0, n_steps=30)
            min_clearance[i] = min(min_clearance[i], rng_c, rng_l, rng_r)
            # simple reactive avoidance: steer away from whichever side is
            # closer, and only slow forward speed when the path directly
            # ahead is also blocked (avoids the naive "brake forever while
            # grazing a wall" failure mode of forward-only sensing)
            if min(rng_l, rng_c, rng_r) < 4.5:
                omega += 1.8 * (rng_l - rng_r) / 4.5
            if rng_c < 2.0:
                v *= 0.5
            robot.step(v, omega, dt)
            if ctrl.at_goal((robot.x, robot.y)):
                finished[i] = True
                finish_time[i] = step * dt
        if all_done:
            break

    return {
        'robots': robots,
        'finish_time': finish_time,
        'min_clearance': min_clearance,
        'replanned': replanned,
        'total_steps': step + 1,
    }

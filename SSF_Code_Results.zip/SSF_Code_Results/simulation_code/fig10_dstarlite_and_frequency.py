import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import (apply_dynamic_obstacle, full_reskeletonize, local_reskeletonize,
                       init_pheromone, modulated_shortest_path)
from advanced_baselines import dstar_lite_initial_and_replan

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

# ---------------------------------------------------------------------------
# Part A: LIR vs full re-skeletonization vs D* Lite, across map sizes
# ---------------------------------------------------------------------------
sizes = [140, 220, 300]
n_trials = 4
lir_times = {s: [] for s in sizes}
full_times = {s: [] for s in sizes}
dstar_times = {s: [] for s in sizes}

for size in sizes:
    for trial in range(n_trials):
        grid = make_office_environment(size=size, seed=1 + trial)
        free = ~grid
        skel, dist = compute_skeleton(free)
        G0 = skeleton_to_graph(skel, dist)
        start = nearest_node(G0, 8, 8)
        goal = nearest_node(G0, size - 10, size - 10)
        init_pheromone(G0, tau0=1.0)
        try:
            path0, len0 = modulated_shortest_path(G0, start, goal)
        except Exception:
            continue
        mid = path0[len(path0) // 2]
        cy, cx, r = mid[0], mid[1], max(size // 20, 6)
        free1, blocked = apply_dynamic_obstacle(free, cy, cx, r)
        if not blocked.any():
            continue

        _, t_full = full_reskeletonize(free1)
        _, t_local = local_reskeletonize(G0, free1, blocked, pad=max(size // 12, 12))
        full_times[size].append(t_full * 1000)
        lir_times[size].append(t_local * 1000)

        (_, _, t_init), (_, _, t_replan) = dstar_lite_initial_and_replan(
            grid, start, goal, blocked)
        dstar_times[size].append(t_replan * 1000)

# ---------------------------------------------------------------------------
# Part B: overhead vs dynamic-obstacle arrival frequency (LIR only)
# ---------------------------------------------------------------------------
freqs = [1, 2, 4, 8]  # obstacles appearing per 20 rounds
overhead_per_freq = []
grid0 = make_office_environment(size=180, seed=7)
free0 = ~grid0
skel0, dist0 = compute_skeleton(free0)
G_base = skeleton_to_graph(skel0, dist0)

for f in freqs:
    rng = np.random.RandomState(f)
    total_time = 0.0
    G_cur = G_base.copy()
    free_cur = free0.copy()
    n_events = 0
    for round_i in range(20):
        if round_i % max(1, 20 // f) == 0:
            cy, cx = rng.randint(20, 160, size=2)
            r = 6
            free_cur, blocked = apply_dynamic_obstacle(free_cur, cy, cx, r)
            if blocked.any():
                t0 = time.perf_counter()
                G_cur, _ = local_reskeletonize(G_cur, free_cur, blocked, pad=18)
                total_time += time.perf_counter() - t0
                n_events += 1
    overhead_per_freq.append(total_time * 1000 / max(n_events, 1))

# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.0))
ax = axes[0]
full_means = [np.mean(full_times[s]) for s in sizes]
lir_means = [np.mean(lir_times[s]) for s in sizes]
dstar_means = [np.mean(dstar_times[s]) for s in sizes]
full_stds = [np.std(full_times[s]) for s in sizes]
lir_stds = [np.std(lir_times[s]) for s in sizes]
dstar_stds = [np.std(dstar_times[s]) for s in sizes]

x = np.arange(len(sizes))
w = 0.25
ax.bar(x - w, full_means, w, yerr=full_stds, label='Full re-skeletonization',
       color='#d62728', alpha=0.85, capsize=3)
ax.bar(x, lir_means, w, yerr=lir_stds, label='Proposed LIR',
       color='#1f77b4', alpha=0.85, capsize=3)
ax.bar(x + w, dstar_means, w, yerr=dstar_stds, label="D* Lite (grid, incremental)",
       color='#2ca02c', alpha=0.85, capsize=3)
ax.set_xticks(x)
ax.set_xticklabels([f'{s}\u00d7{s}' for s in sizes])
ax.set_ylabel('Replanning time (ms)')
ax.set_yscale('log')
ax.set_title('(a) Replanning cost after a new obstacle', fontsize=10)
ax.legend(fontsize=7.5)
ax.grid(alpha=0.25, axis='y')

ax2 = axes[1]
ax2.plot(freqs, overhead_per_freq, marker='o', color='#9467bd', lw=1.8)
ax2.set_xlabel('Obstacle events per 20 rounds')
ax2.set_ylabel('Mean LIR update time per event (ms)')
ax2.set_title('(b) LIR overhead vs. obstacle arrival frequency', fontsize=10)
ax2.grid(alpha=0.25)

fig.suptitle('Dynamic replanning cost: LIR vs. full re-skeletonization vs. D* Lite, '
             'and LIR overhead under varying obstacle frequency', fontsize=10, y=1.03)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig10_dstarlite_frequency.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig10_dstarlite_frequency.png', bbox_inches='tight', dpi=300)

print("=== D* Lite / LIR / full comparison ===")
for s in sizes:
    print(s, 'full=%.2fms' % np.mean(full_times[s]), 'LIR=%.2fms' % np.mean(lir_times[s]),
          'D*Lite=%.2fms' % np.mean(dstar_times[s]))
print("=== obstacle frequency overhead (ms/event) ===")
for f, o in zip(freqs, overhead_per_freq):
    print(f, o)
print("fig10 done")

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from plot_style import apply_style, COLORS

apply_style()

with open('/home/claude/smsn/SSF_Code_Results/simulation_code/multirobot_metrics_results.json') as f:
    results = json.load(f)

robot_counts = [5, 10, 20, 40]
conditions = ['SSF (proposed, gamma=0.6)', 'No congestion (gamma=0)', 'Frozen pheromone']
labels = ['SSF (proposed)', 'No congestion ($\\gamma=0$)', 'Frozen pheromone']
colors = [COLORS['blue'], COLORS['orange'], COLORS['gray']]

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2))

metrics = [
    ('max_occupancy', '(a) Peak edge occupancy\n(max simultaneous robots on one edge)'),
    ('makespan', '(b) Makespan\n(slowest robot\'s path length, px)'),
    ('collision_risk_rate', '(c) Collision-risk rate\n(fraction of robots on an over-capacity edge)'),
]

for ax, (key, title) in zip(axes, metrics):
    for cond, label, color in zip(conditions, labels, colors):
        means = [results[f"{n}_{cond}"][key][0] for n in robot_counts]
        stds = [results[f"{n}_{cond}"][key][1] for n in robot_counts]
        if key == 'collision_risk_rate':
            means = [100 * m for m in means]
            stds = [100 * s for s in stds]
        ax.errorbar(robot_counts, means, yerr=stds, marker='o', color=color,
                    label=label, capsize=3, lw=1.8)
    ax.set_xlabel('Number of concurrent robots')
    ax.set_title(title, fontsize=9.5)
    ax.grid(alpha=0.25)

axes[0].set_ylabel('Peak simultaneous edge occupancy')
axes[1].set_ylabel('Makespan (px)')
axes[2].set_ylabel('Collision-risk rate (%)')
axes[0].legend(fontsize=7.5, loc='upper left')

fig.suptitle('Peak congestion and makespan both show a growing SSF advantage as robot '
             'density increases, even though a single congestion-count threshold '
             '(Table 4) does not capture this clearly', fontsize=9.5, y=1.05)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig_multirobot_metrics.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig_multirobot_metrics.png', bbox_inches='tight', dpi=300)
print("multirobot metrics figure done")

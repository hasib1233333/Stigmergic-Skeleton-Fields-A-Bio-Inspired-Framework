"""
Stigmergic Skeleton Field (SSF) core algorithm:
  - pheromone-modulated shortest paths over the skeleton graph
  - deposition / evaporation dynamics (artificial-life stigmergy)
  - congestion-aware edge cost (ant-traffic inspired)
  - localized incremental re-skeletonization (LIR) on dynamic obstacles
"""
import numpy as np
import networkx as nx
import time
from scipy.spatial import cKDTree
from env_utils import compute_skeleton, skeleton_to_graph, nearest_node


def init_pheromone(G, tau0=1.0):
    for u, v in G.edges:
        G[u][v]['tau'] = tau0
        G[u][v]['usage'] = 0


def edge_cost(G, u, v, alpha=1.0, beta=2.0, gamma=0.6, kappa=6.0):
    """Effective traversal cost of edge (u,v):
    base geometric length, discounted by pheromone^alpha, penalized by
    congestion (usage) and inversely by clearance^beta (favors wide corridors)."""
    e = G[u][v]
    length = e['weight']
    tau = max(e['tau'], 1e-3)
    clearance = max(e.get('clearance', 1.0), 0.5)
    usage = e.get('usage', 0)
    congestion_penalty = 1.0 + gamma * (usage / kappa) ** 2
    return (length * congestion_penalty) / (tau ** alpha * clearance ** (beta / 10.0))


def modulated_shortest_path(G, s, t, **kw):
    def w(u, v, d):
        return edge_cost(G, u, v, **kw)
    return nx.shortest_path(G, s, t, weight=w), nx.shortest_path_length(G, s, t, weight=w)


def deposit_and_evaporate(G, paths, rho=0.15, Q=8.0, usage_decay=0.5):
    for u, v in G.edges:
        G[u][v]['tau'] *= (1.0 - rho)
        G[u][v]['tau'] = max(G[u][v]['tau'], 0.05)
        # usage is an exponentially-smoothed instantaneous congestion signal,
        # not an unbounded accumulator, so it tracks current traffic only.
        G[u][v]['usage'] *= usage_decay
    for path, length in paths:
        deposit = Q / max(length, 1e-3)
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            G[u][v]['tau'] += deposit
            G[u][v]['usage'] = G[u][v].get('usage', 0) + 1


def run_ssf_episode(G, requests, alpha=1.0, beta=2.0, gamma=0.6, kappa=6.0):
    """requests: list of (start_node, goal_node). Returns realized paths & lengths."""
    results = []
    for s, t in requests:
        try:
            path, length = modulated_shortest_path(G, s, t, alpha=alpha, beta=beta,
                                                     gamma=gamma, kappa=kappa)
            results.append((path, length))
        except nx.NetworkXNoPath:
            continue
    return results


def geometric_path_length(G, path):
    return sum(G[path[i]][path[i + 1]]['weight'] for i in range(len(path) - 1))


# ---------------------------------------------------------------------------
# Localized Incremental Re-skeletonization (LIR)
# ---------------------------------------------------------------------------
def apply_dynamic_obstacle(free_mask, cy, cx, r):
    yy, xx = np.ogrid[:free_mask.shape[0], :free_mask.shape[1]]
    blocked = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
    new_mask = free_mask & (~blocked)
    return new_mask, blocked


def full_reskeletonize(free_mask):
    t0 = time.perf_counter()
    skel, dist = compute_skeleton(free_mask)
    G = skeleton_to_graph(skel, dist)
    t1 = time.perf_counter()
    return G, (t1 - t0)


def _box_of(blocked_region, pad, shape):
    ys, xs = np.nonzero(blocked_region)
    H, W = shape
    y0, y1 = max(ys.min() - pad, 0), min(ys.max() + pad, H)
    x0, x1 = max(xs.min() - pad, 0), min(xs.max() + pad, W)
    return y0, y1, x0, x1


def _inside(n, box):
    y0, y1, x0, x1 = box
    return y0 <= n[0] < y1 and x0 <= n[1] < x1


def _find_ports(G_old, box):
    """A 'port' is a point where a retained (outside-the-box) skeleton
    edge used to cross into the region about to be recomputed. Each
    port pairs the retained node that must stay connected with the
    exact pixel (from the edge's stored polyline) where the corridor
    enters the box, so the freshly computed local skeleton can be
    stitched back onto the retained graph there instead of being left
    as a disconnected island (the bug this function exists to fix)."""
    ports = []
    for u, v, data in G_old.edges(data=True):
        u_in, v_in = _inside(u, box), _inside(v, box)
        if u_in == v_in:
            continue  # fully inside (will be recomputed) or fully outside
        outside_node = v if u_in else u
        path = data.get('path')
        if not path:
            ports.append((outside_node, outside_node))
            continue
        seq = path if path[0] == outside_node else path[::-1]
        port_pixel = seq[-1]
        for p in seq:
            port_pixel = p
            if _inside(p, box):
                break
        ports.append((outside_node, port_pixel))
    return ports


def _split_edge_at(G, u, v, split_pixel, dist_sub, y0, x0):
    """Split edge (u,v), whose stored 'path' polyline contains
    split_pixel, into two edges meeting at a new node at split_pixel.
    Returns the new node. Used to stitch a port onto the interior of a
    local skeleton branch, not just onto its sparse junction nodes --
    which matters because junction nodes can be tens of pixels apart
    while the skeleton's own raster pixels (which this is snapped to)
    are almost always within a few pixels of where a retained corridor
    actually crosses the boundary."""
    data = G[u][v]
    path = data['path']
    tau = data.get('tau', 1.0)
    usage = data.get('usage', 0)
    idx = path.index(split_pixel)
    path_a = path[:idx + 1]
    path_b = path[idx:]

    def seg_len(p):
        return sum(np.hypot(p[i + 1][0] - p[i][0], p[i + 1][1] - p[i][1])
                   for i in range(len(p) - 1))

    G.remove_edge(u, v)
    sy, sx = split_pixel[0] - y0, split_pixel[1] - x0
    sy = min(max(sy, 0), dist_sub.shape[0] - 1)
    sx = min(max(sx, 0), dist_sub.shape[1] - 1)
    G.add_node(split_pixel, pos=(split_pixel[1], split_pixel[0]),
               clearance=float(dist_sub[sy, sx]))
    if len(path_a) >= 2:
        G.add_edge(u, split_pixel, weight=max(seg_len(path_a), 0.5),
                    clearance=data.get('clearance', 1.0), path=path_a,
                    tau=tau, usage=usage)
    if len(path_b) >= 2:
        G.add_edge(split_pixel, v, weight=max(seg_len(path_b), 0.5),
                    clearance=data.get('clearance', 1.0), path=path_b,
                    tau=tau, usage=usage)
    return split_pixel


def _attempt_local_reskeletonize(G_old, free_mask, blocked_region, pad, snap_tol=6.0):
    """One attempt at LIR with an explicit boundary-stitching step.
    Ports are snapped to the nearest pixel of the freshly computed
    local skeleton (splitting whichever local edge that pixel lies on
    to create a genuine interface node there), not to the sparse set of
    local junction nodes -- snapping to junctions alone left most ports
    tens of pixels from anything to attach to and made LIR fall back to
    full re-skeletonization on the large majority of trials. Returns
    None (signalling the caller to retry with a larger pad) if any port
    still cannot be reconnected within snap_tol pixels."""
    t0 = time.perf_counter()
    box = _box_of(blocked_region, pad, free_mask.shape)
    y0, y1, x0, x1 = box

    ports = _find_ports(G_old, box)
    nodes_to_remove = [n for n in G_old.nodes if _inside(n, box)]

    sub = free_mask[y0:y1, x0:x1]
    skel_sub, dist_sub = compute_skeleton(sub)
    G_sub = skeleton_to_graph(skel_sub, dist_sub)
    mapping = {n: (n[0] + y0, n[1] + x0) for n in G_sub.nodes}
    G_sub = nx.relabel_nodes(G_sub, mapping)
    for _, _, data in G_sub.edges(data=True):
        if 'path' in data:
            data['path'] = [(p[0] + y0, p[1] + x0) for p in data['path']]

    G_new = G_old.copy()
    G_new.remove_nodes_from(nodes_to_remove)
    for n, d in G_sub.nodes(data=True):
        G_new.add_node(n, **d)
    for u, v, d in G_sub.edges(data=True):
        G_new.add_edge(u, v, **d)
        if 'tau' not in G_new[u][v]:
            G_new[u][v]['tau'] = 1.0
            G_new[u][v]['usage'] = 0

    # dense candidate set: every raster pixel of the local skeleton,
    # each tagged with the (u, v) edge it currently belongs to (or None
    # if it is itself a node), so a port can snap onto the *interior*
    # of a local branch and split it there, not just onto a sparse
    # junction node. Rebuilt after every split (several ports commonly
    # land on the same original branch, and after the first split that
    # branch no longer exists as a single edge, so a stale mapping
    # would silently skip every subsequent port on it).
    local_node_set = set(G_sub.nodes)

    def rebuild_candidates():
        owner = {}
        for n in local_node_set:
            if n in G_new.nodes:
                owner[n] = None
        for u, v, data in G_new.edges(data=True):
            if u in local_node_set or v in local_node_set:
                for p in data.get('path', []):
                    owner.setdefault(p, (u, v))
        pts = list(owner.keys())
        tree = cKDTree(np.array(pts)) if pts else None
        return owner, pts, tree

    # process ports one at a time, rebuilding the candidate set after
    # every split; the local box is small (at most a few hundred
    # skeleton pixels) so this stays cheap, and it is the simplest way
    # to be correct when several ports land on the same original branch
    n_connected = 0
    for outside_node, port_pixel in ports:
        owner_map, cand_pts, tree = rebuild_candidates()
        if tree is None:
            continue
        dist, idx = tree.query(port_pixel)
        if dist > snap_tol:
            continue
        snap_pixel = cand_pts[idx]
        edge_owner = owner_map[snap_pixel]
        if edge_owner is not None and snap_pixel not in G_new.nodes:
            u, v = edge_owner
            snap_pixel = _split_edge_at(G_new, u, v, snap_pixel, dist_sub, y0, x0)
            local_node_set.add(snap_pixel)
        if outside_node not in G_new.nodes or snap_pixel not in G_new.nodes:
            continue
        w = max(float(np.hypot(outside_node[0] - snap_pixel[0],
                                outside_node[1] - snap_pixel[1])), 0.5)
        if not G_new.has_edge(outside_node, snap_pixel):
            G_new.add_edge(outside_node, snap_pixel, weight=w,
                            clearance=1.0, tau=1.0, usage=0)
        n_connected += 1

    t1 = time.perf_counter()
    diagnostics = {
        'fallback': False, 'pad_used': pad,
        'ports_total': len(ports), 'ports_connected': n_connected,
    }
    if len(ports) > 0 and n_connected < len(ports):
        return None  # unstitched port(s): caller should retry / fall back
    return G_new, (t1 - t0), diagnostics


def local_reskeletonize(G_old, free_mask, blocked_region, pad=18,
                         max_retries=2, snap_tol=6.0, verify_connectivity=True):
    """Recompute the skeleton only within a bounding box around the
    change, then explicitly stitch the freshly computed local subgraph
    to the retained global skeleton via boundary interface edges
    (_find_ports / _attempt_local_reskeletonize), verifying that every
    retained corridor that used to cross into the box is reconnected.
    If stitching fails (a port cannot be matched within snap_tol pixels
    of any node in the new local skeleton), retries with a doubled
    padding margin, and finally falls back to full re-skeletonization --
    so LIR is either verifiably spliced into one topology, or explicitly
    not used. Returns (graph, elapsed_time, diagnostics)."""
    cur_pad = pad
    for _ in range(max_retries + 1):
        result = _attempt_local_reskeletonize(G_old, free_mask, blocked_region,
                                               cur_pad, snap_tol=snap_tol)
        if result is not None:
            G_new, dt, diagnostics = result
            if verify_connectivity:
                before_components = nx.number_connected_components(G_old)
                after_components = nx.number_connected_components(G_new)
                diagnostics['components_before'] = before_components
                diagnostics['components_after'] = after_components
                diagnostics['connectivity_preserved'] = (after_components <= before_components)
                if not diagnostics['connectivity_preserved']:
                    cur_pad *= 2
                    continue
            return G_new, dt, diagnostics
        cur_pad *= 2
    t0 = time.perf_counter()
    G_full, _ = full_reskeletonize(free_mask)
    # the fallback graph is entirely freshly computed and would
    # otherwise carry no pheromone state at all; initialize it, then
    # restore historical tau/usage on any edge that also existed in
    # G_old (same endpoints), so a fallback does not silently erase
    # accumulated stigmergic state on the untouched part of the map
    init_pheromone(G_full, tau0=1.0)
    for u, v in G_full.edges:
        if G_old.has_edge(u, v):
            G_full[u][v]['tau'] = G_old[u][v].get('tau', 1.0)
            G_full[u][v]['usage'] = G_old[u][v].get('usage', 0)
    dt = time.perf_counter() - t0
    diagnostics = {'fallback': True, 'pad_used': None, 'ports_total': 0,
                    'ports_connected': 0, 'connectivity_preserved': True}
    return G_full, dt, diagnostics


# ---------------------------------------------------------------------------
# Baselines
# ---------------------------------------------------------------------------
def grid_graph_from_mask(free_mask, step=1):
    """Full occupancy-grid graph (used by the raw-grid ACO baseline)."""
    H, W = free_mask.shape
    G = nx.Graph()
    ys, xs = np.nonzero(free_mask)
    free_pts = set(zip(ys.tolist(), xs.tolist()))
    for y in range(0, H, step):
        for x in range(0, W, step):
            if (y, x) not in free_pts:
                continue
            for dy, dx in [(0, step), (step, 0), (step, step), (step, -step)]:
                ny, nx_ = y + dy, x + dx
                if 0 <= ny < H and 0 <= nx_ < W and (ny, nx_) in free_pts:
                    w = np.hypot(dy, dx)
                    G.add_edge((y, x), (ny, nx_), weight=w, tau=1.0, usage=0, clearance=1.0)
    return G


def rrt_star(free_mask, start, goal, n_iter=1500, step=6.0, seed=0):
    """Minimal RRT* implementation (single-robot, no stigmergy) used as a
    non-coordinated baseline planner."""
    rng = np.random.RandomState(seed)
    H, W = free_mask.shape

    def collision_free(p, q):
        n = int(np.hypot(q[0] - p[0], q[1] - p[1]) / 1.5) + 1
        for i in range(n + 1):
            y = int(p[0] + (q[0] - p[0]) * i / n)
            x = int(p[1] + (q[1] - p[1]) * i / n)
            if not (0 <= y < H and 0 <= x < W) or free_mask[y, x]:
                return False
        return True

    nodes = [start]
    parent = {0: -1}
    cost = {0: 0.0}
    for _ in range(n_iter):
        if rng.rand() < 0.08:
            sample = goal
        else:
            sample = (rng.uniform(0, H), rng.uniform(0, W))
        d = [np.hypot(n0[0] - sample[0], n0[1] - sample[1]) for n0 in nodes]
        i_near = int(np.argmin(d))
        near = nodes[i_near]
        dist = np.hypot(sample[0] - near[0], sample[1] - near[1])
        if dist < 1e-6:
            continue
        new = (near[0] + (sample[0] - near[0]) / dist * min(step, dist),
               near[1] + (sample[1] - near[1]) / dist * min(step, dist))
        if not (0 <= new[0] < H and 0 <= new[1] < W):
            continue
        if free_mask[int(new[0]), int(new[1])]:
            continue
        if not collision_free(near, new):
            continue
        new_cost = cost[i_near] + np.hypot(new[0] - near[0], new[1] - near[1])
        nodes.append(new)
        idx = len(nodes) - 1
        parent[idx] = i_near
        cost[idx] = new_cost
        # rewire within radius
        radius = 12.0
        for j, n0 in enumerate(nodes[:-1]):
            if np.hypot(n0[0] - new[0], n0[1] - new[1]) < radius and collision_free(new, n0):
                c = new_cost + np.hypot(n0[0] - new[0], n0[1] - new[1])
                if c < cost[j]:
                    parent[j] = idx
                    cost[j] = c
        if np.hypot(new[0] - goal[0], new[1] - goal[1]) < step:
            if collision_free(new, goal):
                nodes.append(goal)
                parent[len(nodes) - 1] = idx
                cost[len(nodes) - 1] = new_cost + np.hypot(new[0] - goal[0], new[1] - goal[1])
                gi = len(nodes) - 1
                path = [nodes[gi]]
                while parent[gi] != -1:
                    gi = parent[gi]
                    path.append(nodes[gi])
                return path[::-1], cost[len(nodes) - 1]
    return None, np.inf

"""
Stigmergic Skeleton Field (SSF) core algorithm:
  - pheromone-modulated shortest paths over the skeleton graph
  - deposition / evaporation dynamics (artificial-life stigmergy)
  - congestion-aware edge cost (ant-traffic inspired)
  - localized incremental re-skeletonization (LIR) on dynamic obstacles
"""
import numpy as np
import networkx as nx
import time
from env_utils import compute_skeleton, skeleton_to_graph, nearest_node


def init_pheromone(G, tau0=1.0):
    for u, v in G.edges:
        G[u][v]['tau'] = tau0
        G[u][v]['usage'] = 0


def edge_cost(G, u, v, alpha=1.0, beta=2.0, gamma=0.6, kappa=6.0):
    """Effective traversal cost of edge (u,v):
    base geometric length, discounted by pheromone^alpha, penalized by
    congestion (usage) and inversely by clearance^beta (favors wide corridors)."""
    e = G[u][v]
    length = e['weight']
    tau = max(e['tau'], 1e-3)
    clearance = max(e.get('clearance', 1.0), 0.5)
    usage = e.get('usage', 0)
    congestion_penalty = 1.0 + gamma * (usage / kappa) ** 2
    return (length * congestion_penalty) / (tau ** alpha * clearance ** (beta / 10.0))


def modulated_shortest_path(G, s, t, **kw):
    def w(u, v, d):
        return edge_cost(G, u, v, **kw)
    return nx.shortest_path(G, s, t, weight=w), nx.shortest_path_length(G, s, t, weight=w)


def deposit_and_evaporate(G, paths, rho=0.15, Q=8.0, usage_decay=0.5):
    for u, v in G.edges:
        G[u][v]['tau'] *= (1.0 - rho)
        G[u][v]['tau'] = max(G[u][v]['tau'], 0.05)
        # usage is an exponentially-smoothed instantaneous congestion signal,
        # not an unbounded accumulator, so it tracks current traffic only.
        G[u][v]['usage'] *= usage_decay
    for path, length in paths:
        deposit = Q / max(length, 1e-3)
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            G[u][v]['tau'] += deposit
            G[u][v]['usage'] = G[u][v].get('usage', 0) + 1


def run_ssf_episode(G, requests, alpha=1.0, beta=2.0, gamma=0.6, kappa=6.0):
    """requests: list of (start_node, goal_node). Returns realized paths & lengths."""
    results = []
    for s, t in requests:
        try:
            path, length = modulated_shortest_path(G, s, t, alpha=alpha, beta=beta,
                                                     gamma=gamma, kappa=kappa)
            results.append((path, length))
        except nx.NetworkXNoPath:
            continue
    return results


def geometric_path_length(G, path):
    return sum(G[path[i]][path[i + 1]]['weight'] for i in range(len(path) - 1))


# ---------------------------------------------------------------------------
# Localized Incremental Re-skeletonization (LIR)
# ---------------------------------------------------------------------------
def apply_dynamic_obstacle(free_mask, cy, cx, r):
    yy, xx = np.ogrid[:free_mask.shape[0], :free_mask.shape[1]]
    blocked = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
    new_mask = free_mask & (~blocked)
    return new_mask, blocked


def full_reskeletonize(free_mask):
    t0 = time.perf_counter()
    skel, dist = compute_skeleton(free_mask)
    G = skeleton_to_graph(skel, dist)
    t1 = time.perf_counter()
    return G, (t1 - t0)


def local_reskeletonize(G_old, free_mask, blocked_region, pad=18):
    """Recompute the skeleton only within a bounding box around the change,
    then splice the local graph back into the global graph, preserving
    pheromone state on unaffected edges."""
    t0 = time.perf_counter()
    ys, xs = np.nonzero(blocked_region)
    y0, y1 = max(ys.min() - pad, 0), min(ys.max() + pad, free_mask.shape[0])
    x0, x1 = max(xs.min() - pad, 0), min(xs.max() + pad, free_mask.shape[1])

    sub = free_mask[y0:y1, x0:x1]
    skel_sub, dist_sub = compute_skeleton(sub)
    G_sub = skeleton_to_graph(skel_sub, dist_sub)

    # shift local node coordinates back to global frame
    mapping = {n: (n[0] + y0, n[1] + x0) for n in G_sub.nodes}
    G_sub = nx.relabel_nodes(G_sub, mapping)

    G_new = G_old.copy()
    # drop nodes/edges that fall inside the affected bounding box
    to_remove = [n for n in G_new.nodes if y0 <= n[0] < y1 and x0 <= n[1] < x1]
    G_new.remove_nodes_from(to_remove)
    # add freshly computed local subgraph
    for n, d in G_sub.nodes(data=True):
        G_new.add_node(n, **d)
    for u, v, d in G_sub.edges(data=True):
        G_new.add_edge(u, v, **d)
        if 'tau' not in G_new[u][v]:
            G_new[u][v]['tau'] = 1.0
            G_new[u][v]['usage'] = 0
    t1 = time.perf_counter()
    return G_new, (t1 - t0)


# ---------------------------------------------------------------------------
# Baselines
# ---------------------------------------------------------------------------
def grid_graph_from_mask(free_mask, step=1):
    """Full occupancy-grid graph (used by the raw-grid ACO baseline)."""
    H, W = free_mask.shape
    G = nx.Graph()
    ys, xs = np.nonzero(free_mask)
    free_pts = set(zip(ys.tolist(), xs.tolist()))
    for y in range(0, H, step):
        for x in range(0, W, step):
            if (y, x) not in free_pts:
                continue
            for dy, dx in [(0, step), (step, 0), (step, step), (step, -step)]:
                ny, nx_ = y + dy, x + dx
                if 0 <= ny < H and 0 <= nx_ < W and (ny, nx_) in free_pts:
                    w = np.hypot(dy, dx)
                    G.add_edge((y, x), (ny, nx_), weight=w, tau=1.0, usage=0, clearance=1.0)
    return G


def rrt_star(free_mask, start, goal, n_iter=1500, step=6.0, seed=0):
    """Minimal RRT* implementation (single-robot, no stigmergy) used as a
    non-coordinated baseline planner."""
    rng = np.random.RandomState(seed)
    H, W = free_mask.shape

    def collision_free(p, q):
        n = int(np.hypot(q[0] - p[0], q[1] - p[1]) / 1.5) + 1
        for i in range(n + 1):
            y = int(p[0] + (q[0] - p[0]) * i / n)
            x = int(p[1] + (q[1] - p[1]) * i / n)
            if not (0 <= y < H and 0 <= x < W) or free_mask[y, x]:
                return False
        return True

    nodes = [start]
    parent = {0: -1}
    cost = {0: 0.0}
    for _ in range(n_iter):
        if rng.rand() < 0.08:
            sample = goal
        else:
            sample = (rng.uniform(0, H), rng.uniform(0, W))
        d = [np.hypot(n0[0] - sample[0], n0[1] - sample[1]) for n0 in nodes]
        i_near = int(np.argmin(d))
        near = nodes[i_near]
        dist = np.hypot(sample[0] - near[0], sample[1] - near[1])
        if dist < 1e-6:
            continue
        new = (near[0] + (sample[0] - near[0]) / dist * min(step, dist),
               near[1] + (sample[1] - near[1]) / dist * min(step, dist))
        if not (0 <= new[0] < H and 0 <= new[1] < W):
            continue
        if free_mask[int(new[0]), int(new[1])]:
            continue
        if not collision_free(near, new):
            continue
        new_cost = cost[i_near] + np.hypot(new[0] - near[0], new[1] - near[1])
        nodes.append(new)
        idx = len(nodes) - 1
        parent[idx] = i_near
        cost[idx] = new_cost
        # rewire within radius
        radius = 12.0
        for j, n0 in enumerate(nodes[:-1]):
            if np.hypot(n0[0] - new[0], n0[1] - new[1]) < radius and collision_free(new, n0):
                c = new_cost + np.hypot(n0[0] - new[0], n0[1] - new[1])
                if c < cost[j]:
                    parent[j] = idx
                    cost[j] = c
        if np.hypot(new[0] - goal[0], new[1] - goal[1]) < step:
            if collision_free(new, goal):
                nodes.append(goal)
                parent[len(nodes) - 1] = idx
                cost[len(nodes) - 1] = new_cost + np.hypot(new[0] - goal[0], new[1] - goal[1])
                gi = len(nodes) - 1
                path = [nodes[gi]]
                while parent[gi] != -1:
                    gi = parent[gi]
                    path.append(nodes[gi])
                return path[::-1], cost[len(nodes) - 1]
    return None, np.inf

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from plot_style import apply_style, COLORS

apply_style()

fig, ax = plt.subplots(figsize=(10.5, 8.0))
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis('off')


def box(cx, cy, w, h, text, color, fontsize=8.5, textcolor='black', fontweight='normal'):
    b = FancyBboxPatch((cx - w / 2, cy - h / 2), w, h,
                        boxstyle="round,pad=0.6,rounding_size=2",
                        linewidth=1.3, edgecolor=color, facecolor=color, alpha=0.18)
    ax.add_patch(b)
    b2 = FancyBboxPatch((cx - w / 2, cy - h / 2), w, h,
                         boxstyle="round,pad=0.6,rounding_size=2",
                         linewidth=1.3, edgecolor=color, facecolor='none')
    ax.add_patch(b2)
    ax.text(cx, cy, text, ha='center', va='center', fontsize=fontsize,
             color=textcolor, fontweight=fontweight, wrap=True)
    return (cx, cy, w, h)


def arrow(b_from, b_to, color='0.3', style='-|>', connectionstyle='arc3,rad=0.0',
          lw=1.4, label=None, label_offset=(0, 2.5)):
    x0, y0, w0, h0 = b_from
    x1, y1, w1, h1 = b_to
    # connect from nearest edge
    if abs(x1 - x0) > abs(y1 - y0):
        p0 = (x0 + w0 / 2 * (1 if x1 > x0 else -1), y0)
        p1 = (x1 - w1 / 2 * (1 if x1 > x0 else -1), y1)
    else:
        p0 = (x0, y0 - h0 / 2 * (1 if y1 < y0 else -1))
        p1 = (x1, y1 + h1 / 2 * (1 if y1 < y0 else -1))
    a = FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=14,
                         color=color, lw=lw, connectionstyle=connectionstyle,
                         shrinkA=2, shrinkB=2, zorder=1)
    ax.add_patch(a)
    if label:
        mx, my = (p0[0] + p1[0]) / 2 + label_offset[0], (p0[1] + p1[1]) / 2 + label_offset[1]
        ax.text(mx, my, label, ha='center', va='center', fontsize=7, color=color, style='italic')


# --- Boxes ---
b_input = box(50, 94, 46, 8, "Occupancy map / sensing input", COLORS['gray'], fontweight='bold')

b_skel = box(24, 80, 38, 9, "Medial-axis skeleton\nextraction (Sec. 4.1)", COLORS['blue'])
b_lir = box(76, 80, 38, 9, "LIR: local repair +\nconnectivity verification\n(Sec. 4.3, Alg. 1)", COLORS['purple'])

b_field = box(50, 63, 56, 11, "Shared pheromone field\n$\\tau_{uv}$, usage$_{uv}$  (Eq. 1--3)\n(read/written by every robot; no\nrobot-to-robot communication)",
              COLORS['orange'], fontsize=8.3, fontweight='bold')

b_plan1 = box(16, 45, 22, 9, "Robot 1\ncongestion-aware\nplanner (Eq. 1)", COLORS['green'], fontsize=7.6)
b_plan2 = box(42, 45, 22, 9, "Robot 2\ncongestion-aware\nplanner (Eq. 1)", COLORS['green'], fontsize=7.6)
b_plan3 = box(68, 45, 22, 9, "...", COLORS['green'], fontsize=9)
b_plan4 = box(90, 45, 16, 9, "Robot $N$\nplanner", COLORS['green'], fontsize=7.6)

b_exec = box(50, 28, 50, 9, "Robot path execution\n(Sec. 6.12: continuous differential-drive control)",
             COLORS['gray'], fontsize=8.2)

b_change = box(50, 12, 46, 9, "Environment change detected?\n(new/removed obstacle)", COLORS['red'], fontsize=8.2)

# --- Arrows (forward flow) ---
arrow(b_input, b_skel, color='0.3')
arrow(b_skel, b_field, color=COLORS['blue'], label='initial graph')
arrow(b_field, b_plan1, color=COLORS['orange'])
arrow(b_field, b_plan2, color=COLORS['orange'])
arrow(b_field, b_plan3, color=COLORS['orange'])
arrow(b_field, b_plan4, color=COLORS['orange'])
arrow(b_plan1, b_exec, color=COLORS['green'])
arrow(b_plan2, b_exec, color=COLORS['green'])
arrow(b_plan3, b_exec, color=COLORS['green'])
arrow(b_plan4, b_exec, color=COLORS['green'])
arrow(b_exec, b_change, color='0.3')

# --- Feedback arrows ---
arrow(b_change, b_lir, color=COLORS['purple'], connectionstyle='arc3,rad=0.3',
      label='yes', label_offset=(18, 8))
arrow(b_lir, b_field, color=COLORS['purple'], connectionstyle='arc3,rad=-0.25',
      label='verified splice\n(else fallback)')
arrow(b_change, b_field, color=COLORS['red'], connectionstyle='arc3,rad=-0.55',
      label='no: deposit/evaporate\n(Eq. 2-3) from realized paths',
      label_offset=(30, 0))

fig.suptitle("SSF system architecture: information flow between skeleton extraction,\n"
             "the shared pheromone field, per-robot planners, and LIR's repair loop",
             fontsize=10, y=0.985)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig_architecture.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig_architecture.png', bbox_inches='tight', dpi=300)
print("architecture figure done")

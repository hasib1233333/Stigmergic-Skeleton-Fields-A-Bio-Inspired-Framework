import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from env_utils import (make_warehouse_environment, make_random_fill_environment,
                        compute_skeleton, skeleton_to_graph)
from plot_style import apply_style, COLORS

apply_style()

envs = {
    "(a) Warehouse (16-cell rooms)": make_warehouse_environment(size=140, seed=6, room_size=16),
    "(b) Random-fill (20% occupied)": make_random_fill_environment(size=140, seed=7, fill_pct=20),
}

fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.6))
for ax, (name, grid) in zip(axes, envs.items()):
    free = ~grid
    skel, dist = compute_skeleton(free)
    G = skeleton_to_graph(skel, dist)
    ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.9)
    ys, xs = np.nonzero(skel)
    ax.scatter(xs, ys, s=0.3, c=COLORS['blue'], linewidths=0, alpha=0.8)
    deg3 = [n for n in G.nodes if G.degree[n] >= 3]
    if deg3:
        yj, xj = zip(*deg3)
        ax.scatter(xj, yj, s=6, c=COLORS['orange'], zorder=5)
    ax.set_title(f"{name}\n({G.number_of_nodes()} nodes)", fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])
    ax.grid(False)
    for s in ax.spines.values():
        s.set_visible(False)

fig.suptitle("Additional environments regenerated using the room-size and\n"
             "occupancy-percentage categories of the standard grid-pathfinding\n"
             "benchmark suite", fontsize=10, y=1.08)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig_benchmark_envs.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig_benchmark_envs.png', bbox_inches='tight', dpi=300)
print("benchmark envs figure done")

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import cm
from env_utils import (make_office_environment, make_cluttered_environment,
                        make_maze_environment, compute_skeleton, skeleton_to_graph)

plt.rcParams.update({
    "font.family": "serif", "font.size": 10.5, "axes.linewidth": 0.8,
    "figure.dpi": 300,
})

envs = {
    "(a) Office": make_office_environment(size=140, seed=1),
    "(b) Cluttered": make_cluttered_environment(size=140, seed=2),
    "(c) Maze": make_maze_environment(size=140, seed=3),
}

fig, axes = plt.subplots(1, 3, figsize=(10.8, 3.9))
for ax, (name, grid) in zip(axes, envs.items()):
    free = ~grid
    skel, dist = compute_skeleton(free)
    G = skeleton_to_graph(skel, dist)
    ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.85)
    ys, xs = np.nonzero(skel)
    ax.scatter(xs, ys, s=0.35, c='#d62728', linewidths=0)
    for u, v in G.edges:
        ax.plot([u[1], v[1]], [u[0], v[0]], color='#1f77b4', lw=0.4, alpha=0.35)
    deg1 = [n for n in G.nodes if G.degree[n] >= 3]
    if deg1:
        yj, xj = zip(*deg1)
        ax.scatter(xj, yj, s=10, c='#2ca02c', zorder=5, label='junction')
    ax.set_title(f"{name}\n({G.number_of_nodes()} nodes, {G.number_of_edges()} edges)", fontsize=9.5)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)

fig.suptitle("Test environments with extracted medial-axis skeleton graphs "
             "(red = skeleton pixels, blue = topology edges, green = junction nodes)",
             fontsize=9.5, y=1.02)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig1_environments.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig1_environments.png', bbox_inches='tight', dpi=300)
print("fig1 done")

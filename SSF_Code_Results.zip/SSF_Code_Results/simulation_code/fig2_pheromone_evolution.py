import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

rng = np.random.RandomState(7)
grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
init_pheromone(G, tau0=1.0)

nodes = list(G.nodes)
n_agents = 24
snapshots_at = [0, 5, 20, 60]
snapshots = {}

for it in range(max(snapshots_at) + 1):
    requests = []
    for _ in range(n_agents):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        requests.append((nodes[s], nodes[t]))
    paths = run_ssf_episode(G, requests)
    deposit_and_evaporate(G, paths, rho=0.12, Q=10.0)
    if it in snapshots_at:
        snapshots[it] = {(u, v): G[u][v]['tau'] for u, v in G.edges}

fig, axes = plt.subplots(1, 4, figsize=(13.5, 3.9))
all_tau = np.concatenate([list(s.values()) for s in snapshots.values()])
vmax = np.percentile(all_tau, 99)

for ax, it in zip(axes, snapshots_at):
    ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.75)
    segs, vals = [], []
    for (u, v), tau in snapshots[it].items():
        segs.append([(u[1], u[0]), (v[1], v[0])])
        vals.append(tau)
    vals = np.array(vals)
    lc = LineCollection(segs, array=vals, cmap='inferno', linewidths=1.0 + 3.5 * (vals / vmax),
                         norm=plt.Normalize(0, vmax))
    ax.add_collection(lc)
    ax.set_title(f"Iteration {it}", fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)

cbar = fig.colorbar(lc, ax=axes, shrink=0.85, pad=0.01, label='pheromone concentration $\\tau_{ij}$')
fig.suptitle("Emergent stigmergic trail formation on the skeleton graph "
             "(24 concurrent agent requests per iteration)", fontsize=10.5, y=1.03)
plt.savefig('/home/claude/smsn/figs/fig2_pheromone_evolution.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig2_pheromone_evolution.png', bbox_inches='tight', dpi=300)
print("fig2 done")

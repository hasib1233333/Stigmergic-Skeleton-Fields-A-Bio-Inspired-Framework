import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate

plt.rcParams.update({"font.family": "serif", "font.size": 13, "figure.dpi": 300})

rng = np.random.RandomState(7)
grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
init_pheromone(G, tau0=1.0)

nodes = list(G.nodes)
n_agents = 24
snapshots_at = [0, 5, 20, 60]
snapshots = {}

for it in range(max(snapshots_at) + 1):
    requests = []
    for _ in range(n_agents):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        requests.append((nodes[s], nodes[t]))
    paths = run_ssf_episode(G, requests)
    deposit_and_evaporate(G, paths, rho=0.12, Q=10.0)
    if it in snapshots_at:
        snapshots[it] = {(u, v): G[u][v]['tau'] for u, v in G.edges}

fig, axes = plt.subplots(1, 4, figsize=(16.5, 4.6))
all_tau = np.concatenate([list(s.values()) for s in snapshots.values()])
vmax = np.percentile(all_tau, 99)
panel_labels = ['(a)', '(b)', '(c)', '(d)']

for ax, it, lab in zip(axes, snapshots_at, panel_labels):
    # higher-contrast walls: solid dark gray instead of a washed-out
    # translucent overlay, so the corridor structure reads clearly even
    # at small print size
    ax.imshow(grid, cmap='gray_r', origin='upper', vmin=0, vmax=1.6, alpha=1.0)
    segs, vals = [], []
    for (u, v), tau in snapshots[it].items():
        segs.append([(u[1], u[0]), (v[1], v[0])])
        vals.append(tau)
    vals = np.array(vals)
    lc = LineCollection(segs, array=vals, cmap='inferno', linewidths=1.6 + 4.5 * (vals / vmax),
                         norm=plt.Normalize(0, vmax))
    ax.add_collection(lc)
    ax.set_title(f"{lab} Iteration {it}", fontsize=14, fontweight='bold')
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)

cbar = fig.colorbar(lc, ax=axes, shrink=0.9, pad=0.015,
                     label='Pheromone concentration $\\tau_{ij}$')
cbar.ax.tick_params(labelsize=12)
cbar.set_label('Pheromone concentration $\\tau_{ij}$', fontsize=13)
fig.suptitle("Emergent stigmergic trail formation on the skeleton graph "
             "(24 concurrent agent requests per iteration)", fontsize=13.5, y=1.04)
plt.savefig('/home/claude/smsn/figs/fig2_pheromone_evolution.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig2_pheromone_evolution.png', bbox_inches='tight', dpi=300)
print("fig2 done")

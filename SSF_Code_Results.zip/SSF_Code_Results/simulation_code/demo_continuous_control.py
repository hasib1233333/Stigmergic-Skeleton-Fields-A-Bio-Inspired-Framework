import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import networkx as nx
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import (init_pheromone, modulated_shortest_path, deposit_and_evaporate,
                       apply_dynamic_obstacle, local_reskeletonize)
from diffdrive_sim import simulate_fleet, raycast_range

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 150})

# ---------------------------------------------------------------------------
# 1. Build environment + skeleton graph, plan SSF paths for a small fleet
# ---------------------------------------------------------------------------
grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G0 = skeleton_to_graph(skel, dist)
init_pheromone(G0, tau0=1.0)

rng = np.random.RandomState(4)
N_ROBOTS = 6
starts_goals = []
# pick well-separated, reachable pairs on the largest connected component
largest_cc = max(nx.connected_components(G0), key=len)
Gc = G0.subgraph(largest_cc).copy()
init_pheromone(Gc, tau0=1.0)
nodes = list(Gc.nodes)
for _ in range(N_ROBOTS):
    s, t = rng.choice(len(nodes), size=2, replace=False)
    starts_goals.append((nodes[s], nodes[t]))

robot_paths = []
for s, t in starts_goals:
    path, length = modulated_shortest_path(Gc, s, t)
    robot_paths.append(path)
    deposit_and_evaporate(Gc, [(path, length)], rho=0.0, Q=6.0)

# ---------------------------------------------------------------------------
# 2. Choose a dynamic obstacle event: block robot 0's path partway through
#    its route, trigger LIR, and re-plan just that robot's remaining path
# ---------------------------------------------------------------------------
target_robot = int(np.argmax([len(p) for p in robot_paths]))
orig_path = robot_paths[target_robot]
orig_start_pixel = orig_path[0]
orig_goal_pixel = orig_path[-1]

from scipy.ndimage import label as cc_label

r = 7
found_obstacle = False
for frac in (0.5, 0.4, 0.3, 0.6):
    mid_idx = max(1, int(len(orig_path) * frac))
    mid = orig_path[mid_idx]
    # skip candidate points that are already close to the goal, which
    # would leave nothing meaningful to re-plan
    if np.hypot(mid[0] - orig_goal_pixel[0], mid[1] - orig_goal_pixel[1]) < 15:
        continue
    cy, cx = mid[0], mid[1]
    for r_try in (7, 5, 4, 3):
        free_after, blocked = apply_dynamic_obstacle(free, cy, cx, r_try)
        labels, n_comp = cc_label(free_after)
        if labels[orig_start_pixel] == labels[orig_goal_pixel] and labels[orig_start_pixel] != 0:
            r = r_try
            found_obstacle = True
            break
    if found_obstacle:
        break
if not found_obstacle:
    r = 3
    mid = orig_path[len(orig_path) // 2]
    cy, cx = mid[0], mid[1]
    free_after, blocked = apply_dynamic_obstacle(free, cy, cx, r)

G_after, t_lir = local_reskeletonize(Gc, free_after, blocked, pad=18)
init_pheromone(G_after, tau0=1.0)
start_node = nearest_node(G_after, mid[0], mid[1])
goal_node = nearest_node(G_after, *orig_path[-1])
# medial-axis tie-breaking (documented in the manuscript's Discussion)
# can occasionally leave the local patch disconnected from the rest of
# the graph; retry with a larger pad, then fall back to a full
# re-skeletonization so the demo is robust regardless of the outcome
for pad_try in (34, 50):
    if nx.has_path(G_after, start_node, goal_node):
        break
    G_after, t_lir = local_reskeletonize(Gc, free_after, blocked, pad=pad_try)
    init_pheromone(G_after, tau0=1.0)
    start_node = nearest_node(G_after, mid[0], mid[1])
    goal_node = nearest_node(G_after, *orig_path[-1])
if not nx.has_path(G_after, start_node, goal_node):
    from ssf_core import full_reskeletonize
    G_after, t_lir = full_reskeletonize(free_after)
    init_pheromone(G_after, tau0=1.0)
    start_node = nearest_node(G_after, mid[0], mid[1])
    goal_node = nearest_node(G_after, *orig_path[-1])
new_path, new_len = modulated_shortest_path(G_after, start_node, goal_node)
print(f"LIR replan time: {t_lir*1000:.2f} ms, new remaining path length: {new_len:.1f}px")

DT = 0.12
EVENT_STEP = 90  # simulated step at which the obstacle appears

sim = simulate_fleet(
    grid, robot_paths, dt=DT, max_steps=5000,
    dynamic_event={'step': EVENT_STEP, 'mask_after': ~free_after,
                   'robot_idx': target_robot, 'new_path': new_path}
)

print("=== Continuous-motion (pure-pursuit) simulation summary ===")
for i, (ft, mc) in enumerate(zip(sim['finish_time'], sim['min_clearance'])):
    tag = " (LIR replanned mid-flight)" if sim['replanned'][i] else ""
    status = f"{ft:.2f}s" if ft is not None else "did not reach goal in budget"
    print(f"robot {i}: finish_time={status}, min_obstacle_clearance={mc:.2f}px{tag}")

# ---------------------------------------------------------------------------
# 3. Static trajectory summary figure
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(6.4, 6.4))
disp = grid.astype(float).copy()
disp[blocked] = 1.0
ax.imshow(disp, cmap='Greys', origin='upper', alpha=0.85)
# also outline the dynamic obstacle distinctly
circ = plt.Circle((cx, cy), r, color='red', alpha=0.35, zorder=2)
ax.add_patch(circ)

cmap = plt.get_cmap('tab10')
for i, robot in enumerate(sim['robots']):
    hx = [p[0] for p in robot.history]
    hy = [p[1] for p in robot.history]
    ax.plot(hx, hy, color=cmap(i % 10), lw=1.6,
            label=f"robot {i}" + (" (replanned)" if sim['replanned'][i] else ""))
    ax.scatter([hx[0]], [hy[0]], marker='o', s=30, color=cmap(i % 10), zorder=5,
               edgecolors='black', linewidths=0.5)
    ax.scatter([hx[-1]], [hy[-1]], marker='*', s=80, color=cmap(i % 10), zorder=5,
               edgecolors='black', linewidths=0.5)

ax.set_title("Continuous differential-drive execution of SSF/LIR paths\n"
             "(pure-pursuit control; red disk = obstacle appearing mid-flight)",
             fontsize=9.5)
ax.set_xticks([]); ax.set_yticks([])
ax.legend(fontsize=6.5, loc='upper left', ncol=2)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/demo_continuous_trajectories.png', dpi=200, bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/demo_continuous_trajectories.pdf', bbox_inches='tight')
print("static trajectory figure done")

# ---------------------------------------------------------------------------
# 4. Animated GIF
# ---------------------------------------------------------------------------
max_len = max(len(r.history) for r in sim['robots'])
fig2, ax2 = plt.subplots(figsize=(5.6, 5.6))


def draw_frame(frame_i):
    ax2.clear()
    if frame_i < EVENT_STEP:
        disp_f = grid.astype(float)
        obstacle_visible = False
    else:
        disp_f = grid.astype(float).copy()
        disp_f[blocked] = 1.0
        obstacle_visible = True
    ax2.imshow(disp_f, cmap='Greys', origin='upper', alpha=0.85)
    if obstacle_visible:
        ax2.add_patch(plt.Circle((cx, cy), r, color='red', alpha=0.4, zorder=2))
    for i, robot in enumerate(sim['robots']):
        hist = robot.history[:frame_i + 1]
        if not hist:
            continue
        hx = [p[0] for p in hist]
        hy = [p[1] for p in hist]
        ax2.plot(hx, hy, color=cmap(i % 10), lw=1.2, alpha=0.6)
        px, py = hist[-1]
        ax2.scatter([px], [py], s=45, color=cmap(i % 10), zorder=5,
                    edgecolors='black', linewidths=0.5)
    ax2.set_xticks([]); ax2.set_yticks([])
    ax2.set_title(f"t = {frame_i*DT:.1f}s" + ("  [obstacle appears]" if obstacle_visible and frame_i < EVENT_STEP + 15 else ""),
                  fontsize=9)


frame_indices = list(range(0, max_len, 4))
ani = animation.FuncAnimation(fig2, draw_frame, frames=frame_indices, interval=80)
ani.save('/home/claude/smsn/figs/demo_continuous_animation.gif', writer='pillow', fps=12, dpi=110)
print("animation done")

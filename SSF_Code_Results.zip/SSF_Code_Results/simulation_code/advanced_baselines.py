"""
Additional baseline planners added in response to reviewer requests:
  - A* (grid, 8-connected)
  - Theta* (any-angle grid planner)
  - D* Lite (incremental replanning on the grid, compared against LIR)
  - PRM* (sampling-based roadmap)
  - Skeleton-restricted Conflict-Based Search (CBS) for small-N optimal MAPF
"""
import heapq
import time
import numpy as np
import networkx as nx
from scipy.spatial import cKDTree


# ---------------------------------------------------------------------------
# A* on the occupancy grid
# ---------------------------------------------------------------------------
def astar_grid(obstacle_mask, start, goal):
    H, W = obstacle_mask.shape
    def h(p):
        return np.hypot(p[0] - goal[0], p[1] - goal[1])
    neighbors8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    t0 = time.perf_counter()
    openq = [(h(start), 0.0, start)]
    gscore = {start: 0.0}
    parent = {}
    visited = set()
    while openq:
        _, g, cur = heapq.heappop(openq)
        if cur in visited:
            continue
        visited.add(cur)
        if cur == goal:
            path = [cur]
            while cur in parent:
                cur = parent[cur]
                path.append(cur)
            return path[::-1], gscore[goal], time.perf_counter() - t0
        for dy, dx in neighbors8:
            ny, nx_ = cur[0] + dy, cur[1] + dx
            if not (0 <= ny < H and 0 <= nx_ < W):
                continue
            if obstacle_mask[ny, nx_]:
                continue
            step = np.hypot(dy, dx)
            ng = g + step
            npt = (ny, nx_)
            if ng < gscore.get(npt, np.inf):
                gscore[npt] = ng
                parent[npt] = cur
                heapq.heappush(openq, (ng + h(npt), ng, npt))
    return None, np.inf, time.perf_counter() - t0


# ---------------------------------------------------------------------------
# Theta* (any-angle) on the occupancy grid
# ---------------------------------------------------------------------------
def _line_of_sight(obstacle_mask, p, q):
    H, W = obstacle_mask.shape
    y0, x0 = p
    y1, x1 = q
    n = int(max(abs(y1 - y0), abs(x1 - x0))) + 1
    for i in range(n + 1):
        t = i / n
        y = int(round(y0 + (y1 - y0) * t))
        x = int(round(x0 + (x1 - x0) * t))
        if not (0 <= y < H and 0 <= x < W) or obstacle_mask[y, x]:
            return False
    return True


def theta_star_grid(obstacle_mask, start, goal):
    H, W = obstacle_mask.shape
    def h(p):
        return np.hypot(p[0] - goal[0], p[1] - goal[1])
    neighbors8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    t0 = time.perf_counter()
    gscore = {start: 0.0}
    parent = {start: start}
    openq = [(h(start), start)]
    visited = set()
    while openq:
        _, cur = heapq.heappop(openq)
        if cur in visited:
            continue
        visited.add(cur)
        if cur == goal:
            path = [cur]
            while path[-1] != start:
                path.append(parent[path[-1]])
            return path[::-1], gscore[goal], time.perf_counter() - t0
        par = parent[cur]
        for dy, dx in neighbors8:
            ny, nx_ = cur[0] + dy, cur[1] + dx
            if not (0 <= ny < H and 0 <= nx_ < W) or obstacle_mask[ny, nx_]:
                continue
            npt = (ny, nx_)
            # path 2: try shortcutting through the grandparent (any-angle)
            if _line_of_sight(obstacle_mask, par, npt):
                ng = gscore[par] + np.hypot(npt[0] - par[0], npt[1] - par[1])
                cand_parent = par
            else:
                ng = gscore[cur] + np.hypot(dy, dx)
                cand_parent = cur
            if ng < gscore.get(npt, np.inf):
                gscore[npt] = ng
                parent[npt] = cand_parent
                heapq.heappush(openq, (ng + h(npt), npt))
    return None, np.inf, time.perf_counter() - t0


# ---------------------------------------------------------------------------
# D* Lite (incremental replanning), used as the direct comparator to LIR
# ---------------------------------------------------------------------------
class DStarLite:
    """A compact D* Lite implementation on the occupancy grid. Supports an
    initial planning call and cheap incremental updates when cells flip
    from free to blocked (or vice versa), which is the same use case LIR
    targets for the skeleton representation."""

    def __init__(self, obstacle_mask, start, goal):
        self.mask = obstacle_mask.copy()
        self.H, self.W = obstacle_mask.shape
        self.start = start
        self.goal = goal
        self.g = {}
        self.rhs = {}
        self.km = 0.0
        self.U = []
        self.rhs[goal] = 0.0
        heapq.heappush(self.U, (self._key(goal), goal))
        self._compute_shortest_path()

    def _h(self, a, b):
        return np.hypot(a[0] - b[0], a[1] - b[1])

    def _key(self, s):
        g = self.g.get(s, np.inf)
        rhs = self.rhs.get(s, np.inf)
        m = min(g, rhs)
        return (m + self._h(self.start, s) + self.km, m)

    def _neighbors(self, s):
        out = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                ny, nx_ = s[0] + dy, s[1] + dx
                if 0 <= ny < self.H and 0 <= nx_ < self.W and not self.mask[ny, nx_]:
                    out.append((ny, nx_))
        return out

    def _cost(self, a, b):
        if self.mask[b[0], b[1]]:
            return np.inf
        return np.hypot(a[0] - b[0], a[1] - b[1])

    def _update_vertex(self, u):
        if u != self.goal:
            best = np.inf
            for s in self._neighbors(u):
                best = min(best, self._cost(u, s) + self.g.get(s, np.inf))
            self.rhs[u] = best
        self.U = [(k, s) for k, s in self.U if s != u]
        heapq.heapify(self.U)
        if self.g.get(u, np.inf) != self.rhs.get(u, np.inf):
            heapq.heappush(self.U, (self._key(u), u))

    def _compute_shortest_path(self, budget=200000):
        steps = 0
        while self.U and steps < budget:
            steps += 1
            k_old, u = heapq.heappop(self.U)
            k_new = self._key(u)
            if k_old < k_new:
                heapq.heappush(self.U, (k_new, u))
                continue
            if self.g.get(u, np.inf) > self.rhs.get(u, np.inf):
                self.g[u] = self.rhs[u]
                for s in self._neighbors(u):
                    self._update_vertex(s)
            else:
                self.g[u] = np.inf
                self._update_vertex(u)
                for s in self._neighbors(u):
                    self._update_vertex(s)
            if (self.g.get(self.start, np.inf) <= self.rhs.get(self.start, np.inf)
                    and self.rhs.get(self.start, np.inf) < np.inf):
                # start is locally consistent and finite: safe to stop early
                if len(self.U) == 0 or self.U[0][0] >= self._key(self.start):
                    break

    def extract_path(self):
        if self.g.get(self.start, np.inf) == np.inf:
            return None, np.inf
        path = [self.start]
        cur = self.start
        cost = 0.0
        seen = {cur}
        while cur != self.goal:
            best, best_c = None, np.inf
            for s in self._neighbors(cur):
                c = self._cost(cur, s) + self.g.get(s, np.inf)
                if c < best_c:
                    best_c, best = c, s
            if best is None or best in seen:
                return None, np.inf
            cost += self._cost(cur, best)
            cur = best
            seen.add(cur)
            path.append(cur)
            if len(path) > self.H * self.W:
                return None, np.inf
        return path, cost

    def update_obstacles(self, changed_cells):
        """changed_cells: list of (y, x) that just became blocked."""
        for (y, x) in changed_cells:
            self.mask[y, x] = True
            for s in self._neighbors((y, x)) + [(y, x)]:
                self._update_vertex(s)
        self._compute_shortest_path()


def coarsen_mask(obstacle_mask, stride):
    """Coarsen an obstacle mask to a stride x stride block grid, marking
    a coarse cell as obstacle if ANY pixel inside it is obstacle
    (conservative merge, so the coarse mask never claims free space that
    is actually blocked). Used only for the controlled comparison in
    dstar_lite_coarse_control -- NOT part of the SSF/LIR pipeline."""
    H, W = obstacle_mask.shape
    Hc, Wc = H // stride, W // stride
    coarse = np.zeros((Hc, Wc), dtype=bool)
    for i in range(Hc):
        for j in range(Wc):
            block = obstacle_mask[i * stride:(i + 1) * stride, j * stride:(j + 1) * stride]
            coarse[i, j] = block.any()
    return coarse


def dstar_lite_coarse_control(obstacle_mask, start, goal, blocked_region, stride,
                               n_target_nodes=None):
    """Runs D* Lite on a coarsened grid whose node count is comparable to
    a typical skeleton graph, to test whether the D*Lite-vs-LIR gap
    reported in the main experiments is caused by the *algorithm* or
    simply by the *grid having many more nodes than the skeleton graph*.
    Coordinates are scaled by `stride` internally; the function reports
    coarse-grid node count alongside timing so the comparison is
    self-documenting."""
    coarse_mask = coarsen_mask(obstacle_mask, stride)
    Hc, Wc = coarse_mask.shape
    n_nodes = int((~coarse_mask).sum())

    cs = (max(1, start[0] // stride), max(1, start[1] // stride))
    cg = (max(1, goal[0] // stride), max(1, goal[1] // stride))
    cs = (min(cs[0], Hc - 1), min(cs[1], Wc - 1))
    cg = (min(cg[0], Hc - 1), min(cg[1], Wc - 1))
    if coarse_mask[cs]:
        coarse_mask[cs] = False
    if coarse_mask[cg]:
        coarse_mask[cg] = False

    t0 = time.perf_counter()
    planner = DStarLite(coarse_mask, cs, cg)
    path0, cost0 = planner.extract_path()
    t_initial = time.perf_counter() - t0

    coarse_blocked = coarsen_mask(blocked_region, stride)
    changed = list(zip(*np.nonzero(coarse_blocked)))
    t1 = time.perf_counter()
    if changed:
        planner.update_obstacles(changed)
    path1, cost1 = planner.extract_path()
    t_replan = time.perf_counter() - t1

    return {
        'n_nodes': n_nodes, 'stride': stride,
        't_initial': t_initial, 't_replan': t_replan,
        'cost_initial': cost0 * stride if cost0 is not None and np.isfinite(cost0) else None,
        'cost_replan': cost1 * stride if cost1 is not None and np.isfinite(cost1) else None,
        'solved_initial': path0 is not None, 'solved_replan': path1 is not None,
    }


def dstar_lite_initial_and_replan(obstacle_mask, start, goal, blocked_region):
    """Runs D* Lite from scratch, then applies the given obstacle and
    re-plans incrementally, timing both phases separately."""
    t0 = time.perf_counter()
    planner = DStarLite(obstacle_mask, start, goal)
    path0, cost0 = planner.extract_path()
    t_initial = time.perf_counter() - t0

    ys, xs = np.nonzero(blocked_region)
    changed = list(zip(ys.tolist(), xs.tolist()))
    t1 = time.perf_counter()
    planner.update_obstacles(changed)
    path1, cost1 = planner.extract_path()
    t_replan = time.perf_counter() - t1
    return (path0, cost0, t_initial), (path1, cost1, t_replan)


# ---------------------------------------------------------------------------
# PRM* (probabilistic roadmap, star-rewired for asymptotic optimality)
# ---------------------------------------------------------------------------
def prm_star(obstacle_mask, start, goal, n_samples=400, k_neighbors=10, seed=0):
    H, W = obstacle_mask.shape
    rng = np.random.RandomState(seed)

    def collision_free(p, q):
        n = int(np.hypot(q[0] - p[0], q[1] - p[1]) / 1.5) + 1
        for i in range(n + 1):
            y = int(p[0] + (q[0] - p[0]) * i / n)
            x = int(p[1] + (q[1] - p[1]) * i / n)
            if not (0 <= y < H and 0 <= x < W) or obstacle_mask[y, x]:
                return False
        return True

    t0 = time.perf_counter()
    samples = [start, goal]
    tries = 0
    while len(samples) < n_samples + 2 and tries < n_samples * 20:
        tries += 1
        y, x = rng.uniform(0, H), rng.uniform(0, W)
        if not obstacle_mask[int(y), int(x)]:
            samples.append((y, x))
    pts = np.array(samples)
    tree = cKDTree(pts)
    G = nx.Graph()
    for i, p in enumerate(samples):
        G.add_node(i)
    for i, p in enumerate(samples):
        dists, idxs = tree.query(p, k=min(k_neighbors + 1, len(samples)))
        for d, j in zip(dists, idxs):
            if i == j:
                continue
            if collision_free(samples[i], samples[j]):
                G.add_edge(i, j, weight=d)
    try:
        path_idx = nx.shortest_path(G, 0, 1, weight='weight')
        length = nx.shortest_path_length(G, 0, 1, weight='weight')
        path = [samples[i] for i in path_idx]
    except nx.NetworkXNoPath:
        path, length = None, np.inf
    return path, length, time.perf_counter() - t0


# ---------------------------------------------------------------------------
# Skeleton-restricted Conflict-Based Search (CBS) for small-N optimal MAPF
# ---------------------------------------------------------------------------
def _low_level_astar_with_constraints(G, start, goal, constraints, max_t=200):
    """Time-expanded A* on the skeleton graph. constraints: set of
    (node, t) vertex constraints and (u, v, t) edge constraints to avoid."""
    def h(n):
        return G.nodes[n].get('_h', 0.0)

    openq = [(0, start, 0)]
    gscore = {(start, 0): 0.0}
    parent = {}
    while openq:
        _, cur, t = heapq.heappop(openq)
        if cur == goal:
            path = [(cur, t)]
            key = (cur, t)
            while key in parent:
                key = parent[key]
                path.append(key)
            return path[::-1], gscore[(cur, t)]
        if t > max_t:
            continue
        options = [cur] + list(G.neighbors(cur))
        for nxt in options:
            nt = t + 1
            if (nxt, nt) in constraints:
                continue
            if (cur, nxt, nt) in constraints:
                continue
            step = 1.0 if nxt == cur else G[cur][nxt]['weight']
            ng = gscore[(cur, t)] + step
            key = (nxt, nt)
            if ng < gscore.get(key, np.inf):
                gscore[key] = ng
                parent[key] = (cur, t)
                heapq.heappush(openq, (ng, nxt, nt))
    return None, np.inf


def cbs_solve(G, agents, time_budget_s=5.0, max_t=200):
    """agents: list of (start, goal) node pairs on skeleton graph G.
    Returns (paths, total_cost, wall_time, solved_bool)."""
    t0 = time.perf_counter()

    def solve_with_constraints(constraints_per_agent):
        paths = []
        for i, (s, g) in enumerate(agents):
            p, c = _low_level_astar_with_constraints(
                G, s, g, constraints_per_agent[i], max_t=max_t)
            if p is None:
                return None, np.inf
            paths.append(p)
        return paths, sum(len(p) for p in paths)

    def find_conflict(paths):
        T = max(len(p) for p in paths)
        for t in range(T):
            occ = {}
            for i, p in enumerate(paths):
                node = p[min(t, len(p) - 1)][0]
                if node in occ:
                    return ('vertex', occ[node], i, node, t)
                occ[node] = i
            for i in range(len(paths)):
                for j in range(i + 1, len(paths)):
                    pi = paths[i][min(t, len(paths[i]) - 1)][0]
                    pi_prev = paths[i][min(max(t - 1, 0), len(paths[i]) - 1)][0]
                    pj = paths[j][min(t, len(paths[j]) - 1)][0]
                    pj_prev = paths[j][min(max(t - 1, 0), len(paths[j]) - 1)][0]
                    if pi == pj_prev and pj == pi_prev and pi != pj:
                        return ('edge', i, j, (pi_prev, pi), t)
        return None

    root_constraints = [set() for _ in agents]
    root_paths, root_cost = solve_with_constraints(root_constraints)
    if root_paths is None:
        return None, np.inf, time.perf_counter() - t0, False

    frontier = [(root_cost, root_constraints, root_paths)]
    nodes_expanded = 0
    while frontier and (time.perf_counter() - t0) < time_budget_s:
        nodes_expanded += 1
        frontier.sort(key=lambda x: x[0])
        cost, constraints, paths = frontier.pop(0)
        conflict = find_conflict(paths)
        if conflict is None:
            return paths, cost, time.perf_counter() - t0, True
        if conflict[0] == 'vertex':
            _, i, j, node, t = conflict
            for agent in (i, j):
                new_constraints = [set(c) for c in constraints]
                new_constraints[agent].add((node, t))
                new_paths, new_cost = solve_with_constraints(new_constraints)
                if new_paths is not None:
                    frontier.append((new_cost, new_constraints, new_paths))
        else:
            _, i, j, edge, t = conflict
            for agent in (i, j):
                new_constraints = [set(c) for c in constraints]
                new_constraints[agent].add((edge[0], edge[1], t))
                new_paths, new_cost = solve_with_constraints(new_constraints)
                if new_paths is not None:
                    frontier.append((new_cost, new_constraints, new_paths))
    return None, np.inf, time.perf_counter() - t0, False

"""
Expanded multi-robot performance metrics, addressing the reviewer
request for collision rate, makespan, throughput, waiting/congestion
detail, and congestion-vs-density rather than a single aggregate
congestion count.

Since SSF plans in discrete rounds rather than continuous time, we
define these metrics operationally and state the definition plainly
rather than borrow continuous-time terminology without a matching
model:

  - capacity(e)   = max(1, floor(clearance(e) / 3)), a corridor-width-
                    based proxy for how many robots can occupy an edge
                    at once without a physical conflict.
  - collision-risk = a robot's path uses at least one edge whose
                    simultaneous usage in that round exceeds capacity.
                    Reported as the fraction of robot-requests at risk.
  - max/mean edge occupancy = peak / average simultaneous usage across
                    edges actually used in the round.
  - path-overlap  = fraction of used edges that are shared by 2+ robots
                    in the same round.
  - makespan      = max geometric path length across the round's
                    robots (a time proxy at constant speed).
  - throughput    = (sum of path lengths) / makespan: how efficiently
                    robots move in parallel relative to the slowest one.
"""
import sys
sys.path.insert(0, '.')
import numpy as np
import networkx as nx
from collections import Counter
from env_utils import make_cluttered_environment, compute_skeleton, skeleton_to_graph
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate, geometric_path_length


def edge_capacity(G, u, v):
    clearance = G[u][v].get('clearance', 3.0)
    return max(1, int(clearance // 3))


def round_metrics(G, paths):
    edge_usage_this_round = Counter()
    for path, _ in paths:
        for i in range(len(path) - 1):
            e = tuple(sorted((path[i], path[i + 1])))
            edge_usage_this_round[e] += 1

    at_risk = 0
    for path, _ in paths:
        risky = False
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            e = tuple(sorted((u, v)))
            cap = edge_capacity(G, u, v)
            if edge_usage_this_round[e] > cap:
                risky = True
                break
        if risky:
            at_risk += 1
    collision_risk_rate = at_risk / max(len(paths), 1)

    occ_values = list(edge_usage_this_round.values())
    max_occ = max(occ_values) if occ_values else 0
    mean_occ = np.mean(occ_values) if occ_values else 0.0
    shared_edges = sum(1 for v in occ_values if v >= 2)
    overlap_pct = 100.0 * shared_edges / max(len(occ_values), 1)

    lengths = [geometric_path_length(G, p) for p, _ in paths]
    makespan = max(lengths) if lengths else 0.0
    throughput = sum(lengths) / makespan if makespan > 0 else 0.0

    return {
        'collision_risk_rate': collision_risk_rate,
        'max_occupancy': max_occ,
        'mean_occupancy': mean_occ,
        'overlap_pct': overlap_pct,
        'makespan': makespan,
        'throughput': throughput,
    }


def run_condition(G_base, n_robots, gamma, freeze_pheromone, n_rounds=15, seed=0):
    rng = np.random.RandomState(seed)
    G = G_base.copy()
    init_pheromone(G, tau0=1.0)
    nodes = list(G.nodes)
    all_metrics = []
    for rnd in range(n_rounds):
        requests = []
        for _ in range(n_robots):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            requests.append((nodes[s], nodes[t]))
        paths = run_ssf_episode(G, requests, alpha=1.0, beta=2.0, gamma=gamma, kappa=4.0)
        if not freeze_pheromone:
            deposit_and_evaporate(G, paths, rho=0.12, Q=8.0)
        else:
            deposit_and_evaporate(G, [], rho=0.0, Q=8.0)  # usage still decays, tau frozen
        if rnd >= n_rounds - 5:  # steady-state rounds only
            all_metrics.append(round_metrics(G, paths))
    agg = {}
    for k in all_metrics[0]:
        agg[k] = (np.mean([m[k] for m in all_metrics]), np.std([m[k] for m in all_metrics]))
    return agg


if __name__ == '__main__':
    grid = make_cluttered_environment(size=140, seed=2)
    free = ~grid
    skel, dist = compute_skeleton(free)
    G_raw = skeleton_to_graph(skel, dist)
    largest_cc = max(nx.connected_components(G_raw), key=len)
    G_base = G_raw.subgraph(largest_cc).copy()

    robot_counts = [5, 10, 20, 40]
    conditions = [
        ('SSF (proposed, gamma=0.6)', dict(gamma=0.6, freeze_pheromone=False)),
        ('No congestion (gamma=0)', dict(gamma=0.0, freeze_pheromone=False)),
        ('Frozen pheromone', dict(gamma=0.6, freeze_pheromone=True)),
    ]
    N_SEEDS = 4

    print(f"{'Robots':>6s} {'Condition':28s} {'CollRisk%':>10s} {'MaxOcc':>7s} "
          f"{'MeanOcc':>8s} {'Overlap%':>9s} {'Makespan':>9s} {'Thruput':>8s}")
    results = {}
    for n_robots in robot_counts:
        for name, kw in conditions:
            seed_aggs = [run_condition(G_base, n_robots, n_rounds=15, seed=1000 * s + n_robots, **kw)
                         for s in range(N_SEEDS)]
            agg = {}
            for k in seed_aggs[0]:
                vals = [sa[k][0] for sa in seed_aggs]
                agg[k] = (np.mean(vals), np.std(vals))
            results[(n_robots, name)] = agg
            print(f"{n_robots:6d} {name:28s} "
                  f"{100*agg['collision_risk_rate'][0]:9.1f}% {agg['max_occupancy'][0]:7.2f} "
                  f"{agg['mean_occupancy'][0]:8.2f} {agg['overlap_pct'][0]:8.1f}% "
                  f"{agg['makespan'][0]:9.1f} {agg['throughput'][0]:8.2f}")

    import json
    serializable = {f"{k[0]}_{k[1]}": {kk: list(vv) for kk, vv in v.items()}
                     for k, v in results.items()}
    with open('multirobot_metrics_results.json', 'w') as f:
        json.dump(serializable, f, indent=2)
    print("\nSaved to multirobot_metrics_results.json")

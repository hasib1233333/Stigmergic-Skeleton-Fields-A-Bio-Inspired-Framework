import sys
sys.path.insert(0, '.')
import numpy as np
import networkx as nx
import time
from env_utils import (make_office_environment, make_cluttered_environment, make_maze_environment,
                        compute_skeleton, skeleton_to_graph, nearest_node)
from ssf_core import (apply_dynamic_obstacle, local_reskeletonize, full_reskeletonize,
                       init_pheromone, modulated_shortest_path, geometric_path_length)

N_TRIALS = 120
env_makers = [
    ('office', lambda seed: make_office_environment(size=140, seed=seed)),
    ('cluttered', lambda seed: make_cluttered_environment(size=140, seed=seed, n_obstacles=45)),
    ('maze', lambda seed: make_maze_environment(size=140, seed=seed)),
]

records = {
    'fallback': 0, 'connectivity_preserved': 0, 'valid_path': 0, 'total': 0,
    'lir_times': [], 'full_times': [], 'cost_diffs': [], 'ports_total': [],
    'ports_connected': [],
}

trial = 0
attempts = 0
while trial < N_TRIALS and attempts < N_TRIALS * 4:
    attempts += 1
    env_name, maker = env_makers[trial % 3]
    seed = 1000 + attempts
    grid = maker(seed)
    free = ~grid
    skel0, dist0 = compute_skeleton(free)
    G0_raw = skeleton_to_graph(skel0, dist0)
    largest_cc = max(nx.connected_components(G0_raw), key=len)
    G0 = G0_raw.subgraph(largest_cc).copy()
    init_pheromone(G0, tau0=1.0)
    nodes = list(G0.nodes)
    if len(nodes) < 5:
        continue
    rng = np.random.RandomState(seed)
    si, ti = rng.choice(len(nodes), size=2, replace=False)
    s, t = nodes[si], nodes[ti]
    if not nx.has_path(G0, s, t):
        continue
    path0, len0 = modulated_shortest_path(G0, s, t)
    if len(path0) < 3:
        continue
    mid = path0[len(path0) // 2]
    r = int(rng.choice([4, 6, 8]))
    free1, blocked = apply_dynamic_obstacle(free, mid[0], mid[1], r)
    if not blocked.any():
        continue

    trial += 1
    G_local, t_local, diag = local_reskeletonize(G0, free1, blocked, pad=18)
    records['lir_times'].append(t_local * 1000)
    records['ports_total'].append(diag['ports_total'])
    records['ports_connected'].append(diag['ports_connected'])
    if diag['fallback']:
        records['fallback'] += 1
    if diag.get('connectivity_preserved', True):
        records['connectivity_preserved'] += 1

    G_full, t_full = full_reskeletonize(free1)
    init_pheromone(G_full, tau0=1.0)
    records['full_times'].append(t_full * 1000)
    records['total'] += 1

    try:
        sN, tN = nearest_node(G_local, *s), nearest_node(G_local, *t)
        sF, tF = nearest_node(G_full, *s), nearest_node(G_full, *t)
        local_ok = nx.has_path(G_local, sN, tN)
        full_ok = nx.has_path(G_full, sF, tF)
        if local_ok and full_ok:
            records['valid_path'] += 1
            _, lc = modulated_shortest_path(G_local, sN, tN)
            _, fc = modulated_shortest_path(G_full, sF, tF)
            records['cost_diffs'].append(lc - fc)
        elif full_ok and not local_ok:
            pass  # LIR failed to preserve a route full re-skeletonization finds
    except Exception:
        pass

print(f"Trials completed: {records['total']}")
print(f"Fallback (to full re-skeletonization) rate: {records['fallback']}/{records['total']} "
      f"({100*records['fallback']/records['total']:.1f}%)")
print(f"Connectivity-preserved rate: {records['connectivity_preserved']}/{records['total']} "
      f"({100*records['connectivity_preserved']/records['total']:.1f}%)")
print(f"Valid start-goal path rate (both LIR and full solve it): {records['valid_path']}/{records['total']} "
      f"({100*records['valid_path']/records['total']:.1f}%)")
total_ports = sum(records['ports_total'])
total_connected = sum(records['ports_connected'])
print(f"Interface ports: {total_connected}/{total_ports} connected on first attempt "
      f"({100*total_connected/max(total_ports,1):.1f}%)")
print(f"Mean LIR time: {np.mean(records['lir_times']):.2f} ms (SD {np.std(records['lir_times']):.2f})")
print(f"Mean full re-skeletonization time: {np.mean(records['full_times']):.2f} ms "
      f"(SD {np.std(records['full_times']):.2f})")
print(f"Speedup: {np.mean(records['full_times'])/np.mean(records['lir_times']):.2f}x")
if records['cost_diffs']:
    print(f"Mean path-cost difference (LIR - full): {np.mean(records['cost_diffs']):.2f} px "
          f"(SD {np.std(records['cost_diffs']):.2f}, n={len(records['cost_diffs'])})")

import json
with open('/home/claude/smsn/SSF_Code_Results/simulation_code/lir_validation_results.json', 'w') as f:
    json.dump({k: (v if not isinstance(v, list) else v) for k, v in records.items()}, f, indent=2)
print("\nSaved raw results to lir_validation_results.json")

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import networkx as nx
from env_utils import (make_warehouse_environment, make_random_fill_environment,
                        compute_skeleton, skeleton_to_graph)
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate, geometric_path_length

envs = {
    "Warehouse (16-cell rooms)": make_warehouse_environment(size=140, seed=6, room_size=16),
    "Random-fill (20% occupied)": make_random_fill_environment(size=140, seed=7, fill_pct=20),
}

n_trials = 10
n_agents = 15
n_rounds = 40

print(f"{'Environment':28s} | {'nodes':>6s} | {'SSF cost':>10s} | {'Static cost':>12s} | {'SSF ms':>8s}")
for name, grid in envs.items():
    free = ~grid
    skel, dist = compute_skeleton(free)
    G_raw = skeleton_to_graph(skel, dist)
    largest_cc = max(nx.connected_components(G_raw), key=len)
    G = G_raw.subgraph(largest_cc).copy()
    nodes = list(G.nodes)

    ssf_costs, static_costs, ssf_times = [], [], []
    for trial in range(n_trials):
        rng = np.random.RandomState(1000 * trial + 77)
        requests = []
        for _ in range(n_agents):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            requests.append((nodes[s], nodes[t]))
        Gs = G.copy()
        init_pheromone(Gs, tau0=1.0)
        import time
        for it in range(n_rounds):
            t0 = time.perf_counter()
            paths = run_ssf_episode(Gs, requests)
            deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
        dt = time.perf_counter() - t0
        ssf_costs.append(np.mean([geometric_path_length(Gs, p) for p, _ in paths]))
        ssf_times.append(dt * 1000 / n_agents)
        lens = [nx.shortest_path_length(G, s, t, weight='weight') for s, t in requests]
        static_costs.append(np.mean(lens))

    print(f"{name:28s} | {G.number_of_nodes():6d} | {np.mean(ssf_costs):10.2f} | "
          f"{np.mean(static_costs):12.2f} | {np.mean(ssf_times):8.3f}")

print("\ndone")

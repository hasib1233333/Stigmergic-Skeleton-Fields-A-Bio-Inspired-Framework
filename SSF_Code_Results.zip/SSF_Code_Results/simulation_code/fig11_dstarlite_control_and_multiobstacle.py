import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import (apply_dynamic_obstacle, local_reskeletonize, init_pheromone,
                       modulated_shortest_path, geometric_path_length)
from advanced_baselines import dstar_lite_coarse_control, dstar_lite_initial_and_replan

from plot_style import apply_style, COLORS
apply_style()

# ---------------------------------------------------------------------------
# Part A: coarse-grid D* Lite control -- isolates graph-size effect
# ---------------------------------------------------------------------------
strides = [16, 13, 10, 8, 6]
n_trials = 4
results = {s: {'n_nodes': [], 't_replan': [], 'cost_replan': []} for s in strides}
lir_times, lir_costs, skel_nodes = [], [], []

for trial in range(n_trials):
    grid = make_office_environment(size=140, seed=1 + trial)
    free = ~grid
    skel, dist = compute_skeleton(free)
    G0 = skeleton_to_graph(skel, dist)
    largest_cc = max(nx.connected_components(G0), key=len)
    G0 = G0.subgraph(largest_cc).copy()
    init_pheromone(G0, tau0=1.0)
    start_node = nearest_node(G0, 8, 8)
    goal_node = nearest_node(G0, 130, 130)
    try:
        path0, _ = modulated_shortest_path(G0, start_node, goal_node)
    except Exception:
        continue
    mid = path0[len(path0) // 2]
    free_after, blocked = apply_dynamic_obstacle(free, mid[0], mid[1], 7)
    if not blocked.any():
        continue

    G_after, t_lir, _lir_diag = local_reskeletonize(G0, free_after, blocked, pad=18)
    init_pheromone(G_after, tau0=1.0)
    s2 = nearest_node(G_after, mid[0], mid[1])
    g2 = nearest_node(G_after, *path0[-1])
    if nx.has_path(G_after, s2, g2):
        _, lir_len = modulated_shortest_path(G_after, s2, g2)
        lir_times.append(t_lir * 1000)
        lir_costs.append(lir_len)
    skel_nodes.append(G0.number_of_nodes())

    start, goal = (8, 8), (130, 130)
    for stride in strides:
        r = dstar_lite_coarse_control(grid, start, goal, blocked, stride)
        results[stride]['n_nodes'].append(r['n_nodes'])
        results[stride]['t_replan'].append(r['t_replan'] * 1000)
        if r['cost_replan'] is not None:
            results[stride]['cost_replan'].append(r['cost_replan'])

mean_nodes = [np.mean(results[s]['n_nodes']) for s in strides]
mean_t = [np.mean(results[s]['t_replan']) for s in strides]
std_t = [np.std(results[s]['t_replan']) for s in strides]
mean_lir_nodes = np.mean(skel_nodes)
mean_lir_t = np.mean(lir_times)
std_lir_t = np.std(lir_times)

# ---------------------------------------------------------------------------
# Part B: multiple simultaneous obstacles + one obstacle removal
# ---------------------------------------------------------------------------
grid = make_office_environment(size=180, seed=2)
free0 = ~grid
skel0, dist0 = compute_skeleton(free0)
G_base = skeleton_to_graph(skel0, dist0)

n_simultaneous_list = [1, 2, 3, 4, 5]
multi_times = {k: [] for k in n_simultaneous_list}
for k in n_simultaneous_list:
    for trial in range(4):
        rr = np.random.RandomState(100 * trial + k)
        G_cur = G_base.copy()
        free_cur = free0.copy()
        total_t = 0.0
        for _ in range(k):
            cy, cx = rr.randint(20, 160, size=2)
            r = 6
            free_cur, blocked = apply_dynamic_obstacle(free_cur, cy, cx, r)
            if blocked.any():
                t0 = time.perf_counter()
                G_cur, _, _lir_diag = local_reskeletonize(G_cur, free_cur, blocked, pad=18)
                total_t += time.perf_counter() - t0
        multi_times[k].append(total_t * 1000)

# obstacle removal: place an obstacle, LIR it in, then remove it (restore
# free space) and LIR again, confirming LIR handles disappearance too
cy, cx, r = 90, 90, 8
free_blocked, blocked_region = apply_dynamic_obstacle(free0, cy, cx, r)
G_blocked, t_add, _lir_diag = local_reskeletonize(G_base, free_blocked, blocked_region, pad=18)
free_restored = free0.copy()
t0 = time.perf_counter()
G_restored, _, _lir_diag = local_reskeletonize(G_blocked, free_restored, blocked_region, pad=18)
t_remove = (time.perf_counter() - t0) * 1000
print(f"Obstacle removal LIR update: {t_remove:.2f} ms "
      f"(vs. {t_add*1000:.2f} ms to add it originally)")

# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.2))
ax = axes[0]
ax.errorbar(mean_nodes, mean_t, yerr=std_t, marker='o', color='#A2142F',
            label='D* Lite on coarsened grid\n(varying stride)', capsize=3, lw=1.6)
ax.errorbar([mean_lir_nodes], [mean_lir_t], yerr=[std_lir_t], marker='s',
            color='#0072BD', label='Proposed LIR (skeleton graph)', capsize=4,
            markersize=9)
ax.set_xlabel('Number of graph nodes')
ax.set_ylabel('Replanning time (ms)')
ax.set_title('(a) D* Lite vs. LIR at matched graph size', fontsize=10)
ax.legend(fontsize=7.5, loc='upper center', bbox_to_anchor=(0.5, -0.18),
          ncol=1, frameon=True)
ax.grid(alpha=0.25)

ax2 = axes[1]
means_multi = [np.mean(multi_times[k]) for k in n_simultaneous_list]
stds_multi = [np.std(multi_times[k]) for k in n_simultaneous_list]
ax2.errorbar(n_simultaneous_list, means_multi, yerr=stds_multi, marker='D',
             color='#77AC30', capsize=3, lw=1.8)
ax2.plot(n_simultaneous_list, [means_multi[0] * k for k in n_simultaneous_list],
         ls='--', color='gray', lw=1.2, label='linear scaling from $k$=1')
ax2.set_xlabel('Number of simultaneous new obstacles')
ax2.set_ylabel('Total LIR update time (ms)')
ax2.set_title('(b) Multiple simultaneous obstacles', fontsize=10)
ax2.legend(fontsize=7.5)
ax2.grid(alpha=0.25)

fig.suptitle('Controlling for graph size, and stress-testing LIR under '
              'multiple simultaneous dynamic obstacles', fontsize=10, y=1.03)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig11_dstarlite_control_multiobstacle.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig11_dstarlite_control_multiobstacle.png', bbox_inches='tight', dpi=300)

print("=== Coarse D*Lite control ===")
for s in strides:
    cvals = results[s]['cost_replan']
    cmean = np.mean(cvals) if cvals else float('nan')
    print(f"stride={s}: mean_nodes={np.mean(results[s]['n_nodes']):.1f}, "
          f"mean_t={np.mean(results[s]['t_replan']):.3f}ms, mean_cost={cmean:.1f}")
print(f"LIR (skeleton): mean_nodes={mean_lir_nodes:.1f}, mean_t={mean_lir_t:.3f}ms, "
      f"mean_cost={np.mean(lir_costs):.1f}")
print("=== Multi-obstacle scaling ===")
for k in n_simultaneous_list:
    print(k, "mean_total_ms=%.2f" % np.mean(multi_times[k]), "sd=%.2f" % np.std(multi_times[k]))
print("fig11 done")

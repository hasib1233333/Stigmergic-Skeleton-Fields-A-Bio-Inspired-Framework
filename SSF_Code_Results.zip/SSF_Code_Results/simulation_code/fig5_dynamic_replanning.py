import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import (apply_dynamic_obstacle, full_reskeletonize, local_reskeletonize,
                       init_pheromone, modulated_shortest_path)

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

grid = make_office_environment(size=220, seed=1)
free = ~grid
skel0, dist0 = compute_skeleton(free)
G0 = skeleton_to_graph(skel0, dist0)
init_pheromone(G0, tau0=1.0)

start = nearest_node(G0, 8, 8)
goal = nearest_node(G0, 205, 205)
path0, len0 = modulated_shortest_path(G0, start, goal)

# insert a dynamic obstacle that blocks the previously used corridor
mid = path0[len(path0) // 2]
cy, cx, r = mid[0], mid[1], 7
free1, blocked = apply_dynamic_obstacle(free, cy, cx, r)

G_full, t_full = full_reskeletonize(free1)
init_pheromone(G_full, tau0=1.0)
s_full = nearest_node(G_full, *start)
g_full = nearest_node(G_full, *goal)
path_full, len_full = modulated_shortest_path(G_full, s_full, g_full)

G_local, t_local, _lir_diag = local_reskeletonize(G0, free1, blocked, pad=12)
s_loc = nearest_node(G_local, *start)
g_loc = nearest_node(G_local, *goal)
path_local, len_local = modulated_shortest_path(G_local, s_loc, g_loc)

fig, axes = plt.subplots(1, 3, figsize=(11.5, 4.1))

ax = axes[0]
ax.imshow(free.astype(float) * 0 + grid, cmap='Greys', origin='upper', alpha=0.85)
ys, xs = zip(*path0)
ax.plot(xs, ys, color='#1f77b4', lw=2.0)
ax.set_title(f"(a) Original skeleton path\nlength={len0:.1f}px", fontsize=9.6)
ax.set_xticks([]); ax.set_yticks([])

ax = axes[1]
disp = grid.copy().astype(float)
disp[blocked] = 1.0
ax.imshow(disp, cmap='Greys', origin='upper', alpha=0.85)
circ = plt.Circle((cx, cy), r, color='red', alpha=0.35)
ax.add_patch(circ)
ys, xs = zip(*path_full)
ax.plot(xs, ys, color='#2ca02c', lw=2.0, label='full re-skeletonization')
ax.set_title(f"(b) Full re-skeletonization\nlength={len_full:.1f}px, t={t_full * 1000:.1f} ms",
             fontsize=9.6)
ax.set_xticks([]); ax.set_yticks([])

ax = axes[2]
ax.imshow(disp, cmap='Greys', origin='upper', alpha=0.85)
circ = plt.Circle((cx, cy), r, color='red', alpha=0.35)
ax.add_patch(circ)
box = plt.Rectangle((cx - r - 12, cy - r - 12), 2 * (r + 12), 2 * (r + 12),
                     fill=False, edgecolor='#ff7f0e', lw=1.4, ls='--')
ax.add_patch(box)
ys, xs = zip(*path_local)
ax.plot(xs, ys, color='#9467bd', lw=2.0, label='localized incremental re-skeletonization')
ax.set_title(f"(c) Proposed LIR (dashed = updated region)\n"
             f"length={len_local:.1f}px, t={t_local * 1000:.1f} ms", fontsize=9.6)
ax.set_xticks([]); ax.set_yticks([])

fig.suptitle("Response to a newly appearing dynamic obstacle blocking the active route: "
             f"LIR is {t_full / max(t_local, 1e-6):.1f}$\\times$ faster than full re-skeletonization "
             "while returning an equivalent detour", fontsize=9.8, y=1.03)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig5_dynamic_replanning.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig5_dynamic_replanning.png', bbox_inches='tight', dpi=300)
print("fig5 done", t_full, t_local, len_full, len_local)
print("LIR diagnostics:", _lir_diag)

"""
plot_style.py

Shared style settings so every figure in the paper uses the same
colorblind-friendly palette, font size, and line width, addressing the
"figures look like research plots, not publication figures" feedback.

Palette (colorblind-safe, MATLAB-style):
    blue   #0072BD  -- primary method (SSF / proposed)
    orange #D95319  -- primary baseline
    green  #77AC30  -- tertiary series / positive outcome
    purple #7E2F8E  -- quaternary series
    gray   #7F7F7F  -- ablation / neutral reference
    red    #A2142F  -- used only for "danger"/failure annotations, sparingly

Usage:
    from plot_style import apply_style, COLORS
    apply_style()
    ax.plot(x, y, color=COLORS['blue'], lw=1.5)
"""
import matplotlib.pyplot as plt

COLORS = {
    'blue':   '#0072BD',
    'orange': '#D95319',
    'green':  '#77AC30',
    'purple': '#7E2F8E',
    'gray':   '#7F7F7F',
    'red':    '#A2142F',
    'cyan':   '#4DBEEE',
}

# Ordered palette for cycling across many series (methods, robots, etc.)
PALETTE = [COLORS['blue'], COLORS['orange'], COLORS['green'], COLORS['purple'],
           COLORS['gray'], COLORS['red'], COLORS['cyan']]

LINEWIDTH = 1.5
MARKERSIZE = 5
FONTSIZE = 9


def apply_style():
    plt.rcParams.update({
        "font.family": "serif",
        "font.size": FONTSIZE,
        "axes.titlesize": FONTSIZE,
        "axes.labelsize": FONTSIZE,
        "xtick.labelsize": FONTSIZE - 1,
        "ytick.labelsize": FONTSIZE - 1,
        "legend.fontsize": FONTSIZE - 1.5,
        "figure.titlesize": FONTSIZE + 1,
        "lines.linewidth": LINEWIDTH,
        "lines.markersize": MARKERSIZE,
        "axes.prop_cycle": plt.cycler(color=PALETTE),
        "figure.dpi": 300,
        "savefig.dpi": 300,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linewidth": 0.5,
        "legend.frameon": True,
        "legend.framealpha": 0.9,
        "legend.edgecolor": '0.8',
    })


def outside_legend(ax, **kwargs):
    """Place a legend outside the axes (upper right, just past the frame)
    so it never overlaps data, per the 'move legends outside' request."""
    defaults = dict(loc='upper left', bbox_to_anchor=(1.02, 1.0), borderaxespad=0.)
    defaults.update(kwargs)
    return ax.legend(**defaults)

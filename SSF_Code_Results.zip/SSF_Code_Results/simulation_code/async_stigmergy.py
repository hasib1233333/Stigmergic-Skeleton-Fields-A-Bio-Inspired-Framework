"""
Simulated asynchronous / lossy stigmergy, addressing the reviewer point
that SSF's coordination policy is decentralized (no robot-to-robot
messages) but every experiment so far has used one synchronous,
in-process shared graph. This does not require real networking
infrastructure to test the *sensitivity* of the mechanism to staleness
and loss: we can simulate a robot acting on a delayed or occasionally
dropped view of the shared pheromone field directly, which is exactly
what network latency and packet loss would produce, without needing an
actual multi-process or multi-machine deployment. We state this
explicitly rather than claim it is equivalent to a networked test.

Delay is modeled as: a robot's planning query in round r sees the
field state from round (r - delay_rounds), not round r. Loss is
modeled as: with probability p_loss, a robot's deposit/evaporate
contribution for a round is dropped entirely (never applied), as if
the update message never arrived.
"""
import sys
sys.path.insert(0, '.')
import numpy as np
import networkx as nx
from env_utils import make_cluttered_environment, compute_skeleton, skeleton_to_graph
from ssf_core import (init_pheromone, run_ssf_episode, deposit_and_evaporate,
                       geometric_path_length, modulated_shortest_path)


def run_delayed_lossy(G_base, n_robots=15, n_rounds=25, delay_rounds=0, p_loss=0.0, seed=0):
    rng = np.random.RandomState(seed)
    G_true = G_base.copy()   # the actual, current shared field
    init_pheromone(G_true, tau0=1.0)
    # snapshot history: field state at the end of each round, so a
    # delayed robot can "see" an older snapshot
    history = [dict((e, (G_true[e[0]][e[1]]['tau'], G_true[e[0]][e[1]]['usage']))
                     for e in G_true.edges)]
    nodes = list(G_true.nodes)

    costs, makespans = [], []
    for rnd in range(n_rounds):
        # build the graph each robot actually plans against: the
        # snapshot from `delay_rounds` rounds ago (or the current one
        # if not enough history yet)
        snap_idx = max(0, len(history) - 1 - delay_rounds)
        snapshot = history[snap_idx]
        G_view = G_base.copy()
        for e, (tau, usage) in snapshot.items():
            G_view[e[0]][e[1]]['tau'] = tau
            G_view[e[0]][e[1]]['usage'] = usage

        requests = []
        for _ in range(n_robots):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            requests.append((nodes[s], nodes[t]))
        paths = run_ssf_episode(G_view, requests, alpha=1.0, beta=2.0, gamma=0.6, kappa=4.0)

        # apply updates to the TRUE field, each independently dropped
        # with probability p_loss (simulating a lost update message)
        surviving_paths = [(p, l) for p, l in paths if rng.rand() >= p_loss]
        deposit_and_evaporate(G_true, surviving_paths, rho=0.12, Q=8.0)
        history.append(dict((e, (G_true[e[0]][e[1]]['tau'], G_true[e[0]][e[1]]['usage']))
                             for e in G_true.edges))

        if rnd >= n_rounds - 8:  # steady-state rounds
            lens = [geometric_path_length(G_true, p) for p, _ in paths]
            costs.append(np.mean(lens))
            makespans.append(max(lens) if lens else 0.0)

    return np.mean(costs), np.mean(makespans)


if __name__ == '__main__':
    grid = make_cluttered_environment(size=140, seed=2)
    free = ~grid
    skel, dist = compute_skeleton(free)
    G_raw = skeleton_to_graph(skel, dist)
    largest_cc = max(nx.connected_components(G_raw), key=len)
    G_base = G_raw.subgraph(largest_cc).copy()

    conditions = [
        ('synchronous (baseline)', dict(delay_rounds=0, p_loss=0.0)),
        ('1-round delay', dict(delay_rounds=1, p_loss=0.0)),
        ('3-round delay', dict(delay_rounds=3, p_loss=0.0)),
        ('5-round delay', dict(delay_rounds=5, p_loss=0.0)),
        ('10% update loss', dict(delay_rounds=0, p_loss=0.10)),
        ('20% update loss', dict(delay_rounds=0, p_loss=0.20)),
        ('40% update loss', dict(delay_rounds=0, p_loss=0.40)),
        ('3-round delay + 20% loss', dict(delay_rounds=3, p_loss=0.20)),
    ]
    N_SEEDS = 5

    print(f"{'Condition':28s} {'MeanCost':>10s} {'SD':>7s} {'Makespan':>10s} {'SD':>7s}")
    results = {}
    for name, kw in conditions:
        costs, makespans = [], []
        for s in range(N_SEEDS):
            c, m = run_delayed_lossy(G_base, seed=100 * s + 7, **kw)
            costs.append(c)
            makespans.append(m)
        results[name] = {
            'cost_mean': float(np.mean(costs)), 'cost_sd': float(np.std(costs)),
            'makespan_mean': float(np.mean(makespans)), 'makespan_sd': float(np.std(makespans)),
        }
        print(f"{name:28s} {np.mean(costs):10.2f} {np.std(costs):7.2f} "
              f"{np.mean(makespans):10.2f} {np.std(makespans):7.2f}")

    import json
    with open('async_stigmergy_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    print("\nSaved to async_stigmergy_results.json")

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
nodes = list(G.nodes)

thresholds = [2, 3, 4, 6, 8]
robot_counts = [20, 50, 100]

print("robots | " + " | ".join(f"thr={t}" for t in thresholds))
for n_robots in robot_counts:
    rng = np.random.RandomState(42 + n_robots)
    requests = []
    for _ in range(n_robots):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        requests.append((nodes[s], nodes[t]))
    Gs = G.copy()
    init_pheromone(Gs, tau0=1.0)
    for it in range(15):
        paths = run_ssf_episode(Gs, requests)
        deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
    usage_vals = [Gs[u][v]['usage'] for u, v in Gs.edges]
    counts = [sum(1 for u in usage_vals if u >= t) for t in thresholds]
    print(f"{n_robots:6d} | " + " | ".join(f"{c:5d}" for c in counts))

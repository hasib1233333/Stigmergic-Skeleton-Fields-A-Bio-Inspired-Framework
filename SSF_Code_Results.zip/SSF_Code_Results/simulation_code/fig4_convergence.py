import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
import time
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import (init_pheromone, run_ssf_episode, deposit_and_evaporate,
                       grid_graph_from_mask, geometric_path_length)

from plot_style import apply_style, COLORS
apply_style()

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
nodes = list(G.nodes)

n_iters = 80
n_agents = 20
N_TRIALS = 6

ssf_curves, static_curves = [], []
ssf_times, static_times = [], []

for trial in range(N_TRIALS):
    rng = np.random.RandomState(3 + trial)
    fixed_requests = []
    for _ in range(n_agents):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        fixed_requests.append((nodes[s], nodes[t]))

    Gs = G.copy()
    init_pheromone(Gs, tau0=1.0)
    ssf_curve, ssf_time = [], []
    for it in range(n_iters):
        t0 = time.perf_counter()
        paths = run_ssf_episode(Gs, fixed_requests)
        deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
        ssf_time.append(time.perf_counter() - t0)
        ssf_curve.append(np.mean([geometric_path_length(Gs, p) for p, _ in paths]))
    ssf_curves.append(ssf_curve)
    ssf_times.append(np.mean(ssf_time) * 1000)

    static_curve, static_time = [], []
    for it in range(n_iters):
        t0 = time.perf_counter()
        lens = [nx.shortest_path_length(G, s, t, weight='weight') for s, t in fixed_requests]
        static_time.append(time.perf_counter() - t0)
        static_curve.append(np.mean(lens))
    static_curves.append(static_curve)
    static_times.append(np.mean(static_time) * 1000)

ssf_curves = np.array(ssf_curves)
static_curves = np.array(static_curves)
ssf_mean, ssf_sem = ssf_curves.mean(axis=0), ssf_curves.std(axis=0) / np.sqrt(N_TRIALS)
static_mean, static_sem = static_curves.mean(axis=0), static_curves.std(axis=0) / np.sqrt(N_TRIALS)

# --- Raw-grid ACO baseline (single trial: cost prohibits repeated trials) ---
Ggrid = grid_graph_from_mask(free, step=2)
init_pheromone(Ggrid, tau0=1.0)
rng = np.random.RandomState(3)
fixed_requests = []
for _ in range(n_agents):
    s, t = rng.choice(len(nodes), size=2, replace=False)
    fixed_requests.append((nodes[s], nodes[t]))
grid_requests = [(nearest_node(Ggrid, *s), nearest_node(Ggrid, *t)) for s, t in fixed_requests]
aco_curve, aco_time = [], []
n_iters_grid = 30
for it in range(n_iters_grid):
    t0 = time.perf_counter()
    paths = run_ssf_episode(Ggrid, grid_requests)
    deposit_and_evaporate(Ggrid, paths, rho=0.12, Q=10.0)
    aco_time.append(time.perf_counter() - t0)
    aco_curve.append(np.mean([geometric_path_length(Ggrid, p) for p, _ in paths]))

fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.0))
ax = axes[0]
it_range = np.arange(n_iters)
ax.plot(it_range, ssf_mean, color='#0072BD', lw=1.8, label='Proposed SSF (skeleton + stigmergy)')
ax.fill_between(it_range, ssf_mean - 1.96 * ssf_sem, ssf_mean + 1.96 * ssf_sem,
                 color='#0072BD', alpha=0.2)
ax.plot(it_range, static_mean, color='#7F7F7F', lw=1.4, ls='--',
        label='Static skeleton shortest path (no stigmergy)')
ax.fill_between(it_range, static_mean - 1.96 * static_sem, static_mean + 1.96 * static_sem,
                 color='#7F7F7F', alpha=0.2)
ax.plot(range(n_iters_grid), aco_curve, color='#A2142F', lw=1.4, ls=':',
        label='Raw-grid ACO baseline (single trial)')
ax.set_xlabel("Iteration (planning round)")
ax.set_ylabel("Mean path cost over 20 concurrent requests")
ax.set_title("(a) Convergence of mean path cost (shaded = 95% CI, n=6 trials)", fontsize=9.7)
ax.grid(alpha=0.25)

ax2 = axes[1]
methods = ['Proposed\nSSF', 'Static\nskeleton', 'Raw-grid\nACO']
times = [np.mean(ssf_times), np.mean(static_times), np.mean(aco_time) * 1000]
stds = [np.std(ssf_times), np.std(static_times), np.std(aco_time) * 1000]
bars = ax2.bar(methods, times, yerr=stds, color=['#0072BD', '#7F7F7F', '#A2142F'],
                alpha=0.85, capsize=4, width=0.55)
ax2.set_ylabel("Mean per-round planning time (ms)")
ax2.set_yscale('log')
ax2.set_title("(b) Planning-time cost per round (n=6 trials for SSF/static)", fontsize=9.7)
ax2.grid(alpha=0.25, axis='y')
for b, tm in zip(bars, times):
    ax2.text(b.get_x() + b.get_width() / 2, tm * 1.15, f"{tm:.1f}", ha='center', fontsize=8.5)

# figure-level legend placed below both panels, so it can never overlap
# the plotted curves regardless of their shape
handles, labels = ax.get_legend_handles_labels()
fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, -0.06),
           ncol=1, fontsize=8, frameon=True)

plt.tight_layout(rect=[0, 0.08, 1, 1])
plt.savefig('/home/claude/smsn/figs/fig4_convergence.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig4_convergence.png', bbox_inches='tight', dpi=300)
print("fig4 done", ssf_mean[-1], static_mean[-1], aco_curve[-1])
print("times ms:", times)

import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
import time
from env_utils import (make_office_environment, make_cluttered_environment,
                        make_maze_environment, compute_skeleton, skeleton_to_graph, nearest_node)
from ssf_core import (init_pheromone, run_ssf_episode, deposit_and_evaporate,
                       geometric_path_length, rrt_star)

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

envs = {
    "Office": make_office_environment(size=140, seed=1),
    "Cluttered": make_cluttered_environment(size=140, seed=2),
    "Maze": make_maze_environment(size=140, seed=3),
}

n_trials = 10
n_agents = 15
n_rounds = 40

records = {name: {"SSF": [], "Static": [], "RRT*": []} for name in envs}
time_records = {name: {"SSF": [], "Static": [], "RRT*": []} for name in envs}
rrt_success = {name: [] for name in envs}

rng_master = np.random.RandomState(42)

env_seed_offset = {"Office": 11, "Cluttered": 23, "Maze": 37}
for name, grid in envs.items():
    free = ~grid
    skel, dist = compute_skeleton(free)
    G_raw = skeleton_to_graph(skel, dist)
    largest_cc = max(nx.connected_components(G_raw), key=len)
    G = G_raw.subgraph(largest_cc).copy()
    nodes = list(G.nodes)
    for trial in range(n_trials):
        rng = np.random.RandomState(1000 * trial + env_seed_offset[name])
        requests = []
        for _ in range(n_agents):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            requests.append((nodes[s], nodes[t]))

        # SSF proposed
        Gs = G.copy()
        init_pheromone(Gs, tau0=1.0)
        for it in range(n_rounds):
            t0 = time.perf_counter()
            paths = run_ssf_episode(Gs, requests)
            deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
            dt = time.perf_counter() - t0
        records[name]["SSF"].append(np.mean([geometric_path_length(Gs, p) for p, _ in paths]))
        time_records[name]["SSF"].append(dt * 1000 / n_agents)

        # Static skeleton shortest path (ablation, no stigmergy)
        t0 = time.perf_counter()
        lens = [nx.shortest_path_length(G, s, t, weight='weight') for s, t in requests]
        dt = time.perf_counter() - t0
        records[name]["Static"].append(np.mean(lens))
        time_records[name]["Static"].append(dt * 1000 / n_agents)

        # RRT* baseline (subset of agents -- expensive)
        rrt_lens, rrt_times = [], []
        rrt_attempts = 0
        for s, t in requests[:5]:
            rrt_attempts += 1
            t0 = time.perf_counter()
            path, cost = rrt_star(grid, s, t, n_iter=1500, step=5.0, seed=trial)
            dt = time.perf_counter() - t0
            if path is not None:
                rrt_lens.append(cost)
                rrt_times.append(dt * 1000)
        if rrt_lens:
            records[name]["RRT*"].append(np.mean(rrt_lens))
            time_records[name]["RRT*"].append(np.mean(rrt_times))
        rrt_success[name].append(len(rrt_lens) / rrt_attempts)

methods = ["SSF", "Static", "RRT*"]
colors = {"SSF": "#1f77b4", "Static": "#7f7f7f", "RRT*": "#d62728"}

from scipy import stats

def sig_stars(p):
    if np.isnan(p):
        return 'n.s.'
    if p < 0.001:
        return '***'
    if p < 0.01:
        return '**'
    if p < 0.05:
        return '*'
    return 'n.s.'

sig_annotations = {}
for name in envs:
    a = np.array(records[name]["SSF"])
    b = np.array(records[name]["Static"])
    if np.allclose(a, b):
        sig_annotations[name] = (0.0, 'n.s.')
        continue
    try:
        _, p = stats.wilcoxon(a, b)
    except ValueError:
        p = np.nan
    sig_annotations[name] = (p, sig_stars(p))
    print(f"Wilcoxon SSF vs Static, {name}: p={p}")

fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.4))
ax = axes[0]
positions = []
data = []
labels = []
box_colors = []
width = 0.22
x0 = np.arange(len(envs))
for i, m in enumerate(methods):
    for j, name in enumerate(envs):
        data.append(records[name][m])
        positions.append(x0[j] + (i - 1) * width)
        box_colors.append(colors[m])
bp = ax.boxplot(data, positions=positions, widths=width * 0.9, patch_artist=True,
                showfliers=False)
for patch, c in zip(bp['boxes'], box_colors):
    patch.set_facecolor(c)
    patch.set_alpha(0.65)

# significance brackets between SSF and Static boxes for each environment
for j, name in enumerate(envs):
    x_ssf = x0[j] + (0 - 1) * width
    x_static = x0[j] + (1 - 1) * width
    ymax = max(max(records[name]["SSF"]), max(records[name]["Static"]))
    yr = ymax * 1.08
    ax.plot([x_ssf, x_ssf, x_static, x_static],
            [ymax * 1.02, yr, yr, ymax * 1.02], color='black', lw=0.8)
    p, stars = sig_annotations[name]
    ax.text((x_ssf + x_static) / 2, yr * 1.01, stars, ha='center', fontsize=9)

ax.set_xticks(x0)
ax.set_xticklabels(list(envs.keys()))
ax.set_ylabel("Mean path length per round (px)")
ax.set_title("(a) Path-length distribution across environments\n(10 trials, 15 concurrent requests/round; "
              "brackets = Wilcoxon SSF vs.\\ Static)", fontsize=9.3)
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[m], alpha=0.65) for m in methods]
ax.legend(handles, methods, fontsize=8, loc='upper left')
ax.grid(alpha=0.2, axis='y')
ax.set_ylim(top=ax.get_ylim()[1] * 1.12)

ax2 = axes[1]
x = np.arange(len(envs))
for i, m in enumerate(methods):
    means = [np.mean(time_records[name][m]) for name in envs]
    stds = [np.std(time_records[name][m]) for name in envs]
    ax2.bar(x + (i - 1) * width, means, width * 0.9, yerr=stds, color=colors[m],
            alpha=0.8, capsize=3, label=m)
ax2.set_xticks(x)
ax2.set_xticklabels(list(envs.keys()))
ax2.set_ylabel("Mean per-agent planning time (ms)")
ax2.set_yscale('log')
ax2.set_title("(b) Per-agent planning-time cost across environments", fontsize=9.8)
ax2.legend(fontsize=8)
ax2.grid(alpha=0.2, axis='y')

plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig7_statistics.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig7_statistics.png', bbox_inches='tight', dpi=300)
print("fig7 done")
for name in envs:
    for m in methods:
        print(name, m, "len_mean=%.2f" % np.mean(records[name][m]),
              "time_mean_ms=%.3f" % np.mean(time_records[name][m]))
    print(name, "RRT* success rate=%.2f" % np.mean(rrt_success[name]))

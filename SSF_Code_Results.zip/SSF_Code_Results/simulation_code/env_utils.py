"""
Environment generation and medial-axis skeleton graph construction
for the Stigmergic Skeleton Field (SSF) framework.
"""
import numpy as np
import networkx as nx
from skimage.morphology import medial_axis, skeletonize
from scipy.ndimage import label, binary_dilation
from scipy.spatial import cKDTree


def make_office_environment(size=140, seed=1):
    """Corridor + room style environment (office-like)."""
    rng = np.random.RandomState(seed)
    grid = np.zeros((size, size), dtype=bool)  # False = free
    # outer walls
    grid[0, :] = True
    grid[-1, :] = True
    grid[:, 0] = True
    grid[:, -1] = True
    # main corridors
    grid[size // 2 - 2:size // 2 + 2, :] = False
    grid[:, size // 3 - 2:size // 3 + 2] = False
    # rooms partitions
    n_rooms = 6
    for i in range(n_rooms):
        x0 = rng.randint(5, size - 25)
        y0 = rng.randint(5, size - 25)
        w = rng.randint(14, 22)
        h = rng.randint(14, 22)
        wall = np.zeros((size, size), dtype=bool)
        wall[y0:y0 + h, x0:x0 + w] = True
        wall[y0 + 2:y0 + h - 2, x0 + 2:x0 + w - 2] = False
        # door gap
        gx = rng.randint(x0 + 2, x0 + w - 2)
        wall[y0:y0 + 2, gx:gx + 3] = False
        grid = grid | wall
    return grid


def make_cluttered_environment(size=140, seed=2, n_obstacles=45):
    rng = np.random.RandomState(seed)
    grid = np.zeros((size, size), dtype=bool)
    grid[0, :] = True
    grid[-1, :] = True
    grid[:, 0] = True
    grid[:, -1] = True
    for _ in range(n_obstacles):
        cx, cy = rng.randint(10, size - 10, size=2)
        r = rng.randint(3, 7)
        yy, xx = np.ogrid[:size, :size]
        mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
        grid = grid | mask
    return grid


def make_maze_environment(size=140, seed=3, cell=14):
    """Randomized maze via recursive backtracker on a coarse grid, then upsampled."""
    rng = np.random.RandomState(seed)
    n = size // cell
    visited = np.zeros((n, n), dtype=bool)
    hwalls = np.ones((n + 1, n), dtype=bool)   # horizontal walls
    vwalls = np.ones((n, n + 1), dtype=bool)   # vertical walls

    stack = [(0, 0)]
    visited[0, 0] = True
    while stack:
        cy, cx = stack[-1]
        neighbors = []
        for dy, dx, wh, idx in [(-1, 0, 'h', (cy, cx)), (1, 0, 'h', (cy + 1, cx)),
                                 (0, -1, 'v', (cy, cx)), (0, 1, 'v', (cy, cx + 1))]:
            ny, nx_ = cy + dy, cx + dx
            if 0 <= ny < n and 0 <= nx_ < n and not visited[ny, nx_]:
                neighbors.append((ny, nx_, wh, idx))
        if not neighbors:
            stack.pop()
            continue
        ny, nx_, wh, idx = neighbors[rng.randint(len(neighbors))]
        if wh == 'h':
            hwalls[idx] = False
        else:
            vwalls[idx] = False
        visited[ny, nx_] = True
        stack.append((ny, nx_))

    grid = np.ones((size, size), dtype=bool)
    for j in range(n):
        for i in range(n):
            y0, x0 = j * cell, i * cell
            grid[y0 + 1:y0 + cell - 1, x0 + 1:x0 + cell - 1] = False
    for j in range(n + 1):
        for i in range(n):
            if not hwalls[j, i]:
                y0, x0 = j * cell, i * cell
                grid[max(0, y0 - 1):y0 + 2, x0 + 1:x0 + cell - 1] = False
    for j in range(n):
        for i in range(n + 1):
            if not vwalls[j, i]:
                y0, x0 = j * cell, i * cell
                grid[y0 + 1:y0 + cell - 1, max(0, x0 - 1):x0 + 2] = False
    grid[0, :] = True
    grid[-1, :] = True
    grid[:, 0] = True
    grid[:, -1] = True
    return grid


def compute_skeleton(free_mask):
    """Medial-axis skeleton with distance transform (grassfire-style propagation)."""
    skel, dist = medial_axis(free_mask, return_distance=True)
    return skel, dist


def skeleton_to_graph(skel, dist, prune_len=3):
    """Convert a binary skeleton image into a topology graph (nodes = junctions/
    endpoints, edges = skeleton branches with Euclidean length + min clearance)."""
    ys, xs = np.nonzero(skel)
    pts = set(zip(ys.tolist(), xs.tolist()))

    def neighbors(p):
        y, x = p
        out = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                q = (y + dy, x + dx)
                if q in pts:
                    out.append(q)
        return out

    deg = {p: len(neighbors(p)) for p in pts}
    junctions = {p for p, d in deg.items() if d != 2}

    # A connected component whose pixels are all degree exactly 2 is a
    # pure closed loop with no natural endpoint or branch point (this
    # arises, for instance, when a locally re-cropped sub-image's free
    # space forms an annulus around an obstacle entirely inside the
    # crop). Without a junction such a component is invisible to the
    # traversal below and would be silently dropped -- including any
    # part of it that a caller expected to still be there. We promote
    # one point per such component to a synthetic junction so it is
    # always represented, at the cost of one self-loop-like edge that
    # traverses the rest of the cycle.
    if pts:
        seen = set()
        for p in list(pts):
            if p in seen or p in junctions:
                continue
            comp = set()
            stack = [p]
            while stack:
                q = stack.pop()
                if q in comp:
                    continue
                comp.add(q)
                stack.extend(nb for nb in neighbors(q) if nb not in comp)
            seen |= comp
            if comp and not (comp & junctions):
                junctions.add(min(comp))

    G = nx.Graph()
    for p in junctions:
        G.add_node(p, pos=(p[1], p[0]), clearance=float(dist[p]))

    visited_dir = set()
    for j in junctions:
        for n0 in neighbors(j):
            if (j, n0) in visited_dir:
                continue
            path = [j, n0]
            visited_dir.add((j, n0))
            prev, cur = j, n0
            while cur not in junctions:
                nxts = [q for q in neighbors(cur) if q != prev]
                if not nxts:
                    break
                nxt = nxts[0]
                visited_dir.add((cur, nxt))
                path.append(nxt)
                prev, cur = cur, nxt
            if cur in junctions and len(path) >= 2:
                length = sum(np.hypot(path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
                             for i in range(len(path) - 1))
                if length < prune_len and deg.get(path[-1], 0) == 1:
                    continue
                min_clear = min(dist[p] for p in path)
                if G.has_edge(j, cur):
                    if G[j][cur]['weight'] <= length:
                        continue
                G.add_edge(j, cur, weight=length, clearance=min_clear,
                           path=path)
    return G


def make_warehouse_environment(size=140, seed=6, room_size=16):
    """Room-based environment following the room-size parametrization of
    the standard grid-pathfinding benchmark suite (rooms of size 8, 16,
    32, 64 cells; Sturtevant 2012), regenerated here rather than using
    the literal distributed map files, which could not be retrieved in
    this environment. Cells are grouped into room_size x room_size
    blocks separated by walls with a single door gap per shared wall."""
    rng = np.random.RandomState(seed)
    grid = np.zeros((size, size), dtype=bool)
    grid[0, :] = True; grid[-1, :] = True
    grid[:, 0] = True; grid[:, -1] = True
    n_rooms = size // room_size
    for i in range(1, n_rooms):
        pos = i * room_size
        grid[pos, :] = True
        grid[:, pos] = True
    for i in range(n_rooms):
        for j in range(n_rooms):
            y0, x0 = i * room_size, j * room_size
            if i < n_rooms - 1:
                gap = rng.randint(x0 + 2, min(x0 + room_size - 2, size - 2))
                grid[y0 + room_size, gap:gap + 2] = False
            if j < n_rooms - 1:
                gap = rng.randint(y0 + 2, min(y0 + room_size - 2, size - 2))
                grid[gap:gap + 2, x0 + room_size] = False
    return grid


def make_random_fill_environment(size=140, seed=7, fill_pct=20):
    """Random-fill environment following the occupancy-percentage
    parametrization of the standard grid-pathfinding benchmark suite
    (10/15/.../40% blocked cells; Sturtevant 2012), regenerated here
    with the same parametrization rather than the literal distributed
    maps."""
    rng = np.random.RandomState(seed)
    grid = rng.rand(size, size) < (fill_pct / 100.0)
    grid[0, :] = True; grid[-1, :] = True
    grid[:, 0] = True; grid[:, -1] = True
    return grid


def nearest_node(G, y, x):
    nodes = list(G.nodes)
    tree = cKDTree(np.array(nodes))
    _, idx = tree.query([y, x])
    return nodes[idx]

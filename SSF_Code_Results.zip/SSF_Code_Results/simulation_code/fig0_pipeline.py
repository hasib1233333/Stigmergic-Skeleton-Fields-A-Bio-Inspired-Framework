import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from matplotlib.collections import LineCollection
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate
from plot_style import apply_style, COLORS

apply_style()

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
init_pheromone(G, tau0=1.0)
nodes = list(G.nodes)

rng = np.random.RandomState(3)
for it in range(25):
    requests = []
    for _ in range(20):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        requests.append((nodes[s], nodes[t]))
    paths = run_ssf_episode(G, requests)
    deposit_and_evaporate(G, paths, rho=0.12, Q=10.0)

fig, axes = plt.subplots(1, 6, figsize=(22, 5.2))
panel_titles = [
    "1. Environment",
    "2. Medial-axis\nskeleton",
    "3. Pheromone\nfield",
    "4. Congestion-aware\nrouting",
    "5. Localized\nre-skeletonization",
    "6. Multi-robot\nnavigation",
]

# --- Panel 1: raw environment ---
ax = axes[0]
ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.9)
ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

# --- Panel 2: skeleton graph ---
ax = axes[1]
ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.5)
ys, xs = np.nonzero(skel)
ax.scatter(xs, ys, s=0.4, c=COLORS['blue'], linewidths=0)
deg3 = [n for n in G.nodes if G.degree[n] >= 3]
if deg3:
    yj, xj = zip(*deg3)
    ax.scatter(xj, yj, s=8, c=COLORS['orange'], zorder=5)
ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

# --- Panel 3: pheromone field ---
ax = axes[2]
ax.imshow(grid, cmap='gray_r', origin='upper', vmin=0, vmax=1.6)
segs, vals = [], []
for u, v in G.edges:
    segs.append([(u[1], u[0]), (v[1], v[0])])
    vals.append(G[u][v]['tau'])
vals = np.array(vals)
vmax = np.percentile(vals, 99)
lc = LineCollection(segs, array=vals, cmap='inferno',
                     linewidths=1.2 + 3.5 * (vals / max(vmax, 1e-6)),
                     norm=plt.Normalize(0, vmax))
ax.add_collection(lc)
ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

# --- Panel 4: congestion-aware routing (schematic: two crossing paths) ---
ax = axes[3]
ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.5)
from ssf_core import modulated_shortest_path
Gc = G.copy()
demo_pairs = [(nodes[0], nodes[len(nodes) // 2]), (nodes[3], nodes[len(nodes) // 3]),
              (nodes[7], nodes[-4])]
for i, (s, t) in enumerate(demo_pairs):
    try:
        path, length = modulated_shortest_path(Gc, s, t, gamma=0.6, kappa=4.0)
        ys_p = [p[0] for p in path]; xs_p = [p[1] for p in path]
        color = [COLORS['blue'], COLORS['orange'], COLORS['green']][i % 3]
        ax.plot(xs_p, ys_p, color=color, lw=1.6, alpha=0.9)
        deposit_and_evaporate(Gc, [(path, length)], rho=0.0, Q=6.0)
    except Exception:
        pass
ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

# --- Panel 5: LIR local patch ---
ax = axes[4]
from ssf_core import apply_dynamic_obstacle, local_reskeletonize
free1, blocked = apply_dynamic_obstacle(free, 70, 70, 8)
disp = grid.astype(float).copy()
disp[blocked] = 1.0
ax.imshow(disp, cmap='Greys', origin='upper', alpha=0.9)
box = plt.Rectangle((70 - 8 - 18, 70 - 8 - 18), 2 * (8 + 18), 2 * (8 + 18),
                     fill=False, edgecolor=COLORS['purple'], lw=1.6, ls='--')
ax.add_patch(box)
ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

# --- Panel 6: multi-robot navigation (final paths) ---
ax = axes[5]
ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.5)
rng2 = np.random.RandomState(21)
for i in range(6):
    s, t = rng2.choice(len(nodes), size=2, replace=False)
    try:
        path, length = modulated_shortest_path(G, nodes[s], nodes[t], gamma=0.6, kappa=4.0)
        ys_p = [p[0] for p in path]; xs_p = [p[1] for p in path]
        color = [COLORS['blue'], COLORS['orange'], COLORS['green'],
                  COLORS['purple'], COLORS['gray'], COLORS['cyan']][i]
        ax.plot(xs_p, ys_p, color=color, lw=1.4, alpha=0.9)
        ax.scatter([xs_p[0]], [ys_p[0]], s=14, color=color, zorder=5)
        ax.scatter([xs_p[-1]], [ys_p[-1]], marker='*', s=35, color=color, zorder=5)
    except Exception:
        pass
ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)

for ax, title in zip(axes, panel_titles):
    ax.set_title(title, fontsize=13, fontweight='bold', pad=8)
    for s in ax.spines.values():
        s.set_edgecolor('0.6')
        s.set_visible(True)
        s.set_linewidth(0.8)

# Explicit, deterministic layout: reserve a fixed top margin for the
# title band and a fixed side/bottom margin, rather than relying on
# tight_layout (which does not correctly account for a suptitle placed
# above y=1 and was previously causing both overlap with the panel
# titles and a large blank band under the panels once cropped).
plt.subplots_adjust(left=0.01, right=0.99, bottom=0.03, top=0.82, wspace=0.10)

# arrows between panels, drawn in the finalized (post-adjust) layout
fig.canvas.draw()
for i in range(5):
    bbox_a = axes[i].get_position()
    bbox_b = axes[i + 1].get_position()
    y_mid = (bbox_a.y0 + bbox_a.y1) / 2
    arrow = FancyArrowPatch((bbox_a.x1 + 0.004, y_mid), (bbox_b.x0 - 0.004, y_mid),
                             transform=fig.transFigure, arrowstyle='-|>',
                             mutation_scale=20, color='0.35', lw=1.6,
                             clip_on=False)
    fig.add_artist(arrow)

title_lines = "The SSF pipeline: environment $\\rightarrow$ skeleton $\\rightarrow$ pheromone field $\\rightarrow$ congestion-aware routing $\\rightarrow$ localized re-skeletonization $\\rightarrow$ multi-robot navigation"
fig.text(0.5, 0.97, title_lines, ha='center', va='top', fontsize=13)

plt.savefig('/home/claude/smsn/figs/fig0_pipeline.pdf', bbox_inches='tight', pad_inches=0.08)
plt.savefig('/home/claude/smsn/figs/fig0_pipeline.png', bbox_inches='tight', pad_inches=0.08, dpi=300)
print("fig0 (pipeline / graphical abstract) done")

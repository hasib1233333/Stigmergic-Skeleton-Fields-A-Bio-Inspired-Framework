import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph, nearest_node
from ssf_core import (init_pheromone, run_ssf_episode, deposit_and_evaporate,
                       geometric_path_length, grid_graph_from_mask)

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
nodes = list(G.nodes)

Ggrid = grid_graph_from_mask(free, step=2)

ROBOT_COUNTS = [5, 20, 50, 100]
N_ROUNDS = 15
N_TRIALS = 5

ssf_time_results = {n: [] for n in ROBOT_COUNTS}
ssf_cong_results = {n: [] for n in ROBOT_COUNTS}
aco_time_results = {n: [] for n in ROBOT_COUNTS}

for n_robots in ROBOT_COUNTS:
    for trial in range(N_TRIALS):
        rng = np.random.RandomState(1000 * trial + n_robots)
        requests = []
        for _ in range(n_robots):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            requests.append((nodes[s], nodes[t]))

        Gs = G.copy()
        init_pheromone(Gs, tau0=1.0)
        round_times = []
        for it in range(N_ROUNDS):
            t0 = time.perf_counter()
            paths = run_ssf_episode(Gs, requests)
            deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
            round_times.append(time.perf_counter() - t0)
        ssf_time_results[n_robots].append(np.mean(round_times) * 1000 / n_robots)
        congested = sum(1 for u, v in Gs.edges if Gs[u][v]['usage'] >= 4)
        ssf_cong_results[n_robots].append(congested)

        # raw-grid ACO at matching robot counts (capped rounds due to cost)
        grid_requests = []
        for s, t in requests:
            grid_requests.append((nearest_node(Ggrid, *s), nearest_node(Ggrid, *t)))
        Gg = Ggrid.copy()
        init_pheromone(Gg, tau0=1.0)
        t0 = time.perf_counter()
        paths_g = run_ssf_episode(Gg, grid_requests)
        deposit_and_evaporate(Gg, paths_g, rho=0.12, Q=10.0)
        dt = time.perf_counter() - t0
        aco_time_results[n_robots].append(dt * 1000 / max(n_robots, 1))

fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.0))
ax = axes[0]
ssf_means = [np.mean(ssf_time_results[n]) for n in ROBOT_COUNTS]
ssf_stds = [np.std(ssf_time_results[n]) for n in ROBOT_COUNTS]
aco_means = [np.mean(aco_time_results[n]) for n in ROBOT_COUNTS]
aco_stds = [np.std(aco_time_results[n]) for n in ROBOT_COUNTS]
ax.errorbar(ROBOT_COUNTS, ssf_means, yerr=ssf_stds, marker='o', color='#1f77b4',
            label='Proposed SSF (skeleton)', capsize=3, lw=1.8)
ax.errorbar(ROBOT_COUNTS, aco_means, yerr=aco_stds, marker='s', color='#d62728',
            label='Raw-grid ACO', capsize=3, lw=1.8)
ax.set_xlabel('Number of concurrent robots')
ax.set_ylabel('Mean per-robot planning time (ms)')
ax.set_yscale('log')
ax.set_title('(a) Per-robot planning time vs. robot count', fontsize=10)
ax.legend(fontsize=8.5)
ax.grid(alpha=0.25)

ax2 = axes[1]
cong_means = [np.mean(ssf_cong_results[n]) for n in ROBOT_COUNTS]
cong_stds = [np.std(ssf_cong_results[n]) for n in ROBOT_COUNTS]
ax2.errorbar(ROBOT_COUNTS, cong_means, yerr=cong_stds, marker='D', color='#2ca02c',
             capsize=3, lw=1.8)
ax2.set_xlabel('Number of concurrent robots')
ax2.set_ylabel('Congested edges (usage $\\geq$ 4)')
ax2.set_title('(b) Congestion vs. robot count (proposed SSF)', fontsize=10)
ax2.grid(alpha=0.25)

fig.suptitle(f'Scaling with robot count on the office environment ({N_TRIALS} trials per count)',
             fontsize=10.2, y=1.03)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig9_robot_scaling.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig9_robot_scaling.png', bbox_inches='tight', dpi=300)

print("=== Robot scaling summary ===")
for n in ROBOT_COUNTS:
    print(n, 'SSF ms/robot=%.4f' % np.mean(ssf_time_results[n]),
          'ACO ms/robot=%.4f' % np.mean(aco_time_results[n]),
          'congestion=%.1f' % np.mean(ssf_cong_results[n]))
print("fig9 done")

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from env_utils import make_cluttered_environment, compute_skeleton, skeleton_to_graph
from ssf_core import apply_dynamic_obstacle, full_reskeletonize, local_reskeletonize

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

sizes = [80, 120, 160, 200, 240, 280, 500, 1000]
n_trials = 6
full_times = {s: [] for s in sizes}
local_times = {s: [] for s in sizes}
speedups = {s: [] for s in sizes}
node_counts = {s: [] for s in sizes}
edge_counts = {s: [] for s in sizes}
fallback_counts = {s: 0 for s in sizes}
trial_counts = {s: 0 for s in sizes}

for size in sizes:
    for trial in range(n_trials):
        n_obs = max(int(size * size / 400 * 0.9), 15)
        grid = make_cluttered_environment(size=size, seed=100 + trial, n_obstacles=n_obs)
        free = ~grid
        skel, dist = compute_skeleton(free)
        G0 = skeleton_to_graph(skel, dist)
        cy, cx = size // 2 + trial * 5, size // 2 - trial * 5
        r = max(size // 20, 5)
        free1, blocked = apply_dynamic_obstacle(free, cy, cx, r)
        if not blocked.any():
            continue
        _, t_full = full_reskeletonize(free1)
        _, t_local, lir_diag = local_reskeletonize(G0, free1, blocked, pad=max(size // 12, 10))
        full_times[size].append(t_full * 1000)
        local_times[size].append(t_local * 1000)
        speedups[size].append(t_full / max(t_local, 1e-6))
        node_counts[size].append(G0.number_of_nodes())
        edge_counts[size].append(G0.number_of_edges())
        trial_counts[size] += 1
        if lir_diag.get('fallback'):
            fallback_counts[size] += 1

mean_full = [np.mean(full_times[s]) for s in sizes]
std_full = [np.std(full_times[s]) for s in sizes]
mean_local = [np.mean(local_times[s]) for s in sizes]
std_local = [np.std(local_times[s]) for s in sizes]
mean_speedup = [np.mean(speedups[s]) for s in sizes]
mean_nodes = [np.mean(node_counts[s]) for s in sizes]
mean_edges = [np.mean(edge_counts[s]) for s in sizes]

fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.0))
ax = axes[0]
ax.errorbar(sizes, mean_full, yerr=std_full, marker='o', color='#d62728',
            label='Full re-skeletonization', capsize=3, lw=1.6)
ax.errorbar(sizes, mean_local, yerr=std_local, marker='s', color='#1f77b4',
            label='Proposed LIR (local)', capsize=3, lw=1.6)
ax.set_xscale('log')
ax.set_yscale('log')
ax.set_xlabel("Environment size (grid cells per side, log scale)")
ax.set_ylabel("Re-skeletonization time (ms, log scale)")
ax.set_title("(a) Absolute update cost vs. map size", fontsize=10.5)
ax.legend(fontsize=8.2)
ax.grid(alpha=0.25, which='both')

ax2 = axes[1]
ax2.plot(sizes, mean_speedup, marker='D', color='#2ca02c', lw=1.8)
ax2.fill_between(sizes,
                  [np.mean(speedups[s]) - np.std(speedups[s]) for s in sizes],
                  [np.mean(speedups[s]) + np.std(speedups[s]) for s in sizes],
                  color='#2ca02c', alpha=0.15)
ax2.set_xscale('log')
ax2.set_xlabel("Environment size (grid cells per side, log scale)")
ax2.set_ylabel("Speedup factor (full / LIR)")
ax2.set_title("(b) LIR speedup vs. map size", fontsize=10.5)
ax2.grid(alpha=0.25)

ax3 = axes[2]
ax3.plot(sizes, mean_nodes, marker='o', color='#8c564b', lw=1.6, label='skeleton nodes')
ax3.plot(sizes, mean_edges, marker='^', color='#e377c2', lw=1.6, label='skeleton edges')
ax3.set_xscale('log')
ax3.set_yscale('log')
ax3.set_xlabel("Environment size (grid cells per side, log scale)")
ax3.set_ylabel("Count (log scale, memory proxy)")
ax3.set_title("(c) Skeleton graph size vs. map size", fontsize=10.5)
ax3.legend(fontsize=8.2)
ax3.grid(alpha=0.25, which='both')

fig.suptitle(f"Scalability of localized incremental re-skeletonization (LIR) from "
             f"80 to 1000 grid cells per side, averaged over {n_trials} trials per size",
             fontsize=10.2, y=1.03)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig6_scalability.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig6_scalability.png', bbox_inches='tight', dpi=300)
print("fig6 done")
for s in sizes:
    i = sizes.index(s)
    print(s, 'full=%.2f'%mean_full[i], 'local=%.2f'%mean_local[i], 'speedup=%.2f'%mean_speedup[i],
          'nodes=%.0f'%mean_nodes[i], 'edges=%.0f'%mean_edges[i],
          'fallback=%d/%d'%(fallback_counts[s], trial_counts[s]))

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import networkx as nx
import time
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate, geometric_path_length
from advanced_baselines import cbs_solve

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G_raw = skeleton_to_graph(skel, dist)
largest_cc = max(nx.connected_components(G_raw), key=len)
G = G_raw.subgraph(largest_cc).copy()
for n in G.nodes:
    G.nodes[n]['_h'] = 0.0
nodes = list(G.nodes)

AGENT_COUNTS = [2, 3, 4, 6, 8, 10]
TIME_BUDGET = 8.0

print("N_agents | CBS solved | CBS cost | CBS time(s) | SSF cost | SSF time(ms/round)")
for n_agents in AGENT_COUNTS:
    rng = np.random.RandomState(77 + n_agents)
    agents = []
    for _ in range(n_agents):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        agents.append((nodes[s], nodes[t]))

    cbs_paths, cbs_cost, cbs_time, solved = cbs_solve(G, agents, time_budget_s=TIME_BUDGET, max_t=200)
    if solved:
        cbs_geo_cost = 0.0
        for p in cbs_paths:
            node_seq = [n for n, t in p]
            # collapse consecutive duplicate nodes (wait actions) before measuring length
            collapsed = [node_seq[0]]
            for nd in node_seq[1:]:
                if nd != collapsed[-1]:
                    collapsed.append(nd)
            cbs_geo_cost += sum(G[collapsed[i]][collapsed[i + 1]]['weight']
                                 for i in range(len(collapsed) - 1))
    else:
        cbs_geo_cost = float('nan')

    Gs = G.copy()
    init_pheromone(Gs, tau0=1.0)
    for it in range(30):
        t0 = time.perf_counter()
        paths = run_ssf_episode(Gs, agents)
        deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
        dt = time.perf_counter() - t0
    ssf_cost = sum(geometric_path_length(Gs, p) for p, _ in paths)

    print(f"{n_agents:8d} | {str(solved):10s} | {cbs_geo_cost if solved else float('nan'):8.1f} | "
          f"{cbs_time:10.3f} | {ssf_cost:8.1f} | {dt*1000:8.3f}")

import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from env_utils import make_cluttered_environment, compute_skeleton, skeleton_to_graph
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate, geometric_path_length

plt.rcParams.update({"font.family": "serif", "font.size": 10.5, "figure.dpi": 300})

grid = make_cluttered_environment(size=140, seed=2)
free = ~grid
skel, dist = compute_skeleton(free)
G = skeleton_to_graph(skel, dist)
nodes = list(G.nodes)

n_robots = 10
n_rounds = 20
LINESTYLES = ['-', '--', '-.', ':']


def offset_path(xs, ys, offset_px):
    """Offset a polyline perpendicular to its local direction so that
    overlapping robot paths fan out visually instead of stacking exactly
    on top of one another (a standard transit-map bundling trick)."""
    xs = np.array(xs, dtype=float)
    ys = np.array(ys, dtype=float)
    if len(xs) < 2:
        return xs, ys
    dx = np.gradient(xs)
    dy = np.gradient(ys)
    norm = np.hypot(dx, dy)
    norm[norm == 0] = 1.0
    perp_x = -dy / norm
    perp_y = dx / norm
    return xs + perp_x * offset_px, ys + perp_y * offset_px


fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.8))
titles = ["(a) No stigmergy (\\gamma=0)", "(b) Stigmergic congestion-aware routing (proposed)"]

# Both conditions replay the *identical* sequence of 20 rounds of 10
# random requests (same RNG seed, same call pattern), using the same
# batch-then-update semantics as run_ssf_episode/deposit_and_evaporate
# everywhere else in the paper (Eqs. 1-3): every robot in a round plans
# against the graph state left by the *previous* round, not against
# its round-mates' just-made decisions. An earlier version of this
# figure updated pheromone after each individual robot within a single
# round, which is a materially different (sequential, order-dependent)
# coordination model inconsistent with the rest of the paper; this
# version removes that inconsistency.
for ax, title, use_congestion in zip(axes, titles, [False, True]):
    rng = np.random.RandomState(11)
    Gc = G.copy()
    init_pheromone(Gc, tau0=1.0)
    gamma = 0.6 if use_congestion else 0.0
    last_paths = None
    for rnd in range(n_rounds):
        starts_goals = []
        for _ in range(n_robots):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            starts_goals.append((nodes[s], nodes[t]))
        paths = run_ssf_episode(Gc, starts_goals, alpha=1.0, beta=2.0, gamma=gamma, kappa=4.0)
        deposit_and_evaporate(Gc, paths, rho=0.12, Q=8.0)
        last_paths = paths

    ax.imshow(grid, cmap='Greys', origin='upper', alpha=0.8)
    cmap = plt.get_cmap('tab10')
    for i, (path, length) in enumerate(last_paths):
        ys_p = [p[0] for p in path]
        xs_p = [p[1] for p in path]
        offset = (i - n_robots / 2) * 0.7
        xs_off, ys_off = offset_path(xs_p, ys_p, offset)
        ax.plot(xs_off, ys_off, color=cmap(i % 10), lw=1.5,
                linestyle=LINESTYLES[i % len(LINESTYLES)], alpha=0.95,
                solid_capstyle='round')
        ax.scatter([xs_p[0]], [ys_p[0]], marker='o', s=26, color=cmap(i % 10),
                   zorder=5, edgecolors='black', linewidths=0.4)
        ax.scatter([xs_p[-1]], [ys_p[-1]], marker='*', s=70, color=cmap(i % 10),
                   zorder=5, edgecolors='black', linewidths=0.4)

    max_usage = max((Gc[u][v]['usage'] for u, v in Gc.edges), default=1)
    for u, v in Gc.edges:
        use = Gc[u][v]['usage']
        if use >= 4:
            ax.plot([u[1], v[1]], [u[0], v[0]], color='red',
                     lw=1.2 + 2.0 * use / max(max_usage, 1), alpha=0.30, zorder=3)
    total_len = sum(geometric_path_length(Gc, p) for p, _ in last_paths)
    bottleneck = sum(1 for u, v in Gc.edges if Gc[u][v]['usage'] >= 4)
    print(f"RESULT: {title.strip()}: total_len={total_len:.0f}px congested_edges={bottleneck}")
    ax.set_title(f"{title}\nfinal-round total length={total_len:.0f}px, congested edges={bottleneck}",
                 fontsize=9.3)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)

fig.suptitle(f"Final round of a {n_rounds}-round batch simulation, {n_robots} fresh random "
             "requests per round (same request sequence in both panels): circles = start, "
             "stars = goal, red overlay = edges shared by $\\geq$4 robots in that round. "
             "Both panels use the batch-then-update semantics of Eqs. 1-3, differing only "
             "in $\\gamma$; paths carry a small offset purely for visual separation",
             fontsize=9.0, y=1.06)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig3_multirobot.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig3_multirobot.png', bbox_inches='tight', dpi=300)
print("fig3 done")

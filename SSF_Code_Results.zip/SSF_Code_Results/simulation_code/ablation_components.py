import sys
sys.path.insert(0, '/home/claude/smsn/SSF_Code_Results/simulation_code')
import numpy as np
import networkx as nx
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph
from ssf_core import (init_pheromone, run_ssf_episode, deposit_and_evaporate,
                       geometric_path_length)

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G_raw = skeleton_to_graph(skel, dist)
largest_cc = max(nx.connected_components(G_raw), key=len)
G0 = G_raw.subgraph(largest_cc).copy()
nodes = list(G0.nodes)

N_AGENTS = 18
N_ROUNDS = 40
N_TRIALS = 6
DEFAULTS = dict(alpha=1.0, beta=2.0, gamma=0.6, rho=0.12, kappa=6.0, Q=10.0)


def run_ablation(alpha, beta, gamma, rho, kappa, Q, freeze_pheromone, seed):
    rng = np.random.RandomState(seed)
    G = G0.copy()
    init_pheromone(G, tau0=1.0)
    requests = []
    for _ in range(N_AGENTS):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        requests.append((nodes[s], nodes[t]))
    last_paths = None
    congestion_hist = []
    for it in range(N_ROUNDS):
        paths = run_ssf_episode(G, requests, alpha=alpha, beta=beta, gamma=gamma, kappa=kappa)
        if not freeze_pheromone:
            deposit_and_evaporate(G, paths, rho=rho, Q=Q)
        else:
            # "no adaptive update": usage still tracked for the congestion
            # term to act on, but pheromone tau is never reinforced or
            # evaporated -- it stays at its initial value forever
            for u, v in G.edges:
                G[u][v]['usage'] = 0
            for path, length in paths:
                for i in range(len(path) - 1):
                    u, v = path[i], path[i + 1]
                    G[u][v]['usage'] = G[u][v].get('usage', 0) + 1
        last_paths = paths
        usage_vals = [G[u][v]['usage'] for u, v in G.edges]
        congestion_hist.append(sum(1 for u in usage_vals if u >= 4))
    mean_len = np.mean([geometric_path_length(G, p) for p, _ in last_paths])
    mean_congestion = np.mean(congestion_hist[-10:])
    return mean_len, mean_congestion


configs = {
    "Full SSF (proposed)": dict(DEFAULTS),
    "No congestion term (gamma=0)": {**DEFAULTS, 'gamma': 0.0},
    "No pheromone weighting (alpha=0)": {**DEFAULTS, 'alpha': 0.0},
    "No clearance reward (beta=0)": {**DEFAULTS, 'beta': 0.0},
    "No adaptive update (tau frozen)": dict(DEFAULTS),  # handled via freeze flag below
}
freeze_flags = {
    "Full SSF (proposed)": False,
    "No congestion term (gamma=0)": False,
    "No pheromone weighting (alpha=0)": False,
    "No clearance reward (beta=0)": False,
    "No adaptive update (tau frozen)": True,
}

print(f"{'Configuration':32s} | {'Mean path cost':>15s} | {'Mean congestion':>16s}")
print("-" * 70)
results = {}
for name, cfg in configs.items():
    lens, congs = [], []
    for trial in range(N_TRIALS):
        l, c = run_ablation(freeze_pheromone=freeze_flags[name], seed=500 + trial, **cfg)
        lens.append(l)
        congs.append(c)
    results[name] = (np.mean(lens), np.std(lens), np.mean(congs), np.std(congs))
    print(f"{name:32s} | {np.mean(lens):8.2f} ({np.std(lens):5.2f}) | "
          f"{np.mean(congs):9.2f} ({np.std(congs):5.2f})")

print("\ndone")

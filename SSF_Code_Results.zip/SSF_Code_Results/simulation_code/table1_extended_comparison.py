import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import networkx as nx
import time
from scipy import stats
from env_utils import (make_office_environment, make_cluttered_environment,
                        make_maze_environment, compute_skeleton, skeleton_to_graph, nearest_node)
from ssf_core import (init_pheromone, run_ssf_episode, deposit_and_evaporate,
                       geometric_path_length)
from advanced_baselines import astar_grid, theta_star_grid, prm_star

envs = {
    "Office": make_office_environment(size=140, seed=1),
    "Cluttered": make_cluttered_environment(size=140, seed=2),
    "Maze": make_maze_environment(size=140, seed=3),
}

n_trials = 10
n_agents = 12
n_rounds = 40

methods = ["SSF", "Static", "A*", "Theta*", "PRM*"]
records = {name: {m: [] for m in methods} for name in envs}
time_records = {name: {m: [] for m in methods} for name in envs}

env_seed_offset = {"Office": 11, "Cluttered": 23, "Maze": 37}

for name, grid in envs.items():
    free = ~grid
    skel, dist = compute_skeleton(free)
    G_raw = skeleton_to_graph(skel, dist)
    largest_cc = max(nx.connected_components(G_raw), key=len)
    G = G_raw.subgraph(largest_cc).copy()
    nodes = list(G.nodes)

    for trial in range(n_trials):
        rng = np.random.RandomState(1000 * trial + env_seed_offset[name])
        requests = []
        for _ in range(n_agents):
            s, t = rng.choice(len(nodes), size=2, replace=False)
            requests.append((nodes[s], nodes[t]))

        # SSF
        Gs = G.copy()
        init_pheromone(Gs, tau0=1.0)
        for it in range(n_rounds):
            t0 = time.perf_counter()
            paths = run_ssf_episode(Gs, requests)
            deposit_and_evaporate(Gs, paths, rho=0.12, Q=10.0)
            dt = time.perf_counter() - t0
        records[name]["SSF"].append(np.mean([geometric_path_length(Gs, p) for p, _ in paths]))
        time_records[name]["SSF"].append(dt * 1000 / n_agents)

        # Static skeleton
        t0 = time.perf_counter()
        lens = [nx.shortest_path_length(G, s, t, weight='weight') for s, t in requests]
        dt = time.perf_counter() - t0
        records[name]["Static"].append(np.mean(lens))
        time_records[name]["Static"].append(dt * 1000 / n_agents)

        # A*, Theta*, PRM* on a matched subset (5 requests/trial, expensive)
        for s, t in requests[:5]:
            p, c, dt = astar_grid(grid, s, t)
            if p is not None:
                records[name]["A*"].append(c)
                time_records[name]["A*"].append(dt * 1000)
            p, c, dt = theta_star_grid(grid, s, t)
            if p is not None:
                records[name]["Theta*"].append(c)
                time_records[name]["Theta*"].append(dt * 1000)
            p, c, dt = prm_star(grid, s, t, n_samples=250, k_neighbors=8, seed=trial)
            if p is not None and c < np.inf:
                records[name]["PRM*"].append(c)
                time_records[name]["PRM*"].append(dt * 1000)

# ---------------------------------------------------------------------------
# Statistical significance: paired Wilcoxon signed-rank test, SSF vs each
# baseline, on matched trial-level mean path costs (per environment)
# ---------------------------------------------------------------------------
print("=== Mean path length (px) / mean per-request planning time (ms) ===")
for name in envs:
    for m in methods:
        vals = records[name][m]
        tvals = time_records[name][m]
        if vals:
            print(f"{name:10s} {m:8s} len={np.mean(vals):7.2f} (sd={np.std(vals):5.2f})  "
                  f"time={np.mean(tvals):9.3f}ms  n={len(vals)}")

print("\n=== Paired significance tests: SSF vs Static skeleton (per-trial mean length) ===")
sig_rows = []
for name in envs:
    a = np.array(records[name]["SSF"])
    b = np.array(records[name]["Static"])
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]
    diff = a - b
    try:
        w_stat, w_p = stats.wilcoxon(a, b)
    except ValueError:
        w_stat, w_p = np.nan, np.nan
    t_stat, t_p = stats.ttest_rel(a, b)
    mean_diff = np.mean(diff)
    se = np.std(diff, ddof=1) / np.sqrt(n)
    ci_low, ci_high = mean_diff - 1.96 * se, mean_diff + 1.96 * se
    sig_rows.append((name, mean_diff, ci_low, ci_high, t_stat, t_p, w_stat, w_p))
    print(f"{name:10s} mean_diff={mean_diff:6.2f}px  95% CI=[{ci_low:5.2f},{ci_high:5.2f}]  "
          f"paired t={t_stat:6.2f} (p={t_p:.4f})  Wilcoxon W={w_stat:6.2f} (p={w_p:.4f})")

print("\ndone")

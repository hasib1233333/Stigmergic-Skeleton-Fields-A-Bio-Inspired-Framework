import sys
sys.path.insert(0, '/home/claude/smsn/code')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from env_utils import make_office_environment, compute_skeleton, skeleton_to_graph
from ssf_core import init_pheromone, run_ssf_episode, deposit_and_evaporate, geometric_path_length

plt.rcParams.update({"font.family": "serif", "font.size": 9.5, "figure.dpi": 300})

grid = make_office_environment(size=140, seed=1)
free = ~grid
skel, dist = compute_skeleton(free)
G0 = skeleton_to_graph(skel, dist)
nodes = list(G0.nodes)

N_AGENTS = 18
N_ROUNDS = 40
N_TRIALS = 5
DEFAULTS = dict(alpha=1.0, beta=2.0, gamma=0.6, rho=0.12, kappa=6.0, Q=10.0)


def run_once(alpha, beta, gamma, rho, kappa, Q, seed):
    rng = np.random.RandomState(seed)
    G = G0.copy()
    init_pheromone(G, tau0=1.0)
    requests = []
    for _ in range(N_AGENTS):
        s, t = rng.choice(len(nodes), size=2, replace=False)
        requests.append((nodes[s], nodes[t]))
    last_paths = None
    max_usage_hist = []
    for it in range(N_ROUNDS):
        paths = run_ssf_episode(G, requests, alpha=alpha, beta=beta, gamma=gamma, kappa=kappa)
        deposit_and_evaporate(G, paths, rho=rho, Q=Q)
        last_paths = paths
        usage_vals = [G[u][v]['usage'] for u, v in G.edges]
        max_usage_hist.append(np.mean(sorted(usage_vals, reverse=True)[:5]) if usage_vals else 0)
    mean_len = np.mean([geometric_path_length(G, p) for p, _ in last_paths])
    congestion = np.mean(max_usage_hist[-10:])
    return mean_len, congestion


def sweep(param_name, values):
    lens, cong = [], []
    for v in values:
        kw = dict(DEFAULTS)
        kw[param_name] = v
        trial_lens, trial_cong = [], []
        for trial in range(N_TRIALS):
            l, c = run_once(seed=200 + trial, **kw)
            trial_lens.append(l)
            trial_cong.append(c)
        lens.append((np.mean(trial_lens), np.std(trial_lens)))
        cong.append((np.mean(trial_cong), np.std(trial_cong)))
    return lens, cong


sweeps = {
    r'$\alpha$ (pheromone weight)': ('alpha', [0.5, 1.0, 1.5, 2.0]),
    r'$\beta$ (clearance weight)': ('beta', [0.0, 1.0, 2.0, 4.0]),
    r'$\gamma$ (congestion weight)': ('gamma', [0.0, 0.3, 0.6, 1.0]),
    r'$\rho$ (evaporation rate)': ('rho', [0.05, 0.10, 0.20, 0.30]),
    r'$\kappa$ (congestion threshold)': ('kappa', [2.0, 4.0, 6.0, 10.0]),
}

fig, axes = plt.subplots(2, 5, figsize=(13.5, 5.6))
results_summary = {}
for col, (label, (pname, values)) in enumerate(sweeps.items()):
    lens, cong = sweep(pname, values)
    results_summary[pname] = (values, lens, cong)
    ax = axes[0, col]
    means = [m for m, s in lens]
    stds = [s for m, s in lens]
    ax.errorbar(values, means, yerr=stds, marker='o', color='#1f77b4', capsize=3, lw=1.4)
    ax.set_title(label, fontsize=9)
    ax.set_ylabel('mean path cost' if col == 0 else '')
    ax.grid(alpha=0.25)

    ax2 = axes[1, col]
    means_c = [m for m, s in cong]
    stds_c = [s for m, s in cong]
    ax2.errorbar(values, means_c, yerr=stds_c, marker='s', color='#d62728', capsize=3, lw=1.4)
    ax2.set_xlabel(label, fontsize=8.5)
    ax2.set_ylabel('congestion (top-5 mean usage)' if col == 0 else '')
    ax2.grid(alpha=0.25)

fig.suptitle('Parameter sensitivity: mean path cost (top row) and congestion '
             '(bottom row) after 40 rounds, 18 concurrent requests, office '
             'environment, 5 trials per setting', fontsize=10, y=1.03)
plt.tight_layout()
plt.savefig('/home/claude/smsn/figs/fig8_sensitivity.pdf', bbox_inches='tight')
plt.savefig('/home/claude/smsn/figs/fig8_sensitivity.png', bbox_inches='tight', dpi=300)

print("=== Parameter sensitivity summary ===")
for pname, (values, lens, cong) in results_summary.items():
    print(pname, list(zip(values, [round(m,2) for m,_ in lens], [round(m,2) for m,_ in cong])))
print("fig8 done")

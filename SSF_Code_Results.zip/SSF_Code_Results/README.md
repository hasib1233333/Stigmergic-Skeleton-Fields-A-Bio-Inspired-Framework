# Stigmergic Skeleton Field (SSF) — Simulation Code & Results (Major Revision)

Complete code used to generate every figure and table in the revised
manuscript "Stigmergic Skeleton Fields: A Bio-Inspired Framework for
Decentralized Multi-Robot Navigation via Localized Incremental
Re-Skeletonization," including all material added in response to peer
review, plus a continuous-motion demo and a companion ROS 2 package.

## Core framework
- `env_utils.py` — environment generation (office, cluttered, maze) and
  medial-axis skeleton graph extraction.
- `ssf_core.py` — SSF algorithm: pheromone-modulated shortest paths,
  deposit/evaporate dynamics, congestion-aware cost, localized
  incremental re-skeletonization (LIR), raw-grid ACO and RRT* baselines.
- `advanced_baselines.py` — A*, Theta*, D* Lite (with incremental
  obstacle updates), PRM*, and a skeleton-restricted Conflict-Based
  Search (CBS) implementation for optimal small-N multi-agent comparison.

## Figure/table scripts
- `fig1_environments.py` ... `fig7_statistics.py` — original seven
  figures (fig3/fig4/fig7 updated: path-bundling visualization,
  confidence intervals, significance brackets).
- `fig8_sensitivity.py` — five-parameter sensitivity sweep
  (alpha, beta, gamma, rho, kappa).
- `fig9_robot_scaling.py` — robot-count scaling, 5/20/50/100 agents.
- `fig10_dstarlite_and_frequency.py` — D* Lite vs. LIR vs. full
  re-skeletonization across map sizes, and LIR overhead vs. obstacle
  arrival frequency.
- `fig6_scalability.py` (extended) — map-size sweep now covers
  80–1000 grid cells per side, plus a node/edge-count memory proxy.
- `table1_extended_comparison.py` — A*/Theta*/PRM* comparison
  with paired Wilcoxon/t-test statistical significance.
- `table2_cbs_comparison.py` — skeleton-restricted CBS vs. SSF,
  N = 2..10 agents.
- `diffdrive_sim.py` — continuous differential-drive kinematics,
  sequential-waypoint controller, and a raycast range sensor for local
  reactive avoidance: executes SSF/LIR-planned paths as continuous
  trajectories instead of instantaneous graph traversal.
- `demo_continuous_control.py` — six-robot scenario with a mid-flight
  dynamic obstacle and LIR replan under the continuous controller;
  produces `demo_continuous_trajectories.png/.pdf` and an animated
  `demo_continuous_animation.gif`.

## Requirements
```
pip install numpy scipy networkx scikit-image matplotlib pillow
```
Each script is self-contained: `python3 <script>.py`.

## Notes on the new baselines
- D* Lite and CBS are from-scratch, pure-Python reference
  implementations, chosen for a like-for-like comparison against our
  equally pure-Python SSF/LIR implementation. Absolute timings should
  be read as relative comparisons within this codebase, not as
  representative of optimized production implementations.
- The skeleton-restricted CBS operates on the same skeleton graph as
  SSF (not the raw occupancy grid), isolating the cost of optimal
  multi-agent coordination from the cost of the topological
  representation itself.

## ROS 2 / Gazebo package (`ros2_package/ssf_ros2/`)

A companion ROS 2 (ament_python) package implementing SSF's
shared-blackboard architecture as real ROS nodes: a
`skeleton_service_node` publishing the skeleton graph and pheromone
field, and independent `robot_agent_node` instances that query it and
drive `cmd_vel`, plus a `generate_world.py` script that converts the
exact office environment used throughout the paper into a Gazebo SDF
world (already generated once as `worlds/office.sdf`, 36 wall boxes,
valid XML). See `ros2_package/ssf_ros2/README.md` for build/run
instructions and known gaps.

**Honest status:** this package was authored and passes
`python3 -m py_compile` on every file, and its planning logic
(`ssf_lib.py`) is a direct, tested copy of `ssf_core.py`/`env_utils.py`
above (verified to import and plan correctly outside of ROS). It has
**not** been built with `colcon` or run against a real ROS 2 / Gazebo
installation, because the sandbox used to prepare this submission has
no network access to ROS package repositories (`packages.ros.org`) and
no display server for Gazebo. Treat it as a reviewed starting point,
not a validated deployment — see the "Known gaps" section of its own
README for specific things to check first.

## Reproducibility note

Figures using scikit-image's `medial_axis` can vary by a few percent
between runs due to internal tie-breaking on plateaus of exactly equal
distance-transform value (discussed in the manuscript's Discussion
section). This does not affect the qualitative conclusions; each
experiment computes its skeleton once and reuses it across all trials
of that experiment. `demo_continuous_control.py` includes an explicit
retry/fallback path for this reason (see its LIR-replan section).

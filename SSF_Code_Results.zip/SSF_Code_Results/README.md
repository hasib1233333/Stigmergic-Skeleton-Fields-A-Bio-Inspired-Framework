# Stigmergic Skeleton Field (SSF) — Simulation Code & Results (Major Revision v3)

Complete code used to generate every figure and table in the manuscript
"Stigmergic Skeleton Fields: A Bio-Inspired Framework for Decentralized
Multi-Robot Navigation via Localized Incremental Re-Skeletonization."

## Critical fix in this revision: LIR was not actually splicing

A reviewer checked the supplied code directly and found that
`local_reskeletonize` deleted nodes inside the affected box, recomputed
a skeleton for that crop in isolation, and pasted the new nodes/edges
into the retained graph — **without ever creating an edge connecting
the two pieces**. On the paper's own dynamic-obstacle scenario, this
produced 2 disconnected components (87 + 5 nodes) where there had been
1; it "worked" in demos only because tested start/goal pairs happened
to route around the orphaned piece.

This is fixed in `ssf_core.py`:
- `_find_ports` traces each retained edge's stored pixel path to find
  where it crossed into the affected box.
- `_attempt_local_reskeletonize` snaps each port to the nearest pixel
  of the freshly recomputed local skeleton (splitting the nearest local
  edge to create a real interface node if needed — snapping to sparse
  junction nodes alone left most ports too far away to connect).
- `local_reskeletonize` verifies the connected-component count did not
  increase; if it did, it retries with a larger pad and ultimately
  falls back to full re-skeletonization, restoring historical
  pheromone state on unaffected edges.
- `skeleton_to_graph` (`env_utils.py`) was also fixed: a local crop can
  produce a pure closed loop (uniform degree-2, no junction), which was
  previously silently dropped entirely.

**Validated over 120 trials** (`lir_validation.py`,
`lir_validation_results.json`): connectivity preserved 120/120 (100%),
fallback to full re-skeletonization 46/120 (38%), mean speedup 1.24x
(not the ~9x an earlier, unstitched version had suggested — that
figure was measuring how cheap it is to skip the reconnection work,
not how cheap correct reconnection is).

## Other corrections in this revision

- `fig3_multirobot.py` previously updated pheromone after *each robot*
  within a round (sequential, order-dependent), inconsistent with the
  batch-then-update semantics used everywhere else
  (`run_ssf_episode` + `deposit_and_evaporate` after the full batch).
  Rewritten to use identical semantics; the congestion-avoidance effect
  shown is now smaller and noisier than the original figure implied,
  reported honestly rather than re-drawn to look cleaner.
- Skeleton node/edge counts for the office/cluttered/maze environments
  are reported as ranges from repeated extraction, not single-run
  figures, because `scikit-image`'s `medial_axis` is not fully
  deterministic on these inputs (documented in the manuscript's
  Discussion section).
- `fig_architecture.py` (new): a system-level block diagram (sensing
  input to skeleton extraction to shared pheromone field to per-robot
  planners to execution to LIR-triggered repair loop), added because
  the paper previously had no single figure showing this end-to-end.
- All figures updated with a consistent colorblind-safe palette,
  uniform fonts/line widths, and legends repositioned to never overlap
  data (`plot_style.py`).

## Core framework
- `env_utils.py` — environment generation and medial-axis skeleton
  graph extraction (now handles pure-loop components correctly).
- `ssf_core.py` — SSF algorithm, now with verified LIR splicing
  (`_find_ports`, `_attempt_local_reskeletonize`, `local_reskeletonize`).
- `advanced_baselines.py` — A*, Theta*, D* Lite (incremental + coarsened
  control), PRM*, skeleton-restricted CBS.

## Key scripts
- `lir_validation.py` — the 120-trial validation referenced above.
- `fig1_environments.py` ... `fig11_dstarlite_control_and_multiobstacle.py`,
  `fig_architecture.py`, `fig_benchmark_envs.py`,
  `demo_continuous_control.py` — one script per figure, each
  self-contained: `python3 <script>.py`.
- `ablation_components.py`, `congestion_threshold_check.py`,
  `benchmark_style_envs.py` — supporting analyses cited in text/tables.

## Requirements
```
pip install numpy scipy networkx scikit-image matplotlib pillow
```

## ROS 2 / Gazebo package (`ros2_package/ssf_ros2/`)
Authored and passes `python3 -m py_compile` on every file; **not**
built or run against a real ROS 2/Gazebo installation (no network
access to ROS package repos, no display server, in the sandbox used to
prepare this submission). Treat as a reviewed starting point.

## Reproducibility note
Given the documented `medial_axis` non-determinism, exact figures will
vary by a few percent (occasionally more) if regenerated. Each
experiment computes its skeleton once and reuses it across all trials
of that experiment, so this does not affect any single reported
comparison — but comparing two separately-generated artifacts (e.g., a
figure regenerated today against a number quoted in an older draft)
can show real differences. This is why several passages in the
manuscript now report ranges from repeated runs rather than
single-run figures.

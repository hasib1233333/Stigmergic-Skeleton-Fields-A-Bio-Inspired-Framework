# ssf_ros2

ROS 2 reference implementation of the **Stigmergic Skeleton Field (SSF)**
shared-blackboard architecture described in the Discussion section of
*"Stigmergic Skeleton Fields: A Bio-Inspired Framework for Decentralized
Multi-Robot Navigation via Localized Incremental Re-Skeletonization."*

## What this honestly is, and isn't

**This package was authored and syntax-checked, but not built or run
against a real ROS 2 + Gazebo installation.** The sandbox this was
written in has no network access to ROS package repositories
(`packages.ros.org`) and no display server, so `colcon build`,
`ros2 launch`, and Gazebo itself could not be executed here. Every
Python file passes `python3 -m py_compile`, and the pure-Python SSF/LIR
logic inside `ssf_lib.py` is the exact code validated in the paper's
simulation experiments (copied from `env_utils.py` / `ssf_core.py`,
confirmed to import and run correctly). The ROS-specific glue
(`rclpy` node structure, topic wiring, the launch file) follows
standard, common ROS 2 patterns, but **you should expect to do some
debugging** the first time you build and run it, the way you would
with any first-time ROS package from a new source.

If you don't have ROS 2 / Gazebo available either, the companion
`simulation_code/demo_continuous_control.py` (in the main code archive)
gives you a dependency-free stand-in: real differential-drive
kinematics, a pure-pursuit-style controller, local obstacle sensing,
and a mid-flight LIR replan, all in plain Python/matplotlib, runnable
anywhere.

## Prerequisites

- ROS 2 (developed against Humble or Jazzy conventions; should also
  work on Iron with minor adjustments)
- Gazebo (either `gz sim` / Harmonic with `ros_gz_sim`, or classic
  Gazebo with `gazebo_ros`) if you want the physical simulation step;
  the ROS nodes themselves don't require Gazebo specifically and will
  work with any robot base that publishes `nav_msgs/Odometry` and
  subscribes to `geometry_msgs/Twist` on `cmd_vel`
- Python packages: `numpy`, `networkx`, `scipy`, `scikit-image`
  (`pip install numpy networkx scipy scikit-image` inside your ROS 2
  Python environment)

## Build

```bash
mkdir -p ~/ssf_ws/src
cp -r ssf_ros2 ~/ssf_ws/src/
cd ~/ssf_ws
colcon build --packages-select ssf_ros2
source install/setup.bash
```

## Generate the world (matches the paper's office environment exactly)

```bash
ros2 run ssf_ros2 generate_world --size 140 --seed 1 --cell-size 1.0 \
    --out worlds/office.sdf
```

This calls the same `make_office_environment(size=140, seed=1)` used
throughout the paper, so the Gazebo world's wall layout is pixel-for-
pixel (cell-for-cell) identical to the skeleton graph the
`skeleton_service_node` plans over.

## Bring up your robots

Spawn your robots into `worlds/office.sdf` (or your own world) using
your normal robot bring-up launch file. This package doesn't spawn
robots itself, since spawn procedure differs a lot between TurtleBot3,
Nav2-based stacks, and custom bases. Make sure each robot:
- publishes `nav_msgs/Odometry` on `<namespace>/odom`
- subscribes to `geometry_msgs/Twist` on `<namespace>/cmd_vel`

## Run SSF planning + coordination

```bash
ros2 run ssf_ros2 skeleton_service_node --ros-args -p map_size:=140 -p map_seed:=1
```

then, in another terminal:

```bash
ros2 launch ssf_ros2 ssf_multi_robot.launch.py \
    robot_ids:="['robot_0','robot_1','robot_2']" \
    starts:="[[8,8],[8,60],[60,8]]" \
    goals:="[[120,120],[120,60],[60,120]]"
```

Each `robot_agent_node` requests a path from the shared
`skeleton_service_node` over plain JSON-encoded `std_msgs/String`
topics (see the docstring in `skeleton_service_node.py` for the exact
schema), reports its committed route back so the pheromone field
updates, and drives `cmd_vel` with the same sequential-waypoint
controller validated in the paper's continuous-motion demo. No robot
ever talks to another robot directly -- coordination happens only
through the shared pheromone field on the service node, exactly as in
the paper.

## Injecting a dynamic obstacle (to trigger LIR)

```bash
ros2 topic pub --once /ssf/dynamic_obstacle std_msgs/String \
    "{data: '{\"cx\": 70, \"cy\": 70, \"r\": 7}'}"
```

Watch the `skeleton_service_node` terminal for the `LIR update applied
in N.N ms` log line, then request a new plan (or wait for your
robot_agent_node's own re-request logic, which this reference version
does not implement automatically -- see "Known gaps" below).

## Known gaps / what we'd do next

- `robot_agent_node` currently requests a path once, at startup. It
  does not automatically re-request when the shared skeleton changes
  (e.g. after a `/ssf/dynamic_obstacle` event) or when it drifts far
  from its planned path. A production version should subscribe to a
  "graph changed" notification from the service node and re-plan from
  its current pose.
- The request/response wire format uses JSON-over-`std_msgs/String`
  rather than proper `.srv` interfaces, to keep this example buildable
  as a single `ament_python` package. For real use, define
  `ssf_interfaces/srv/PlanPath.srv` and `ssf_interfaces/msg/*.msg` in a
  small `ament_cmake` interfaces package and swap the JSON calls for
  real service calls -- the message schema here is written so that
  swap is mechanical.
- No collision avoidance between robots is implemented at the
  continuous-motion level (SSF's congestion-aware cost reduces the
  *chance* of two robots being routed onto the same corridor
  simultaneously, but does not itself guarantee collision-free
  continuous trajectories). Pair this with a local collision-avoidance
  layer (e.g. a costmap-based local planner, or reciprocal velocity
  obstacles) for real deployment.
- `map_size`/`map_seed` on the service node and the world generator's
  `--size`/`--seed` must be kept in sync manually; a production version
  should generate both from one source of truth at launch time.

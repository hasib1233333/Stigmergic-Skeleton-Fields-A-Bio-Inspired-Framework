"""
generate_world.py

Converts the exact same office environment used throughout the paper
(env_utils.make_office_environment) into a Gazebo SDF world file, so
the physical layout a robot navigates in Gazebo matches the layout SSF
planned over -- this is the piece that makes the ROS/Gazebo step a
genuine extension of the paper's simulation rather than an unrelated
demo scene.

Usage:
    ros2 run ssf_ros2 generate_world --size 140 --seed 1 --cell-size 1.0 \
        --out worlds/office.sdf

Walls are emitted as merged rectangular boxes (simple run-length merge
along rows) rather than one box per grid cell, to keep the resulting
SDF a reasonable size.
"""
import argparse

import numpy as np

from ssf_ros2.ssf_lib import make_office_environment


SDF_HEADER = """<?xml version="1.0"?>
<sdf version="1.8">
  <world name="ssf_office">
    <physics name="1ms" type="ignored">
      <max_step_size>0.001</max_step_size>
      <real_time_factor>1.0</real_time_factor>
    </physics>
    <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"></plugin>
    <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"></plugin>
    <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"></plugin>
    <light type="directional" name="sun">
      <cast_shadows>true</cast_shadows>
      <pose>0 0 10 0 0 0</pose>
      <diffuse>0.8 0.8 0.8 1</diffuse>
      <direction>-0.5 0.1 -0.9</direction>
    </light>
    <model name="ground_plane">
      <static>true</static>
      <link name="link">
        <collision name="collision">
          <geometry><plane><normal>0 0 1</normal><size>1000 1000</size></plane></geometry>
        </collision>
        <visual name="visual">
          <geometry><plane><normal>0 0 1</normal><size>1000 1000</size></plane></geometry>
        </visual>
      </link>
    </model>
"""

SDF_FOOTER = """  </world>
</sdf>
"""

WALL_BOX_TEMPLATE = """    <model name="wall_{idx}">
      <static>true</static>
      <pose>{cx} {cy} {hz} 0 0 0</pose>
      <link name="link">
        <collision name="collision">
          <geometry><box><size>{sx} {sy} {sz}</size></box></geometry>
        </collision>
        <visual name="visual">
          <geometry><box><size>{sx} {sy} {sz}</size></box></geometry>
          <material><ambient>0.6 0.6 0.6 1</ambient><diffuse>0.6 0.6 0.6 1</diffuse></material>
        </visual>
      </link>
    </model>
"""


def merge_wall_boxes(grid):
    """Greedy run-length merge of obstacle cells into horizontal strips,
    then merge adjacent same-width strips vertically. Not optimal, but
    keeps the SDF file size reasonable for a 140x140 (or larger) grid."""
    H, W = grid.shape
    visited = np.zeros_like(grid, dtype=bool)
    boxes = []  # (row0, col0, row1, col1) inclusive
    for y in range(H):
        x = 0
        while x < W:
            if grid[y, x] and not visited[y, x]:
                x_end = x
                while x_end + 1 < W and grid[y, x_end + 1] and not visited[y, x_end + 1]:
                    x_end += 1
                # try to extend this strip downward as long as an
                # identical strip of obstacle cells exists
                y_end = y
                while y_end + 1 < H and np.all(grid[y_end + 1, x:x_end + 1]):
                    y_end += 1
                visited[y:y_end + 1, x:x_end + 1] = True
                boxes.append((y, x, y_end, x_end))
                x = x_end + 1
            else:
                x += 1
    return boxes


def build_sdf(grid, cell_size, wall_height=1.0):
    boxes = merge_wall_boxes(grid)
    parts = [SDF_HEADER]
    for idx, (y0, x0, y1, x1) in enumerate(boxes):
        sx = (x1 - x0 + 1) * cell_size
        sy = (y1 - y0 + 1) * cell_size
        cx = (x0 + x1 + 1) / 2 * cell_size
        cy = (y0 + y1 + 1) / 2 * cell_size
        parts.append(WALL_BOX_TEMPLATE.format(
            idx=idx, cx=cx, cy=cy, hz=wall_height / 2,
            sx=sx, sy=sy, sz=wall_height))
    parts.append(SDF_FOOTER)
    return ''.join(parts)


def main(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--size', type=int, default=140)
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--cell-size', type=float, default=1.0,
                         help='metres per grid cell in the emitted world')
    parser.add_argument('--out', type=str, default='worlds/office.sdf')
    ns = parser.parse_args(args)

    grid = make_office_environment(size=ns.size, seed=ns.seed)
    sdf = build_sdf(grid, ns.cell_size)
    with open(ns.out, 'w') as f:
        f.write(sdf)
    print(f'Wrote {ns.out} ({len(merge_wall_boxes(grid))} wall boxes, '
          f'{ns.size}x{ns.size} cells at {ns.cell_size} m/cell).')


if __name__ == '__main__':
    main()

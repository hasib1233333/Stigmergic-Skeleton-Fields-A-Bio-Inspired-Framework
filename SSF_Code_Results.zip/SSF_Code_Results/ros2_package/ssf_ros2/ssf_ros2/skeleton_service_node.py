"""
skeleton_service_node.py

Publishes the SSF shared blackboard: the medial-axis skeleton graph of
a known map, and the live pheromone/usage field on that graph, exactly
as described in the "Simulation-only scope" discussion of the SSF
paper. Robot-agent nodes (robot_agent_node.py) query this node for a
path and report back which edges they used, so the pheromone field is
updated centrally but every planning decision is still made
independently by each robot node -- the ROS-level analogue of the
single-process simulation in the paper.

This node deliberately avoids requiring a custom ROS interface
(.srv/.msg) package to keep the example buildable with just
ament_python: requests and responses are JSON-encoded std_msgs/String
messages on plain topics. For a production system, replace these with
proper .srv definitions (e.g. ssf_interfaces/srv/PlanPath.srv) once you
have an ament_cmake interface package set up; the JSON schema below is
written so that swap is mechanical.

Wire format
-----------
Request   (topic: /ssf/plan_request,  std_msgs/String, JSON):
    {"robot_id": "robot_0", "start_xy": [x, y], "goal_xy": [x, y]}

Response  (topic: /ssf/plan_response, std_msgs/String, JSON):
    {"robot_id": "robot_0", "path_xy": [[x0,y0], [x1,y1], ...], "length": 123.4}

Usage report (topic: /ssf/path_used, std_msgs/String, JSON), published by
each robot agent once it starts executing a returned path, is what
drives the pheromone deposit/evaporate update on this node:
    {"robot_id": "robot_0", "path_xy": [[x0,y0], ...], "length": 123.4}

Dynamic obstacles are injected via:
    {"cx": x, "cy": y, "r": radius}
on topic /ssf/dynamic_obstacle, which triggers a Localized Incremental
Re-skeletonization (LIR) update on this node before the next planning
request is served.
"""
import json
import time

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

# Reuses the exact same SSF/LIR implementation validated in the paper's
# simulation experiments (env_utils.py, ssf_core.py), so the planning
# logic running inside ROS is identical to the logic the paper reports
# on, not a re-implementation.
from ssf_ros2.ssf_lib import (
    make_office_environment, compute_skeleton, skeleton_to_graph,
    nearest_node, init_pheromone, modulated_shortest_path,
    deposit_and_evaporate, apply_dynamic_obstacle, local_reskeletonize,
)


class SkeletonServiceNode(Node):
    def __init__(self):
        super().__init__('ssf_skeleton_service')

        self.declare_parameter('map_size', 140)
        self.declare_parameter('map_seed', 1)
        size = self.get_parameter('map_size').value
        seed = self.get_parameter('map_seed').value

        self.get_logger().info(f'Building office environment (size={size}, seed={seed})...')
        self.grid = make_office_environment(size=size, seed=seed)
        self.free = ~self.grid
        skel, dist = compute_skeleton(self.free)
        self.G = skeleton_to_graph(skel, dist)
        init_pheromone(self.G, tau0=1.0)
        self.get_logger().info(
            f'Skeleton ready: {self.G.number_of_nodes()} nodes, '
            f'{self.G.number_of_edges()} edges.')

        self.plan_req_sub = self.create_subscription(
            String, '/ssf/plan_request', self.on_plan_request, 10)
        self.plan_resp_pub = self.create_publisher(String, '/ssf/plan_response', 10)

        self.usage_sub = self.create_subscription(
            String, '/ssf/path_used', self.on_path_used, 10)

        self.obstacle_sub = self.create_subscription(
            String, '/ssf/dynamic_obstacle', self.on_dynamic_obstacle, 10)

        # periodic evaporation, matching the SSF planning-round cadence
        # in the paper's simulation
        self.evap_timer = self.create_timer(1.0, self.on_evaporate_tick)
        self._pending_paths = []

    def on_plan_request(self, msg: String):
        try:
            req = json.loads(msg.data)
            sx, sy = req['start_xy']
            gx, gy = req['goal_xy']
            s = nearest_node(self.G, sy, sx)
            g = nearest_node(self.G, gy, gx)
            path, length = modulated_shortest_path(self.G, s, g)
            resp = {
                'robot_id': req.get('robot_id', 'unknown'),
                'path_xy': [[x, y] for (y, x) in path],
                'length': length,
            }
        except Exception as exc:  # noqa: BLE001 -- report back, don't crash the node
            resp = {'robot_id': req.get('robot_id', 'unknown'), 'error': str(exc)}
            self.get_logger().warn(f'Plan request failed: {exc}')
        self.plan_resp_pub.publish(String(data=json.dumps(resp)))

    def on_path_used(self, msg: String):
        report = json.loads(msg.data)
        path_yx = [(y, x) for (x, y) in report['path_xy']]
        self._pending_paths.append((path_yx, report['length']))

    def on_evaporate_tick(self):
        if self._pending_paths:
            deposit_and_evaporate(self.G, self._pending_paths, rho=0.12, Q=10.0)
            self._pending_paths = []
        else:
            deposit_and_evaporate(self.G, [], rho=0.12, Q=10.0)

    def on_dynamic_obstacle(self, msg: String):
        evt = json.loads(msg.data)
        t0 = time.perf_counter()
        free_after, blocked = apply_dynamic_obstacle(
            self.free, int(evt['cy']), int(evt['cx']), int(evt['r']))
        if not blocked.any():
            return
        self.G, _ = local_reskeletonize(self.G, free_after, blocked, pad=18)
        self.free = free_after
        dt_ms = (time.perf_counter() - t0) * 1000
        self.get_logger().info(
            f'LIR update applied in {dt_ms:.1f} ms '
            f'(obstacle at ({evt["cx"]},{evt["cy"]}), r={evt["r"]})')


def main(args=None):
    rclpy.init(args=args)
    node = SkeletonServiceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

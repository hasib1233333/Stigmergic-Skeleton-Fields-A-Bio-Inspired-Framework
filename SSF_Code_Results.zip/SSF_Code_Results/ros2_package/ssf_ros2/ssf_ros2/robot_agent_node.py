"""
robot_agent_node.py

One instance of this node per robot. Each instance is fully independent
-- it only ever talks to the shared skeleton_service_node, never to
other robot agents directly -- which is the ROS-level realization of
SSF's no-inter-robot-communication design. Launch N of these (see
launch/ssf_multi_robot.launch.py) with distinct robot_id / namespace
parameters to reproduce the multi-robot scenarios in the paper.

Control loop: on start, request a path from the shared service, then
drive it with the same sequential-waypoint controller validated in the
paper's continuous-motion demo (diffdrive_sim.py), publishing
geometry_msgs/Twist on <namespace>/cmd_vel and reading
nav_msgs/Odometry on <namespace>/odom. If you are running this against
Gazebo with a differential-drive plugin (e.g. gz_ros2_control or the
classic diff_drive_controller), this node needs no changes -- point
`namespace` at the spawned robot's namespace.
"""
import json

import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

from ssf_ros2.ssf_lib import SequentialWaypointController


class RobotAgentNode(Node):
    def __init__(self):
        super().__init__('ssf_robot_agent')

        self.declare_parameter('robot_id', 'robot_0')
        self.declare_parameter('start_xy', [8.0, 8.0])
        self.declare_parameter('goal_xy', [120.0, 120.0])
        self.declare_parameter('v_nominal', 0.35)   # m/s, tune to your robot
        self.declare_parameter('control_hz', 10.0)

        self.robot_id = self.get_parameter('robot_id').value
        self.start_xy = list(self.get_parameter('start_xy').value)
        self.goal_xy = list(self.get_parameter('goal_xy').value)
        self.v_nominal = self.get_parameter('v_nominal').value

        self.cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.odom_sub = self.create_subscription(Odometry, 'odom', self.on_odom, 10)

        self.plan_req_pub = self.create_publisher(String, '/ssf/plan_request', 10)
        self.plan_resp_sub = self.create_subscription(
            String, '/ssf/plan_response', self.on_plan_response, 10)
        self.usage_pub = self.create_publisher(String, '/ssf/path_used', 10)
        self.obstacle_pub = self.create_publisher(String, '/ssf/dynamic_obstacle', 10)

        self.controller = None
        self.pose = None  # (x, y, theta) from odometry

        self._request_plan()
        hz = self.get_parameter('control_hz').value
        self.timer = self.create_timer(1.0 / hz, self.control_step)

    def _request_plan(self):
        req = {'robot_id': self.robot_id, 'start_xy': self.start_xy, 'goal_xy': self.goal_xy}
        self.plan_req_pub.publish(String(data=json.dumps(req)))
        self.get_logger().info(f'[{self.robot_id}] plan requested: {self.start_xy} -> {self.goal_xy}')

    def on_plan_response(self, msg: String):
        resp = json.loads(msg.data)
        if resp.get('robot_id') != self.robot_id:
            return
        if 'error' in resp:
            self.get_logger().error(f'[{self.robot_id}] planning failed: {resp["error"]}')
            return
        path_xy = resp['path_xy']
        self.controller = SequentialWaypointController(path_xy, v_nominal=self.v_nominal)
        self.get_logger().info(f'[{self.robot_id}] path received, length={resp["length"]:.1f}')
        # report usage immediately so the shared pheromone field reflects
        # this robot's committed route; a more elaborate version could
        # report incrementally as the robot progresses
        self.usage_pub.publish(String(data=json.dumps(
            {'robot_id': self.robot_id, 'path_xy': path_xy, 'length': resp['length']})))

    def on_odom(self, msg: Odometry):
        q = msg.pose.pose.orientation
        theta = np.arctan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
        self.pose = (msg.pose.pose.position.x, msg.pose.pose.position.y, theta)

    def control_step(self):
        if self.controller is None or self.pose is None:
            return
        x, y, theta = self.pose
        v, omega = self.controller.control(x, y, theta)
        twist = Twist()
        twist.linear.x = float(v)
        twist.angular.z = float(omega)
        self.cmd_pub.publish(twist)
        if self.controller.at_goal(x, y):
            self.get_logger().info(f'[{self.robot_id}] goal reached; stopping.')
            self.cmd_pub.publish(Twist())  # zero velocity
            self.timer.cancel()


def main(args=None):
    rclpy.init(args=args)
    node = RobotAgentNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

"""
ssf_lib.py

Self-contained copy of the validated SSF/LIR implementation from the
papers simulation code (env_utils.py + ssf_core.py), bundled directly
into this ROS 2 package so it installs cleanly via colcon without an
external path dependency. Kept byte-for-byte in sync with the
manuscripts supplementary code at time of writing; if you update the
paper-side simulation code, copy the changes here too.
"""
import time
import heapq
import numpy as np
import networkx as nx
from skimage.morphology import medial_axis
from scipy.spatial import cKDTree

from scipy.ndimage import label, binary_dilation
from scipy.spatial import cKDTree


def make_office_environment(size=140, seed=1):
    """Corridor + room style environment (office-like)."""
    rng = np.random.RandomState(seed)
    grid = np.zeros((size, size), dtype=bool)  # False = free
    # outer walls
    grid[0, :] = True
    grid[-1, :] = True
    grid[:, 0] = True
    grid[:, -1] = True
    # main corridors
    grid[size // 2 - 2:size // 2 + 2, :] = False
    grid[:, size // 3 - 2:size // 3 + 2] = False
    # rooms partitions
    n_rooms = 6
    for i in range(n_rooms):
        x0 = rng.randint(5, size - 25)
        y0 = rng.randint(5, size - 25)
        w = rng.randint(14, 22)
        h = rng.randint(14, 22)
        wall = np.zeros((size, size), dtype=bool)
        wall[y0:y0 + h, x0:x0 + w] = True
        wall[y0 + 2:y0 + h - 2, x0 + 2:x0 + w - 2] = False
        # door gap
        gx = rng.randint(x0 + 2, x0 + w - 2)
        wall[y0:y0 + 2, gx:gx + 3] = False
        grid = grid | wall
    return grid


def make_cluttered_environment(size=140, seed=2, n_obstacles=45):
    rng = np.random.RandomState(seed)
    grid = np.zeros((size, size), dtype=bool)
    grid[0, :] = True
    grid[-1, :] = True
    grid[:, 0] = True
    grid[:, -1] = True
    for _ in range(n_obstacles):
        cx, cy = rng.randint(10, size - 10, size=2)
        r = rng.randint(3, 7)
        yy, xx = np.ogrid[:size, :size]
        mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
        grid = grid | mask
    return grid


def make_maze_environment(size=140, seed=3, cell=14):
    """Randomized maze via recursive backtracker on a coarse grid, then upsampled."""
    rng = np.random.RandomState(seed)
    n = size // cell
    visited = np.zeros((n, n), dtype=bool)
    hwalls = np.ones((n + 1, n), dtype=bool)   # horizontal walls
    vwalls = np.ones((n, n + 1), dtype=bool)   # vertical walls

    stack = [(0, 0)]
    visited[0, 0] = True
    while stack:
        cy, cx = stack[-1]
        neighbors = []
        for dy, dx, wh, idx in [(-1, 0, 'h', (cy, cx)), (1, 0, 'h', (cy + 1, cx)),
                                 (0, -1, 'v', (cy, cx)), (0, 1, 'v', (cy, cx + 1))]:
            ny, nx_ = cy + dy, cx + dx
            if 0 <= ny < n and 0 <= nx_ < n and not visited[ny, nx_]:
                neighbors.append((ny, nx_, wh, idx))
        if not neighbors:
            stack.pop()
            continue
        ny, nx_, wh, idx = neighbors[rng.randint(len(neighbors))]
        if wh == 'h':
            hwalls[idx] = False
        else:
            vwalls[idx] = False
        visited[ny, nx_] = True
        stack.append((ny, nx_))

    grid = np.ones((size, size), dtype=bool)
    for j in range(n):
        for i in range(n):
            y0, x0 = j * cell, i * cell
            grid[y0 + 1:y0 + cell - 1, x0 + 1:x0 + cell - 1] = False
    for j in range(n + 1):
        for i in range(n):
            if not hwalls[j, i]:
                y0, x0 = j * cell, i * cell
                grid[max(0, y0 - 1):y0 + 2, x0 + 1:x0 + cell - 1] = False
    for j in range(n):
        for i in range(n + 1):
            if not vwalls[j, i]:
                y0, x0 = j * cell, i * cell
                grid[y0 + 1:y0 + cell - 1, max(0, x0 - 1):x0 + 2] = False
    grid[0, :] = True
    grid[-1, :] = True
    grid[:, 0] = True
    grid[:, -1] = True
    return grid


def compute_skeleton(free_mask):
    """Medial-axis skeleton with distance transform (grassfire-style propagation)."""
    skel, dist = medial_axis(free_mask, return_distance=True)
    return skel, dist


def skeleton_to_graph(skel, dist, prune_len=3):
    """Convert a binary skeleton image into a topology graph (nodes = junctions/
    endpoints, edges = skeleton branches with Euclidean length + min clearance)."""
    ys, xs = np.nonzero(skel)
    pts = set(zip(ys.tolist(), xs.tolist()))

    def neighbors(p):
        y, x = p
        out = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                q = (y + dy, x + dx)
                if q in pts:
                    out.append(q)
        return out

    deg = {p: len(neighbors(p)) for p in pts}
    junctions = {p for p, d in deg.items() if d != 2}

    G = nx.Graph()
    for p in junctions:
        G.add_node(p, pos=(p[1], p[0]), clearance=float(dist[p]))

    visited_dir = set()
    for j in junctions:
        for n0 in neighbors(j):
            if (j, n0) in visited_dir:
                continue
            path = [j, n0]
            visited_dir.add((j, n0))
            prev, cur = j, n0
            while cur not in junctions:
                nxts = [q for q in neighbors(cur) if q != prev]
                if not nxts:
                    break
                nxt = nxts[0]
                visited_dir.add((cur, nxt))
                path.append(nxt)
                prev, cur = cur, nxt
            if cur in junctions and len(path) >= 2:
                length = sum(np.hypot(path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
                             for i in range(len(path) - 1))
                if length < prune_len and deg.get(path[-1], 0) == 1:
                    continue
                min_clear = min(dist[p] for p in path)
                if G.has_edge(j, cur):
                    if G[j][cur]['weight'] <= length:
                        continue
                G.add_edge(j, cur, weight=length, clearance=min_clear,
                           path=path)
    return G


def nearest_node(G, y, x):
    nodes = list(G.nodes)
    tree = cKDTree(np.array(nodes))
    _, idx = tree.query([y, x])
    return nodes[idx]

# ---------------------------------------------------------------------------
# ssf_core.py contents (pheromone dynamics, LIR, congestion-aware cost)
# ---------------------------------------------------------------------------
import networkx as nx
import time



def init_pheromone(G, tau0=1.0):
    for u, v in G.edges:
        G[u][v]['tau'] = tau0
        G[u][v]['usage'] = 0


def edge_cost(G, u, v, alpha=1.0, beta=2.0, gamma=0.6, kappa=6.0):
    """Effective traversal cost of edge (u,v):
    base geometric length, discounted by pheromone^alpha, penalized by
    congestion (usage) and inversely by clearance^beta (favors wide corridors)."""
    e = G[u][v]
    length = e['weight']
    tau = max(e['tau'], 1e-3)
    clearance = max(e.get('clearance', 1.0), 0.5)
    usage = e.get('usage', 0)
    congestion_penalty = 1.0 + gamma * (usage / kappa) ** 2
    return (length * congestion_penalty) / (tau ** alpha * clearance ** (beta / 10.0))


def modulated_shortest_path(G, s, t, **kw):
    def w(u, v, d):
        return edge_cost(G, u, v, **kw)
    return nx.shortest_path(G, s, t, weight=w), nx.shortest_path_length(G, s, t, weight=w)


def deposit_and_evaporate(G, paths, rho=0.15, Q=8.0, usage_decay=0.5):
    for u, v in G.edges:
        G[u][v]['tau'] *= (1.0 - rho)
        G[u][v]['tau'] = max(G[u][v]['tau'], 0.05)
        # usage is an exponentially-smoothed instantaneous congestion signal,
        # not an unbounded accumulator, so it tracks current traffic only.
        G[u][v]['usage'] *= usage_decay
    for path, length in paths:
        deposit = Q / max(length, 1e-3)
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            G[u][v]['tau'] += deposit
            G[u][v]['usage'] = G[u][v].get('usage', 0) + 1


def run_ssf_episode(G, requests, alpha=1.0, beta=2.0, gamma=0.6, kappa=6.0):
    """requests: list of (start_node, goal_node). Returns realized paths & lengths."""
    results = []
    for s, t in requests:
        try:
            path, length = modulated_shortest_path(G, s, t, alpha=alpha, beta=beta,
                                                     gamma=gamma, kappa=kappa)
            results.append((path, length))
        except nx.NetworkXNoPath:
            continue
    return results


def geometric_path_length(G, path):
    return sum(G[path[i]][path[i + 1]]['weight'] for i in range(len(path) - 1))


# ---------------------------------------------------------------------------
# Localized Incremental Re-skeletonization (LIR)
# ---------------------------------------------------------------------------
def apply_dynamic_obstacle(free_mask, cy, cx, r):
    yy, xx = np.ogrid[:free_mask.shape[0], :free_mask.shape[1]]
    blocked = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
    new_mask = free_mask & (~blocked)
    return new_mask, blocked


def full_reskeletonize(free_mask):
    t0 = time.perf_counter()
    skel, dist = compute_skeleton(free_mask)
    G = skeleton_to_graph(skel, dist)
    t1 = time.perf_counter()
    return G, (t1 - t0)


def local_reskeletonize(G_old, free_mask, blocked_region, pad=18):
    """Recompute the skeleton only within a bounding box around the change,
    then splice the local graph back into the global graph, preserving
    pheromone state on unaffected edges."""
    t0 = time.perf_counter()
    ys, xs = np.nonzero(blocked_region)
    y0, y1 = max(ys.min() - pad, 0), min(ys.max() + pad, free_mask.shape[0])
    x0, x1 = max(xs.min() - pad, 0), min(xs.max() + pad, free_mask.shape[1])

    sub = free_mask[y0:y1, x0:x1]
    skel_sub, dist_sub = compute_skeleton(sub)
    G_sub = skeleton_to_graph(skel_sub, dist_sub)

    # shift local node coordinates back to global frame
    mapping = {n: (n[0] + y0, n[1] + x0) for n in G_sub.nodes}
    G_sub = nx.relabel_nodes(G_sub, mapping)

    G_new = G_old.copy()
    # drop nodes/edges that fall inside the affected bounding box
    to_remove = [n for n in G_new.nodes if y0 <= n[0] < y1 and x0 <= n[1] < x1]
    G_new.remove_nodes_from(to_remove)
    # add freshly computed local subgraph
    for n, d in G_sub.nodes(data=True):
        G_new.add_node(n, **d)
    for u, v, d in G_sub.edges(data=True):
        G_new.add_edge(u, v, **d)
        if 'tau' not in G_new[u][v]:
            G_new[u][v]['tau'] = 1.0
            G_new[u][v]['usage'] = 0
    t1 = time.perf_counter()
    return G_new, (t1 - t0)


# ---------------------------------------------------------------------------
# Baselines
# ---------------------------------------------------------------------------
def grid_graph_from_mask(free_mask, step=1):
    """Full occupancy-grid graph (used by the raw-grid ACO baseline)."""
    H, W = free_mask.shape
    G = nx.Graph()
    ys, xs = np.nonzero(free_mask)
    free_pts = set(zip(ys.tolist(), xs.tolist()))
    for y in range(0, H, step):
        for x in range(0, W, step):
            if (y, x) not in free_pts:
                continue
            for dy, dx in [(0, step), (step, 0), (step, step), (step, -step)]:
                ny, nx_ = y + dy, x + dx
                if 0 <= ny < H and 0 <= nx_ < W and (ny, nx_) in free_pts:
                    w = np.hypot(dy, dx)
                    G.add_edge((y, x), (ny, nx_), weight=w, tau=1.0, usage=0, clearance=1.0)
    return G


def rrt_star(free_mask, start, goal, n_iter=1500, step=6.0, seed=0):
    """Minimal RRT* implementation (single-robot, no stigmergy) used as a
    non-coordinated baseline planner."""
    rng = np.random.RandomState(seed)
    H, W = free_mask.shape

    def collision_free(p, q):
        n = int(np.hypot(q[0] - p[0], q[1] - p[1]) / 1.5) + 1
        for i in range(n + 1):
            y = int(p[0] + (q[0] - p[0]) * i / n)
            x = int(p[1] + (q[1] - p[1]) * i / n)
            if not (0 <= y < H and 0 <= x < W) or free_mask[y, x]:
                return False
        return True

    nodes = [start]
    parent = {0: -1}
    cost = {0: 0.0}
    for _ in range(n_iter):
        if rng.rand() < 0.08:
            sample = goal
        else:
            sample = (rng.uniform(0, H), rng.uniform(0, W))
        d = [np.hypot(n0[0] - sample[0], n0[1] - sample[1]) for n0 in nodes]
        i_near = int(np.argmin(d))
        near = nodes[i_near]
        dist = np.hypot(sample[0] - near[0], sample[1] - near[1])
        if dist < 1e-6:
            continue
        new = (near[0] + (sample[0] - near[0]) / dist * min(step, dist),
               near[1] + (sample[1] - near[1]) / dist * min(step, dist))
        if not (0 <= new[0] < H and 0 <= new[1] < W):
            continue
        if free_mask[int(new[0]), int(new[1])]:
            continue
        if not collision_free(near, new):
            continue
        new_cost = cost[i_near] + np.hypot(new[0] - near[0], new[1] - near[1])
        nodes.append(new)
        idx = len(nodes) - 1
        parent[idx] = i_near
        cost[idx] = new_cost
        # rewire within radius
        radius = 12.0
        for j, n0 in enumerate(nodes[:-1]):
            if np.hypot(n0[0] - new[0], n0[1] - new[1]) < radius and collision_free(new, n0):
                c = new_cost + np.hypot(n0[0] - new[0], n0[1] - new[1])
                if c < cost[j]:
                    parent[j] = idx
                    cost[j] = c
        if np.hypot(new[0] - goal[0], new[1] - goal[1]) < step:
            if collision_free(new, goal):
                nodes.append(goal)
                parent[len(nodes) - 1] = idx
                cost[len(nodes) - 1] = new_cost + np.hypot(new[0] - goal[0], new[1] - goal[1])
                gi = len(nodes) - 1
                path = [nodes[gi]]
                while parent[gi] != -1:
                    gi = parent[gi]
                    path.append(nodes[gi])
                return path[::-1], cost[len(nodes) - 1]
    return None, np.inf


# ---------------------------------------------------------------------------
# Continuous-motion controller (ROS-facing), validated in the paper's
# pure-Python continuous-motion demo (diffdrive_sim.py) before being
# adapted here for ROS topics. Operates in whatever linear unit the
# skeleton graph and your Gazebo world agree on (e.g. 1 grid cell = 1
# metre if you use generate_world.py unmodified).
# ---------------------------------------------------------------------------
class SequentialWaypointController:
    """Sequential waypoint follower: advances to the next waypoint once
    the robot is at least as close to it as to the current one, which
    is robust to corner-cutting and avoids the hunting/oscillation
    failure mode of naive lookahead-search pure pursuit."""

    def __init__(self, waypoints_xy, v_nominal=0.35, wp_tol=0.3, goal_tol=0.4,
                 max_omega=1.5):
        self.wp = np.array(waypoints_xy, dtype=float)
        self.v_nominal = v_nominal
        self.wp_tol = wp_tol
        self.goal_tol = goal_tol
        self.max_omega = max_omega
        self._idx = 1 if len(self.wp) > 1 else 0

    def _advance_if_close(self, x, y):
        moved = True
        while moved and self._idx < len(self.wp) - 1:
            moved = False
            d_cur = np.hypot(self.wp[self._idx, 0] - x, self.wp[self._idx, 1] - y)
            if d_cur < self.wp_tol:
                self._idx += 1
                moved = True
                continue
            d_next = np.hypot(self.wp[self._idx + 1, 0] - x, self.wp[self._idx + 1, 1] - y)
            if d_next < d_cur:
                self._idx += 1
                moved = True

    def at_goal(self, x, y):
        return np.hypot(self.wp[-1, 0] - x, self.wp[-1, 1] - y) < self.goal_tol

    def control(self, x, y, theta):
        self._advance_if_close(x, y)
        tx, ty = self.wp[self._idx]
        dx, dy = tx - x, ty - y
        target_theta = np.arctan2(dy, dx)
        heading_err = (target_theta - theta + np.pi) % (2 * np.pi) - np.pi
        omega = np.clip(2.5 * heading_err, -self.max_omega, self.max_omega)
        v = self.v_nominal * max(0.15, 1.0 - abs(heading_err) / (np.pi / 2))
        dist_to_goal = np.hypot(self.wp[-1, 0] - x, self.wp[-1, 1] - y)
        lookahead = max(self.wp_tol * 3, 1.0)
        if dist_to_goal < 3 * lookahead:
            v *= max(0.25, dist_to_goal / (3 * lookahead))
        return v, omega

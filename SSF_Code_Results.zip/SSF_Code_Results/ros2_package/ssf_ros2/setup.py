from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'ssf_ros2'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.sdf')),
    ],
    install_requires=['setuptools', 'numpy', 'networkx', 'scipy', 'scikit-image'],
    zip_safe=True,
    maintainer='Md Hasibuzzaman',
    maintainer_email='hsbuzzaman@gmail.com',
    description='ROS 2 reference implementation of the Stigmergic Skeleton Field (SSF) shared-blackboard architecture.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'skeleton_service_node = ssf_ros2.skeleton_service_node:main',
            'robot_agent_node = ssf_ros2.robot_agent_node:main',
            'generate_world = ssf_ros2.generate_world:main',
        ],
    },
)
